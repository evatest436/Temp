/*Declare local varaibles */
DECLARE @columnID INT = 0
DECLARE @ExistingTableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0

DECLARE @i INT = 0
DECLARE @NumDims INT = 0
DECLARE @Cnt VARCHAR(40)
DECLARE @SchedRollup VARCHAR(40)
DECLARE @MaxSubCat INT = 0
DECLARE @MaxSchedID INT = 0
DECLARE @MaxCat INT = 0
DECLARE @UpdateICStandard INT = 0

/* HOME PAGE ALERTS */
/* Check if Table is registered*/
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_WEBALERT');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_WEBALERT', 0);
	PRINT 'LVAPP_WEBALERT table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_WEBALERT table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @tableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	/*DELETE from LV_APPTABLE_COLUMNS WHERE TABLEID = @tableID;*/
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'ALERT_ID', 'autointeger', '1')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'DESCRIPTION', 'string', '')
	PRINT 'LVAPP_WEBALERT Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_WEBALERT Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_WEBALERT')
	BEGIN
		PRINT 'LVAPP_WEBALERT table exists'
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
	CREATE TABLE [dbo].[LVAPP_WEBALERT](
  [ALERT_ID] [int] NOT NULL,
  [DESCRIPTION] [varChar](1000),
  CONSTRAINT pk_LVAPP_WEBALERT PRIMARY KEY (ALERT_ID)
	) ON [KLX_BASE_DAT]
	SET ANSI_PADDING OFF;
	Print 'LVAPP_WEBALERT table created'

END; 

/* HOME PAGE LINKS */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_WEBLINKS');

If @ExistingTableID = 0 
BEGIN
PRINT 'build new table';
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_WEBLINKS', 0);
	PRINT 'LVAPP_WEBLINKS table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_WEBLINKS table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'LINK_ID', 'autointeger', '1')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'LINK_DESCRIPTION', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'LINK_URL', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (4, @tableID, 'LINK_PRIORITY', 'number', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (5, @tableID, 'LINK_HOMEPAGE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (6, @tableID, 'LINK_CATEGORY', 'string', '')
	PRINT 'LVAPP_WEBLINKS Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_WEBLINKS Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_WEBLINKS')
	BEGIN
		PRINT 'LVAPP_WEBLINKS table exists'
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
	CREATE TABLE [dbo].[LVAPP_WEBLINKS](
    [LINK_ID] [int] NOT NULL,
	[LINK_DESCRIPTION] [varChar](1000),
	[LINK_URL] [varchar](4000) ,
	[LINK_PRIORITY] [float], 
	[LINK_HOMEPAGE] [varChar](255),
	[LINK_CATEGORY] [varChar](100),
	CONSTRAINT pk_LVAPP_WEBLINKS PRIMARY KEY (LINK_ID)
	) ON [KLX_BASE_DAT]
	SET ANSI_PADDING OFF;
	Print 'LVAPP_WEBLINKS table created'

END; 
GO

/*Declare local varaibles */
DECLARE @columnID INT = 0
DECLARE @ExistingTableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0

DECLARE @i INT = 0
DECLARE @NumDims INT = 0
DECLARE @Cnt VARCHAR(40)
DECLARE @SchedRollup VARCHAR(40)
DECLARE @MaxSubCat INT = 0
DECLARE @MaxSchedID INT = 0
DECLARE @MaxCat INT = 0
DECLARE @UpdateICStandard INT = 0

/* HOME PAGE ALERTS */
/* CJE Setup */
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);

 /* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_CJESETUP');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_CJESETUP', 0);
	PRINT 'LVAPP_CJESETUP table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_CJESETUP table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID] ,[TABLEID], [COLUMNNAME] ,[DATATYPE] ,[DATAVALUES]) VALUES(2, @tableID, 'APPID', 'STRING', '');	
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID] ,[TABLEID], [COLUMNNAME] ,[DATATYPE] ,[DATAVALUES]) VALUES(3, @tableID, 'POSTPERIOD', 'STRING', '');
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID] ,[TABLEID], [COLUMNNAME] ,[DATATYPE] ,[DATAVALUES]) VALUES(4, @tableID, 'TYPE', 'STRING', '');
	PRINT 'LVAPP_CJESETUP Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_CJESETUP Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_CJESETUP')
	BEGIN
		PRINT 'LVAPP_CJESETUP table exists'
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
	CREATE TABLE [dbo].[LVAPP_CJESETUP](
	[APPID] [varchar](31) NOT NULL,
	[POSTPERIOD] [varchar](100) NOT NULL,
	[TYPE] [varchar](100),
	CONSTRAINT [PK_IDPER] PRIMARY KEY (APPID,POSTPERIOD))
	SET ANSI_PADDING OFF
	Print 'LVAPP_CJESETUP table created'
END; 
GO

/*Declare local varaibles */
DECLARE @columnID INT = 0
DECLARE @ExistingTableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0

DECLARE @i INT = 0
DECLARE @NumDims INT = 0
DECLARE @Cnt VARCHAR(40)
DECLARE @SchedRollup VARCHAR(40)
DECLARE @MaxSubCat INT = 0
DECLARE @MaxSchedID INT = 0
DECLARE @MaxCat INT = 0
DECLARE @UpdateICStandard INT = 0

/* LV User Components */
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);

/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LV_USERCOMPONENTS');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LV_USERCOMPONENTS', 0);
	PRINT 'LV_USERCOMPONENTS table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LV_USERCOMPONENTS table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'USER_NAME', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'AUTH_NAME', 'string', '')
	PRINT 'LV_USERCOMPONENTS Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LV_USERCOMPONENTS Columns have been previously registered'
END;

/* LV Group Components */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LV_GROUPCOMPONENTS');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LV_GROUPCOMPONENTS', 0);
	PRINT 'LV_GROUPCOMPONENTS table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LV_GROUPCOMPONENTS table has been previously registered'
END;



/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'GROUP_NAME', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'AUTH_NAME', 'string', '')
	PRINT 'LV_GROUPCOMPONENTS Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LV_GROUPCOMPONENTS Columns have been previously registered'
END;
GO

/*Declare local varaibles */
DECLARE @columnID INT = 0
DECLARE @ExistingTableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0

DECLARE @i INT = 0
DECLARE @NumDims INT = 0
DECLARE @Cnt VARCHAR(40)
DECLARE @SchedRollup VARCHAR(40)
DECLARE @MaxSubCat INT = 0
DECLARE @MaxSchedID INT = 0
DECLARE @MaxCat INT = 0
DECLARE @UpdateICStandard INT = 0

/* LVAPP Automation Settings */
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_AUTOMATION')
	BEGIN
		PRINT 'LVAPP_AUTOMATION table exists'
		IF COL_LENGTH('LVAPP_AUTOMATION', 'TIMEPERIOD') IS NULL
		BEGIN
		  PRINT ' LVAPP_AUTOMATIONUpdating table'
		  ALTER TABLE LVAPP_AUTOMATION
		  ADD TIMEPERIOD int;
	  END;
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
	CREATE TABLE [dbo].LVAPP_AUTOMATION (
		[ID] float NOT NULL,
		[CALCULATION] varchar(31) ,
		[ACCOUNT] int NOT NULL,
		[ENTITY] int NOT NULL,
		[PARAMS] varchar(4000),
		[TIMEPERIOD] int, 
		CONSTRAINT pk_LVAPP_AUTOMATION PRIMARY KEY ([ID], [CALCULATION])) ON [KLX_BASE_DAT]
  SET ANSI_PADDING OFF
	Print 'LVAPP_AUTOMATION table created'
END; 


/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_AUTOMATION');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_AUTOMATION', 0);
	PRINT 'LVAPP_AUTOMATION table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_AUTOMATION table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(1, @tableID, 'ID', 'NUMBER', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(2, @tableID, 'CALCULATION', 'STRING', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(3, @tableID, 'ACCOUNT', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=0))
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(4, @tableID, 'ENTITY', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=2))
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(5, @tableID, 'PARAMS', 'STRING', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(6, @tableID, 'TIMEPERIOD', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=1))
	PRINT 'LVAPP_AUTOMATION Columns have been registered'
END
ELSE
BEGIN
	SET @columnID = (SELECT ISNULL(MAX(COLUMNID),0) from LV_APPTABLE_COLUMNS WHERE TABLEID = @tableID AND COLUMNNAME = 'TIMEPERIOD');
	If @columnID = 0
	BEGIN
		SET @columnID = (SELECT ISNULL(MAX(COLUMNID),0) from LV_APPTABLE_COLUMNS WHERE TABLEID = @tableID) + 1;
		INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(@columnID, @tableID, 'TIMEPERIOD', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=1));
		PRINT 'LVAPP_AUTOMATION Updating Apptable Columns'
	END;
	ELSE
	BEGIN
		PRINT 'LVAPP_AUTOMATION Columns have been previously registered'
	END;
END;

/* LVAPP Areas */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_AREAS');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_AREAS', 0);
	PRINT 'LVAPP_AREAS table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_AREAS table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(1, @tableID, 'ID', 'NUMBER', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(2, @tableID, 'RELID', 'NUMBER', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(3, @tableID, 'TYPE', 'STRING', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(4, @tableID, 'DIMENSION', 'DIMENSION', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(5, @tableID, 'ITEMNO', 'NUMBER', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(6, @tableID, 'SYMBOL', 'SYMBOL', 'DimensionColumn:DIMENSION')
	PRINT 'LVAPP_AREAS Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_AREAS Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_AREAS')
	BEGIN
		PRINT 'LVAPP_AREAS table exists'
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
	CREATE TABLE [dbo].LVAPP_AREAS (
		[ID] float NOT NULL,
		[RELID] float NOT NULL,
		[TYPE] varchar(15) NOT NULL,
		[DIMENSION] int NOT NULL,
		[ITEMNO] float NOT NULL,
		[SYMBOL] int NOT NULL,
		CONSTRAINT pk_LVAPP_AREAS PRIMARY KEY ([RELID], [TYPE], [DIMENSION], [ITEMNO])) ON [KLX_BASE_DAT]
  SET ANSI_PADDING OFF
	Print 'LVAPP_AREAS table created'
END; 



/* LVAPP Alloc Run */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_ALLOCRUN');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_ALLOCRUN', 0);
	PRINT 'LVAPP_ALLOCRUN table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_ALLOCRUN table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(1, @tableID, 'ID', 'autointeger', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(2, @tableID, 'ALLOCID', 'NUMBER', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(3, @tableID, 'ALLOCPERIOD', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=1))
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(4, @tableID, 'PROCESSORDER', 'NUMBER', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(5, @tableID, 'ALLOCSTATUS', 'NUMBER', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(6, @tableID, 'ACCOUNT', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=0))
	PRINT 'LVAPP_ALLOCRUN Columns have been registered'
END
ELSE
BEGIN
	SET @columnID = (SELECT ISNULL(MAX(COLUMNID),0) from LV_APPTABLE_COLUMNS WHERE TABLEID = @tableID AND COLUMNNAME = 'ALLOCSTATUS');
	If @columnID = 0
	BEGIN
		SET @columnID = (SELECT ISNULL(MAX(COLUMNID),0) from LV_APPTABLE_COLUMNS WHERE TABLEID = @tableID) + 1;
		INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(@columnID, @tableID, 'ALLOCSTATUS', 'NUMBER', '');
		SET @columnID = (SELECT ISNULL(MAX(COLUMNID),0) from LV_APPTABLE_COLUMNS WHERE TABLEID = @tableID) + 1;
		INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(@columnID, @tableID, 'ACCOUNT', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=0));
		PRINT 'LVAPP_ALLOCRUN Updating Apptable Columns for ALLOCSTATUS AND ACCOUNT'
	END;
	ELSE
	BEGIN
		PRINT 'LVAPP_ALLOCRUN Columns have been previously registered'
	END;
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_ALLOCRUN')
	BEGIN
		PRINT 'LVAPP_ALLOCRUN table exists'
		IF COL_LENGTH('LVAPP_ALLOCRUN', 'ALLOCSTATUS') IS NULL
		BEGIN
		  PRINT ' LVAPP_ALLOCRUN Updating table'
		  ALTER TABLE LVAPP_ALLOCRUN
		  ADD ALLOCSTATUS float;
		END;
		IF COL_LENGTH('LVAPP_ALLOCRUN', 'ACCOUNT') IS NULL
		BEGIN
		  PRINT ' LVAPP_ALLOCRUN Updating table'
		  ALTER TABLE LVAPP_ALLOCRUN
		  ADD ACCOUNT int;
		END;
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
	CREATE TABLE [dbo].LVAPP_ALLOCRUN (
		[ID] int NOT NULL,
		[ALLOCID] float NOT NULL,
		[ALLOCPERIOD] Int NOT NULL,
		[PROCESSORDER] float,
		[ALLOCSTATUS] float,
		[ACCOUNT] Int,
		CONSTRAINT pk_LVAPP_ALLOCRUN PRIMARY KEY ([ID])) ON [KLX_BASE_DAT]
  SET ANSI_PADDING OFF
	Print 'LVAPP_ALLOCRUN table created'
END; 


/* LVAPP_PROCESSES */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_PROCESSES');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_PROCESSES', 0);
	PRINT 'LVAPP_PROCESSES table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_PROCESSES table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
		INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'PROCESS_ID', 'string', '')
		INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'NAME', 'string', '')
		INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'ICON', 'string', '')
		INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (4, @tableID, 'TITLE', 'string', '')
	PRINT 'LVAPP_PROCESSES Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_PROCESSES Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_PROCESSES')
	BEGIN
		SET @tableID =  (SELECT TABLEID FROM LV_APPTABLES WHERE TABLENAME = 'LVAPP_PROCESSES');
		IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'LVAPP_PROCESSES' AND COLUMN_NAME = 'TITLE') 
		BEGIN
			INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (4, @tableID, 'TITLE', 'string', '')
			EXEC sp_executesql N' ALTER TABLE LVAPP_PROCESSES ADD TITLE varchar(256)'
			EXEC sp_executesql N' UPDATE LVAPP_PROCESSES SET TITLE = NAME'
			PRINT 'LVAPP_PROCESSES Updating '
		END;
		ELSE
	BEGIN
		PRINT 'LVAPP_PROCESSES table exists'
	END
	END;
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
		CREATE TABLE [dbo].[LVAPP_PROCESSES] (
		[PROCESS_ID]	[varchar] (100) NOT NULL,
		[NAME]			[varchar] (256), 
		[ICON]			[varchar] (100),
		[TITLE]			[varchar] (256),
		CONSTRAINT pk_LVAPP_PROCESSES PRIMARY KEY (PROCESS_ID)
		)
		ON [KLX_BASE_DAT]
		SET ANSI_PADDING OFF
	Print 'LVAPP_PROCESSES table created'
END;
 
/* LVAPP_PROCESSSTEPS */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_PROCESSSTEPS');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_PROCESSSTEPS', 0);
	PRINT 'LVAPP_PROCESSSTEPS table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_PROCESSSTEPS table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'PROCESS_ID', 'string', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'STEP_ID', 'string', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'NAME', 'string', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (4, @tableID, 'ICON', 'string', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (5, @tableID, 'COLOR', 'string', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (6, @tableID, 'SEQUENCEORDER', 'number', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (7, @tableID, 'ACTIONINWEB', 'string', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (8, @tableID, 'ACTIONINCLIENT', 'string', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (9, @tableID, 'DESCRIPTION', 'string', '')
	PRINT 'LVAPP_PROCESSSTEPS Columns have been registered'
END
ELSE
BEGIN
	
	Set @columnID = (SELECT ISNULL(MAX(COLUMNID),0) from LV_APPTABLE_COLUMNS WHERE TABLEID = @tableID AND COLUMNNAME = 'DESCRIPTION');
	If @columnID = 0
	BEGIN
		Set @columnID = (SELECT ISNULL(MAX(COLUMNID),0) from LV_APPTABLE_COLUMNS WHERE TABLEID = @tableID) + 1
		INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(@columnID, @tableID, 'DESCRIPTION', 'STRING', '');
		PRINT 'LVAPP_PROCESSSTEPS Updating Apptable Columns for DESCRIPTION'
	END;
	ELSE
	BEGIN
		PRINT 'LVAPP_PROCESSSTEPS Columns have been previously registered'
	END;
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_PROCESSSTEPS')
	BEGIN
		PRINT 'LVAPP_PROCESSSTEPS table exists'
		If COL_LENGTH('LVAPP_PROCESSSTEPS','DESCRIPTION') IS NULL
		BEGIN
			PRINT 'LVAPP_PROCESSSTEPS Updating table'
			ALTER TABLE LVAPP_PROCESSSTEPS
			ADD DESCRIPTION varchar(1024);
		END;
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
	CREATE TABLE [dbo].[LVAPP_PROCESSSTEPS] (
		[PROCESS_ID]		[varchar] (100) NOT NULL,
		[STEP_ID]			[varchar] (100) NOT NULL,
		[NAME]				[varchar] (256),
		[ICON]				[varchar] (100),
		[COLOR]				[varchar] (50),
		[SEQUENCEORDER]		[float],
		[ACTIONINWEB]		[varchar] (256),
		[ACTIONINCLIENT]	[varchar] (256),
		[DESCRIPTION]		[varchar] (1024),
		CONSTRAINT pk_LVAPP_PROCESSSTEPS PRIMARY KEY (PROCESS_ID, STEP_ID)
	)
	ON [KLX_BASE_DAT]
	SET ANSI_PADDING OFF
	Print 'LVAPP_PROCESSSTEPS table created'
END; 

/* LVAPP_STEPRELATIONSHIPS */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_STEPRELATIONSHIPS');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_STEPRELATIONSHIPS', 0);
	PRINT 'LVAPP_STEPRELATIONSHIPS table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_STEPRELATIONSHIPS table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'PROCESS_ID', 'string', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'STEP_ID', 'string', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'NEXT_STEPID', 'string', '')
	PRINT 'LVAPP_STEPRELATIONSHIPS Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_STEPRELATIONSHIPS Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_STEPRELATIONSHIPS')
	BEGIN
		PRINT 'LVAPP_STEPRELATIONSHIPS table exists'
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
	CREATE TABLE [dbo].[LVAPP_STEPRELATIONSHIPS] (
		[PROCESS_ID]	[varchar] (100) NOT NULL,
		[STEP_ID]		[varchar] (100) NOT NULL,
		[NEXT_STEPID]	[varchar] (100) NOT NULL,
		CONSTRAINT pk_LVAPP_STEPRELATIONSHIPS PRIMARY KEY (PROCESS_ID, STEP_ID, NEXT_STEPID)
	)
	ON [KLX_BASE_DAT]
	SET ANSI_PADDING OFF
	Print 'LVAPP_STEPRELATIONSHIPS table created'
END; 
GO

/*Declare local varaibles */
DECLARE @columnID INT = 0
DECLARE @ExistingTableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0

DECLARE @i INT = 0
DECLARE @NumDims INT = 0
DECLARE @Cnt VARCHAR(40)
DECLARE @SchedRollup VARCHAR(40)
DECLARE @MaxSubCat INT = 0
DECLARE @MaxSchedID INT = 0
DECLARE @MaxCat INT = 0
DECLARE @UpdateICStandard INT = 0

/* SLNS Intercompany */
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);

/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'SLNS_INTERCOMPANY');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'SLNS_INTERCOMPANY', 0);
	PRINT 'SLNS_INTERCOMPANY table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'SLNS_INTERCOMPANY table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(1, @tableID, 'NAME', 'STRING', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(2, @tableID, 'OFFSET_ACCOUNT', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where DIM_INDEX=0))
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(3, @tableID, 'TYPE', 'AUTOINTEGER', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(4, @tableID, 'LANG_CODE', 'STRING', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(5, @tableID, 'DESCRIPTION', 'STRING', '')
	PRINT 'SLNS_INTERCOMPANY Columns have been registered'
END
ELSE
BEGIN
	PRINT 'SLNS_INTERCOMPANY Columns have been previously registered'
END;
GO

/*Declare local varaibles */
DECLARE @columnID INT = 0
DECLARE @ExistingTableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0

DECLARE @i INT = 0
DECLARE @NumDims INT = 0
DECLARE @Cnt VARCHAR(40)
DECLARE @SchedRollup VARCHAR(40)
DECLARE @MaxSubCat INT = 0
DECLARE @MaxSchedID INT = 0
DECLARE @MaxCat INT = 0
DECLARE @UpdateICStandard INT = 0

/* LV_UserPasswordActivity */

/* Check if Table is registered*/
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LV_UserPasswordActivity');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LV_UserPasswordActivity', 0);
	PRINT 'LV_UserPasswordActivity table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LV_UserPasswordActivity table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (1, @tableID,'USER_NAME','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (2, @tableID,'CREATED','DATE','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (3, @tableID,'LAST_UPDATE','DATE','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (4, @tableID,'PASSWORD_RESET','BOOLEAN','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (5, @tableID,'PASSWORD_RESET_EXPIRY','BOOLEAN','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (6, @tableID,'PASSWORD_RESET_TOKEN','STRING','');
	PRINT 'LV_UserPasswordActivity Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LV_UserPasswordActivity Columns have been previously registered'
END;

/* USER AUTHORIZATIONS */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LV_UserAuthorizations');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LV_UserAuthorizations', 0);
	PRINT 'LV_UserAuthorizations table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LV_UserAuthorizations table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (1, @tableID,'USER_NAME','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (2, @tableID,'AUTH_NAME','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (3, @tableID,'AUTH_DESC','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (4, @tableID,'AUTH_TYPE','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (5, @tableID,'LAST_UPDATE','DATE','');
	PRINT 'LV_UserAuthorizations Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LV_UserAuthorizations Columns have been previously registered'
END;

/* USER ACCESS, ALL USERS */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LV_UserAccessForAllUsers');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LV_UserAccessForAllUsers', 0);
	PRINT 'LV_UserAccessForAllUsers table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LV_UserAccessForAllUsers table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (1, @tableID,'USER_NAME','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (2, @tableID,'ACCESS_DIM','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (3, @tableID,'ACCESS_SYM','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (4, @tableID,'ACCESS_TYPE','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (5, @tableID,'ACCESS_PRIOR','AUTOINTEGER','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (6, @tableID,'ACCESS_LEVEL','AUTOINTEGER','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (7, @tableID,'INHERIT','BOOLEAN','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (8, @tableID,'ROLE_NAME','STRING','');
	PRINT 'LV_UserAccessForAllUsers Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LV_UserAccessForAllUsers Columns have been previously registered'
END;

/* USER ATTRIBUTES */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LV_UserAttributes');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LV_UserAttributes', 0);
	PRINT 'LV_UserAttributes table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LV_UserAttributes table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (1, @tableID,'USER_NAME','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (2, @tableID,'ATTR_NAME','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (3, @tableID,'ATTR_DESC','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (4, @tableID,'ATTR_VALUE','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (5, @tableID,'DEFAULT_NUMERIC','NUMBER','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (6, @tableID,'DEFAULT_STRING','STRING','');
	PRINT 'LV_UserAttributes Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LV_UserAttributes Columns have been previously registered'
END;

/* GROUP ACTIVITY */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LV_GroupActivity');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LV_GroupActivity', 0);
	PRINT 'LV_GroupActivity table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LV_GroupActivity table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (1, @tableID,'GROUP_NAME','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (2, @tableID,'GROUP_DESC','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (3, @tableID,'CREATED','DATE','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (4, @tableID,'LAST_UPDATE','DATE','');
	PRINT 'LV_GroupActivity Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LV_GroupActivity Columns have been previously registered'
END;

/* GROUP AUTHORIZATIONS */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LV_GroupAuthorizations');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LV_GroupAuthorizations', 0);
	PRINT 'LV_GroupAuthorizations table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LV_GroupAuthorizations table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (1, @tableID,'GROUP_NAME','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (2, @tableID,'AUTH_NAME','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (3, @tableID,'AUTH_DESC','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (4, @tableID,'AUTH_TYPE','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (5, @tableID,'LAST_UPDATE','DATE','');
	PRINT 'LV_GroupAuthorizations Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LV_GroupAuthorizations Columns have been previously registered'
END;

/* GROUP ACCESS */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LV_GroupAccessForGroups');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LV_GroupAccessForGroups', 0);
	PRINT 'LV_GroupAccessForGroups table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LV_GroupAccessForGroups table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (1, @tableID,'GROUP_NAME','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (2, @tableID,'ACCESS_DIM','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (3, @tableID,'ACCESS_SYM','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (4, @tableID,'ACCESS_TYPE','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (5, @tableID,'ACCESS_PRIOR','AUTOINTEGER','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (6, @tableID,'ACCESS_LEVEL','AUTOINTEGER','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (7, @tableID,'INHERIT','BOOLEAN','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (8, @tableID,'ROLE_NAME','STRING','');
	PRINT 'LV_GroupAccessForGroups Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LV_GroupAccessForGroups Columns have been previously registered'
END;

/* COMBINED USER GROUP ACCESS */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LV_CombineUserGroupAccess');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LV_CombineUserGroupAccess', 0);
	PRINT 'LV_CombineUserGroupAccess table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LV_CombineUserGroupAccess table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (1, @tableID,'USER_NAME','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (2, @tableID,'GROUP_NAME','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (3, @tableID,'ACCESS_DIM','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (4, @tableID,'ACCESS_SYM','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (5, @tableID,'ACCESS_TYPE','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (6, @tableID,'ACCESS_PRIOR','AUTOINTEGER','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (7, @tableID,'ACCESS_LEVEL','AUTOINTEGER','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (8, @tableID,'INHERIT','BOOLEAN','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (9, @tableID,'ROLE_NAME','STRING','');
	PRINT 'LV_CombineUserGroupAccess Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LV_CombineUserGroupAccess Columns have been previously registered'
END;

/* USER GROUP MEMBERSHIP */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'SLNS_USERGROUPMEMBERSHIP');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'SLNS_USERGROUPMEMBERSHIP', 0);
	PRINT 'SLNS_USERGROUPMEMBERSHIP table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'SLNS_USERGROUPMEMBERSHIP table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (1, @tableID,'GROUP_NAME','STRING','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (2, @tableID,'GROUP_DESC','STRING','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (3, @tableID,'USER_NAME','STRING','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (4, @tableID,'USER_DOMAIN','STRING','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (5, @tableID,'USER_DESC','STRING','');
	PRINT 'SLNS_USERGROUPMEMBERSHIP Columns have been registered'
END
ELSE
BEGIN
	PRINT 'SLNS_USERGROUPMEMBERSHIP Columns have been previously registered'
END;

/* USERS */
/* Check if Table is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'SLNS_USERS');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'SLNS_USERS', 0);
	PRINT 'SLNS_USERS table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'SLNS_USERS table has been previously registered'
END;

/* Check if Table's columns are registered */ 
/* register (or re-register) the columns */ 
BEGIN
	DELETE FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @tableID;
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (1, @tableID,'USER_NAME','STRING','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (2, @tableID,'USER_DOMAIN','STRING','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (3, @tableID,'USER_DESC','STRING','');
	INSERT INTO LV_APPTABLE_COLUMNS VALUES (4, @tableID,'USER_STATUS','AUTOINTEGER','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (5, @tableID,'FIRST_NAME','STRING','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (6, @tableID,'LAST_NAME','STRING','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (7, @tableID,'EMAIL','STRING','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (8, @tableID,'OFFICE_PHONE','STRING','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (9, @tableID,'HOME_PHONE','STRING','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (10, @tableID,'USER_LOGIN','DATE','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (11, @tableID,'LAST_UPDATE','DATE','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (12, @tableID,'CREATE_DATE','DATE','');
    INSERT INTO LV_APPTABLE_COLUMNS VALUES (13, @tableID,'FAIL_ATTEMPT','AUTOINTEGER','');
	PRINT 'SLNS_USERS Columns have been registered'
END;
GO

/*Declare local varaibles */
DECLARE @columnID INT = 0
DECLARE @ExistingTableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0

DECLARE @i INT = 0
DECLARE @NumDims INT = 0
DECLARE @Cnt VARCHAR(40)
DECLARE @SchedRollup VARCHAR(40)
DECLARE @MaxSubCat INT = 0
DECLARE @MaxSchedID INT = 0
DECLARE @MaxCat INT = 0
DECLARE @UpdateICStandard INT = 0

/* VIEW LV_USERCOMPONENTS */
IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'LV_USERCOMPONENTS'))
BEGIN
    EXECUTE('CREATE VIEW LV_USERCOMPONENTS AS SELECT TOP (100) PERCENT USER_NAME, B.NAME AS AUTH_NAME FROM LV_USER_MAIN A, LV_OPERATIONS B, LV_USER_OPERATIONS C');
	Print 'LV_USERCOMPONENTS View created'
END;
GO

ALTER VIEW LV_USERCOMPONENTS AS 
    SELECT TOP (100) PERCENT USER_NAME, B.NAME AS AUTH_NAME FROM LV_USER_MAIN A, LV_OPERATIONS B, LV_USER_OPERATIONS C
	WHERE     USER_STATUS != 1 AND A.USER_ID = C.USER_ID AND B.OPERATION_ID = C.OPERATION_ID AND C.OBJECT_ID = 0
	AND B.NAME IN ('APPLICATIONADMINISTRATOR', 'SERVERMANAGER', 'WORKFLOWDESIGNER', 'JOURNALENTRIES', 'ADDINFOROFFICE', 'ANALYSISREPORTINGPUBLISHER','ANALYSISREPORTINGAUTHOR', 'EXCELV3', 'DASHBOARDDESIGNER', 'MAPPINGSEDITOR', 'DESIGNER')
	ORDER BY  USER_NAME
GO
Print 'LV_USERCOMPONENTS View updated'

/* VIEW LV_GROUPCOMPONENTS */
IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'LV_GROUPCOMPONENTS'))
BEGIN
    EXECUTE('CREATE VIEW LV_GROUPCOMPONENTS AS SELECT TOP (100) PERCENT A.NAME AS GROUP_NAME, C.NAME AS AUTH_NAME FROM LV_GROUP_MAIN A, LV_OPERATIONS C, LV_GROUP_OPERATIONS D');
	Print 'LV_GROUPCOMPONENTS View created'
END;
GO

ALTER VIEW LV_GROUPCOMPONENTS AS    
	SELECT TOP (100) PERCENT A.NAME AS GROUP_NAME, C.NAME AS AUTH_NAME FROM LV_GROUP_MAIN A, LV_OPERATIONS C, LV_GROUP_OPERATIONS D
	WHERE     A.GROUP_ID = D.GROUP_ID AND C.OPERATION_ID = D.OPERATION_ID AND D.OBJECT_ID = 0
	AND C.NAME IN ('APPLICATIONADMINISTRATOR', 'SERVERMANAGER', 'WORKFLOWDESIGNER', 'JOURNALENTRIES', 'ADDINFOROFFICE', 'ANALYSISREPORTINGPUBLISHER', 'ANALYSISREPORTINGAUTHOR', 'EXCELV3', 'DASHBOARDDESIGNER', 'MAPPINGSEDITOR', 'DESIGNER')
	ORDER BY  GROUP_NAME
GO
Print 'LV_GROUPCOMPONENTS View updated'

/* VIEW SLNS_INTERCOMPANY */
IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'SLNS_INTERCOMPANY'))
BEGIN
    EXECUTE('CREATE VIEW SLNS_INTERCOMPANY AS SELECT a.IC_OBJ_NAME AS NAME, a.IC_OBJ_OFFSET_ACCT AS OFFSET_ACCOUNT, a.IC_OBJ_TYPE AS TYPE, b.LANG_CODE, b.DESCRIPTION
	FROM KLX_IC_OBJECT AS A, KLX_DESC AS b');
	Print 'SLNS_INTERCOMPANY View created'
END;
GO

ALTER VIEW SLNS_INTERCOMPANY AS    
	SELECT a.IC_OBJ_NAME AS NAME, a.IC_OBJ_OFFSET_ACCT AS OFFSET_ACCOUNT, a.IC_OBJ_TYPE AS TYPE, b.LANG_CODE, b.DESCRIPTION
	FROM dbo.KLX_IC_OBJECT AS a INNER JOIN
	KLX_DESC AS b ON a.IC_OBJ_ID = b.MAJOR_OBJ_ID
	WHERE (b.DESC_TYPE = 17)
GO
Print 'SLNS_INTERCOMPANY View updated'

/* VIEW SLNS_USERGROUPMEMBERSHIP */
IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'SLNS_USERGROUPMEMBERSHIP'))
BEGIN
    EXECUTE('CREATE VIEW SLNS_USERGROUPMEMBERSHIP AS SELECT TOP (100) PERCENT NAME AS GROUP_NAME, C.DESCRIPTION AS GROUP_DESC, USER_NAME, DOMAIN AS USER_DOMAIN, B.DESCRIPTION AS USER_DESC
    FROM      LV_GROUP_MAIN A CROSS JOIN LV_USER_MAIN B, KLX_DESC C, LV_USER_GROUP D
    WHERE     USER_STATUS != 1 AND LANG_CODE = ''EN'' AND A.GROUP_ID = MAJOR_OBJ_ID AND DESC_TYPE = 19 AND A.GROUP_ID = D.GROUP_ID AND B.USER_ID = D.USER_ID
    ORDER BY  GROUP_NAME, USER_NAME');
	Print 'SLNS_USERGROUPMEMBERSHIP View created'
END
GO
Print 'SLNS_USERGROUPMEMBERSHIP View updated'

/* VIEW SLNS_USERS */
IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'SLNS_USERS'))
BEGIN
    EXECUTE('CREATE VIEW SLNS_USERS AS SELECT TOP (100) PERCENT USER_NAME, DOMAIN AS USER_DOMAIN, DESCRIPTION AS USER_DESC, USER_STATUS, FIRST_NAME, LAST_NAME, EMAIL, OFFICE_PHONE, HOME_PHONE, LAST_LOGIN AS USER_LOGIN, LAST_UPDATE, CREATE_DATE, FAIL_ATTEMPT
    FROM      LV_USER_MAIN A, LV_USER_DETAILS B
    WHERE     A.USER_ID = B.USER_ID
    ORDER BY  USER_NAME');
	Print 'SLNS_USERS View created'
END;
GO

ALTER VIEW SLNS_USERS AS
	SELECT TOP (100) PERCENT USER_NAME, DOMAIN AS USER_DOMAIN, DESCRIPTION AS USER_DESC, USER_STATUS, FIRST_NAME, LAST_NAME, EMAIL, OFFICE_PHONE, HOME_PHONE, LAST_LOGIN AS USER_LOGIN, LAST_UPDATE, CREATE_DATE, FAIL_ATTEMPT
	FROM LV_USER_MAIN A, LV_USER_DETAILS B
	WHERE A.USER_ID = B.USER_ID
	ORDER BY USER_NAME;
GO
Print 'SLNS_USERS View updated'

/*Declare local varaibles */
DECLARE @columnID INT = 0
DECLARE @ExistingTableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0

DECLARE @i INT = 0
DECLARE @NumDims INT = 0
DECLARE @Cnt VARCHAR(40)
DECLARE @SchedRollup VARCHAR(40)
DECLARE @MaxSubCat INT = 0
DECLARE @MaxSchedID INT = 0
DECLARE @MaxCat INT = 0
DECLARE @UpdateICStandard INT = 0

/* ISO Country Codes */
/* Check if Table is registered*/
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_ISOCOUNTRIES');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_ISOCOUNTRIES', 0);
	PRINT 'LVAPP_ISOCOUNTRIES table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_ISOCOUNTRIES table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'COUNTRY', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'ISOCODE', 'boolean', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'ALPHA2', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (4, @tableID, 'ALPHA3', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (5, @tableID, 'NUMERIC3', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (6, @tableID, 'DESCRIPTION', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (7, @tableID, 'ACTIVE', 'boolean', '')
	PRINT 'LVAPP_ISOCOUNTRIES Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_ISOCOUNTRIES Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_ISOCOUNTRIES')
	BEGIN
		PRINT 'LVAPP_ISOCOUNTRIES table exists'
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
	CREATE TABLE [dbo].[LVAPP_ISOCOUNTRIES](
		[COUNTRY] [varChar](1000) NOT NULL,
		[ISOCODE] [int],
		[ALPHA2] [varchar](2) NOT NULL,
		[ALPHA3] [varchar](3), 
		[NUMERIC3] [varchar](3),
		[DESCRIPTION] [varchar](4000),
		[ACTIVE] [int] NOT NULL,
		CONSTRAINT pk_LVAPP_ISOCOUNTRIES PRIMARY KEY (ALPHA2)
	) ON [KLX_BASE_DAT]
	SET ANSI_PADDING OFF
	Print 'LVAPP_ISOCOUNTRIES table created'
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1, 'Afghanistan', 'AF', 'AFG', '004', 'Afghanistan', 0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Albania', 'AL', 'ALB', '008', 'Albania' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Antarctica', 'AQ', 'ATA', '010', 'Antarctica' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Algeria', 'DZ', 'DZA', '012', 'Algeria' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'American Samoa', 'AS', 'ASM', '016', 'American Samoa' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Andorra', 'AD', 'AND', '020', 'Andorra' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Angola', 'AO', 'AGO', '024', 'Angola' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Antigua and Barbuda', 'AG', 'ATG', '028', 'Antigua and Barbuda' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Azerbaijan', 'AZ', 'AZE', '031', 'Azerbaijan' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Argentina', 'AR', 'ARG', '032', 'Argentina' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Australia', 'AU', 'AUS', '036', 'Australia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Austria', 'AT', 'AUT', '040', 'Austria' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Bahamas', 'BS', 'BHS', '044', 'Bahamas' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Bahrain', 'BH', 'BHR', '048', 'Bahrain' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Bangladesh', 'BD', 'BGD', '050', 'Bangladesh' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Armenia', 'AM', 'ARM', '051', 'Armenia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Barbados', 'BB', 'BRB', '052', 'Barbados' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Belgium', 'BE', 'BEL', '056', 'Belgium' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Bermuda', 'BM', 'BMU', '060', 'Bermuda' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Bhutan', 'BT', 'BTN', '064', 'Bhutan' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Bolivia, Plurinational State of', 'BO', 'BOL', '068', 'Bolivia, Plurinational State of' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Bosnia and Herzegovina', 'BA', 'BIH', '070', 'Bosnia and Herzegovina' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Botswana', 'BW', 'BWA', '072', 'Botswana' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Bouvet Island', 'BV', 'BVT', '074', 'Bouvet Island' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Brazil', 'BR', 'BRA', '076', 'Brazil' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Belize', 'BZ', 'BLZ', '084', 'Belize' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'British Indian Ocean Territory', 'IO', 'IOT', '086', 'British Indian Ocean Territory' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Solomon Islands', 'SB', 'SLB', '090', 'Solomon Islands' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Virgin Islands, British', 'VG', 'VGB', '092', 'Virgin Islands, British' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Brunei Darussalam', 'BN', 'BRN', '096', 'Brunei Darussalam' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Bulgaria', 'BG', 'BGR', '100', 'Bulgaria' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Myanmar', 'MM', 'MMR', '104', 'Myanmar' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Burundi', 'BI', 'BDI', '108', 'Burundi' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Belarus', 'BY', 'BLR', '112', 'Belarus' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Cambodia', 'KH', 'KHM', '116', 'Cambodia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Cameroon', 'CM', 'CMR', '120', 'Cameroon' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Canada', 'CA', 'CAN', '124', 'Canada' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Cape Verde', 'CV', 'CPV', '132', 'Cape Verde' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Cayman Islands', 'KY', 'CYM', '136', 'Cayman Islands' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Central African Republic', 'CF', 'CAF', '140', 'Central African Republic' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Sri Lanka', 'LK', 'LKA', '144', 'Sri Lanka' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Chad', 'TD', 'TCD', '148', 'Chad' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Chile', 'CL', 'CHL', '152', 'Chile' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'China', 'CN', 'CHN', '156', 'China' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Taiwan, Province of China', 'TW', 'TWN', '158', 'Taiwan, Province of China' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Christmas Island', 'CX', 'CXR', '162', 'Christmas Island' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Cocos (Keeling) Islands', 'CC', 'CCK', '166', 'Cocos (Keeling) Islands' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Colombia', 'CO', 'COL', '170', 'Colombia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Comoros', 'KM', 'COM', '174', 'Comoros' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Mayotte', 'YT', 'MYT', '175', 'Mayotte' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Congo', 'CG', 'COG', '178', 'Congo' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Congo, the Democratic Republic of the', 'CD', 'COD', '180', 'Congo, the Democratic Republic of the' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Cook Islands', 'CK', 'COK', '184', 'Cook Islands' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Costa Rica', 'CR', 'CRI', '188', 'Costa Rica' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Croatia', 'HR', 'HRV', '191', 'Croatia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Cuba', 'CU', 'CUB', '192', 'Cuba' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Cyprus', 'CY', 'CYP', '196', 'Cyprus' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Czech Republic', 'CZ', 'CZE', '203', 'Czech Republic' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Benin', 'BJ', 'BEN', '204', 'Benin' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Denmark', 'DK', 'DNK', '208', 'Denmark' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Dominica', 'DM', 'DMA', '212', 'Dominica' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Dominican Republic', 'DO', 'DOM', '214', 'Dominican Republic' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Ecuador', 'EC', 'ECU', '218', 'Ecuador' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'El Salvador', 'SV', 'SLV', '222', 'El Salvador' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Equatorial Guinea', 'GQ', 'GNQ', '226', 'Equatorial Guinea' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Ethiopia', 'ET', 'ETH', '231', 'Ethiopia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Eritrea', 'ER', 'ERI', '232', 'Eritrea' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Estonia', 'EE', 'EST', '233', 'Estonia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Faroe Islands', 'FO', 'FRO', '234', 'Faroe Islands' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Falkland Islands (Malvinas)', 'FK', 'FLK', '238', 'Falkland Islands (Malvinas)' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'South Georgia and the South Sandwich Islands', 'GS', 'SGS', '239', 'South Georgia and the South Sandwich Islands' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Fiji', 'FJ', 'FJI', '242', 'Fiji' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Finland', 'FI', 'FIN', '246', 'Finland' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Åland Islands', 'AX', 'ALA', '248', 'Åland Islands' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'France', 'FR', 'FRA', '250', 'France' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'French Guiana', 'GF', 'GUF', '254', 'French Guiana' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'French Polynesia', 'PF', 'PYF', '258', 'French Polynesia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'French Southern Territories', 'TF', 'ATF', '260', 'French Southern Territories' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Djibouti', 'DJ', 'DJI', '262', 'Djibouti' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Gabon', 'GA', 'GAB', '266', 'Gabon' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Georgia', 'GE', 'GEO', '268', 'Georgia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Gambia', 'GM', 'GMB', '270', 'Gambia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Palestine, State of', 'PS', 'PSE', '275', 'Palestine, State of' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Germany', 'DE', 'DEU', '276', 'Germany' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Ghana', 'GH', 'GHA', '288', 'Ghana' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Gibraltar', 'GI', 'GIB', '292', 'Gibraltar' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Kiribati', 'KI', 'KIR', '296', 'Kiribati' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Greece', 'GR', 'GRC', '300', 'Greece' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Greenland', 'GL', 'GRL', '304', 'Greenland' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Grenada', 'GD', 'GRD', '308', 'Grenada' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Guadeloupe', 'GP', 'GLP', '312', 'Guadeloupe' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Guam', 'GU', 'GUM', '316', 'Guam' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Guatemala', 'GT', 'GTM', '320', 'Guatemala' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Guinea', 'GN', 'GIN', '324', 'Guinea' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Guyana', 'GY', 'GUY', '328', 'Guyana' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Haiti', 'HT', 'HTI', '332', 'Haiti' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Heard Island and McDonald Islands', 'HM', 'HMD', '334', 'Heard Island and McDonald Islands' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Holy See (Vatican City State)', 'VA', 'VAT', '336', 'Holy See (Vatican City State)' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Honduras', 'HN', 'HND', '340', 'Honduras' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Hong Kong', 'HK', 'HKG', '344', 'Hong Kong' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Hungary', 'HU', 'HUN', '348', 'Hungary' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Iceland', 'IS', 'ISL', '352', 'Iceland' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'India', 'IN', 'IND', '356', 'India' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Indonesia', 'ID', 'IDN', '360', 'Indonesia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Iran, Islamic Republic of', 'IR', 'IRN', '364', 'Iran, Islamic Republic of' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Iraq', 'IQ', 'IRQ', '368', 'Iraq' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Ireland', 'IE', 'IRL', '372', 'Ireland' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Israel', 'IL', 'ISR', '376', 'Israel' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Italy', 'IT', 'ITA', '380', 'Italy' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Côte d''Ivoire', 'CI', 'CIV', '384', 'Côte d''Ivoire' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Jamaica', 'JM', 'JAM', '388', 'Jamaica' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Japan', 'JP', 'JPN', '392', 'Japan' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Kazakhstan', 'KZ', 'KAZ', '398', 'Kazakhstan' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Jordan', 'JO', 'JOR', '400', 'Jordan' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Kenya', 'KE', 'KEN', '404', 'Kenya' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Korea, Democratic People''s Republic of', 'KP', 'PRK', '408', 'Korea, Democratic People''s Republic of' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Korea, Republic of', 'KR', 'KOR', '410', 'Korea, Republic of' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Kuwait', 'KW', 'KWT', '414', 'Kuwait' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Kyrgyzstan', 'KG', 'KGZ', '417', 'Kyrgyzstan' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Lao People''s Democratic Republic', 'LA', 'LAO', '418', 'Lao People''s Democratic Republic' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Lebanon', 'LB', 'LBN', '422', 'Lebanon' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Lesotho', 'LS', 'LSO', '426', 'Lesotho' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Latvia', 'LV', 'LVA', '428', 'Latvia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Liberia', 'LR', 'LBR', '430', 'Liberia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Libya', 'LY', 'LBY', '434', 'Libya' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Liechtenstein', 'LI', 'LIE', '438', 'Liechtenstein' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Lithuania', 'LT', 'LTU', '440', 'Lithuania' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Luxembourg', 'LU', 'LUX', '442', 'Luxembourg' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Macao', 'MO', 'MAC', '446', 'Macao' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Madagascar', 'MG', 'MDG', '450', 'Madagascar' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Malawi', 'MW', 'MWI', '454', 'Malawi' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Malaysia', 'MY', 'MYS', '458', 'Malaysia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Maldives', 'MV', 'MDV', '462', 'Maldives' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Mali', 'ML', 'MLI', '466', 'Mali' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Malta', 'MT', 'MLT', '470', 'Malta' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Martinique', 'MQ', 'MTQ', '474', 'Martinique' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Mauritania', 'MR', 'MRT', '478', 'Mauritania' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Mauritius', 'MU', 'MUS', '480', 'Mauritius' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Mexico', 'MX', 'MEX', '484', 'Mexico' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Monaco', 'MC', 'MCO', '492', 'Monaco' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Mongolia', 'MN', 'MNG', '496', 'Mongolia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Moldova, Republic of', 'MD', 'MDA', '498', 'Moldova, Republic of' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Montenegro', 'ME', 'MNE', '499', 'Montenegro' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Montserrat', 'MS', 'MSR', '500', 'Montserrat' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Morocco', 'MA', 'MAR', '504', 'Morocco' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Mozambique', 'MZ', 'MOZ', '508', 'Mozambique' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Oman', 'OM', 'OMN', '512', 'Oman' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Namibia', 'NA', 'NAM', '516', 'Namibia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Nauru', 'NR', 'NRU', '520', 'Nauru' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Nepal', 'NP', 'NPL', '524', 'Nepal' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Netherlands', 'NL', 'NLD', '528', 'Netherlands' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Curaçao', 'CW', 'CUW', '531', 'Curaçao' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Aruba', 'AW', 'ABW', '533', 'Aruba' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Sint Maarten (Dutch part)', 'SX', 'SXM', '534', 'Sint Maarten (Dutch part)' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Bonaire, Sint Eustatius and Saba', 'BQ', 'BES', '535', 'Bonaire, Sint Eustatius and Saba' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'New Caledonia', 'NC', 'NCL', '540', 'New Caledonia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Vanuatu', 'VU', 'VUT', '548', 'Vanuatu' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'New Zealand', 'NZ', 'NZL', '554', 'New Zealand' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Nicaragua', 'NI', 'NIC', '558', 'Nicaragua' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Niger', 'NE', 'NER', '562', 'Niger' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Nigeria', 'NG', 'NGA', '566', 'Nigeria' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Niue', 'NU', 'NIU', '570', 'Niue' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Norfolk Island', 'NF', 'NFK', '574', 'Norfolk Island' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Norway', 'NO', 'NOR', '578', 'Norway' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Northern Mariana Islands', 'MP', 'MNP', '580', 'Northern Mariana Islands' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'United States Minor Outlying Islands', 'UM', 'UMI', '581', 'United States Minor Outlying Islands' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Micronesia, Federated States of', 'FM', 'FSM', '583', 'Micronesia, Federated States of' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Marshall Islands', 'MH', 'MHL', '584', 'Marshall Islands' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Palau', 'PW', 'PLW', '585', 'Palau' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Pakistan', 'PK', 'PAK', '586', 'Pakistan' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Panama', 'PA', 'PAN', '591', 'Panama' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Papua New Guinea', 'PG', 'PNG', '598', 'Papua New Guinea' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Paraguay', 'PY', 'PRY', '600', 'Paraguay' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Peru', 'PE', 'PER', '604', 'Peru' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Philippines', 'PH', 'PHL', '608', 'Philippines' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Pitcairn', 'PN', 'PCN', '612', 'Pitcairn' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Poland', 'PL', 'POL', '616', 'Poland' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Portugal', 'PT', 'PRT', '620', 'Portugal' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Guinea-Bissau', 'GW', 'GNB', '624', 'Guinea-Bissau' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Timor-Leste', 'TL', 'TLS', '626', 'Timor-Leste' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Puerto Rico', 'PR', 'PRI', '630', 'Puerto Rico' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Qatar', 'QA', 'QAT', '634', 'Qatar' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Réunion', 'RE', 'REU', '638', 'Réunion' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Romania', 'RO', 'ROU', '642', 'Romania' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Russian Federation', 'RU', 'RUS', '643', 'Russian Federation' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Rwanda', 'RW', 'RWA', '646', 'Rwanda' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Saint Barthélemy', 'BL', 'BLM', '652', 'Saint Barthélemy' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Saint Helena, Ascension and Tristan da Cunha', 'SH', 'SHN', '654', 'Saint Helena, Ascension and Tristan da Cunha' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Saint Kitts and Nevis', 'KN', 'KNA', '659', 'Saint Kitts and Nevis' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Anguilla', 'AI', 'AIA', '660', 'Anguilla' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Saint Lucia', 'LC', 'LCA', '662', 'Saint Lucia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Saint Martin (French part)', 'MF', 'MAF', '663', 'Saint Martin (French part)' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Saint Pierre and Miquelon', 'PM', 'SPM', '666', 'Saint Pierre and Miquelon' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Saint Vincent and the Grenadines', 'VC', 'VCT', '670', 'Saint Vincent and the Grenadines' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'San Marino', 'SM', 'SMR', '674', 'San Marino' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Sao Tome and Principe', 'ST', 'STP', '678', 'Sao Tome and Principe' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Saudi Arabia', 'SA', 'SAU', '682', 'Saudi Arabia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Senegal', 'SN', 'SEN', '686', 'Senegal' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Serbia', 'RS', 'SRB', '688', 'Serbia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Seychelles', 'SC', 'SYC', '690', 'Seychelles' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Sierra Leone', 'SL', 'SLE', '694', 'Sierra Leone' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Singapore', 'SG', 'SGP', '702', 'Singapore' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Slovakia', 'SK', 'SVK', '703', 'Slovakia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Viet Nam', 'VN', 'VNM', '704', 'Viet Nam' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Slovenia', 'SI', 'SVN', '705', 'Slovenia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Somalia', 'SO', 'SOM', '706', 'Somalia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'South Africa', 'ZA', 'ZAF', '710', 'South Africa' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Zimbabwe', 'ZW', 'ZWE', '716', 'Zimbabwe' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Spain', 'ES', 'ESP', '724', 'Spain' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'South Sudan', 'SS', 'SSD', '728', 'South Sudan' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Sudan', 'SD', 'SDN', '729', 'Sudan' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Western Sahara', 'EH', 'ESH', '732', 'Western Sahara' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Suriname', 'SR', 'SUR', '740', 'Suriname' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Svalbard and Jan Mayen', 'SJ', 'SJM', '744', 'Svalbard and Jan Mayen' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Swaziland', 'SZ', 'SWZ', '748', 'Swaziland' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Sweden', 'SE', 'SWE', '752', 'Sweden' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Switzerland', 'CH', 'CHE', '756', 'Switzerland' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Syrian Arab Republic', 'SY', 'SYR', '760', 'Syrian Arab Republic' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Tajikistan', 'TJ', 'TJK', '762', 'Tajikistan' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Thailand', 'TH', 'THA', '764', 'Thailand' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Togo', 'TG', 'TGO', '768', 'Togo' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Tokelau', 'TK', 'TKL', '772', 'Tokelau' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Tonga', 'TO', 'TON', '776', 'Tonga' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Trinidad and Tobago', 'TT', 'TTO', '780', 'Trinidad and Tobago' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'United Arab Emirates', 'AE', 'ARE', '784', 'United Arab Emirates' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Tunisia', 'TN', 'TUN', '788', 'Tunisia' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Turkey', 'TR', 'TUR', '792', 'Turkey' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Turkmenistan', 'TM', 'TKM', '795', 'Turkmenistan' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Turks and Caicos Islands', 'TC', 'TCA', '796', 'Turks and Caicos Islands' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Tuvalu', 'TV', 'TUV', '798', 'Tuvalu' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Uganda', 'UG', 'UGA', '800', 'Uganda' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Ukraine', 'UA', 'UKR', '804', 'Ukraine' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Macedonia, the Former Yugoslav Republic of', 'MK', 'MKD', '807', 'Macedonia, the Former Yugoslav Republic of' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Egypt', 'EG', 'EGY', '818', 'Egypt' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'United Kingdom', 'GB', 'GBR', '826', 'United Kingdom' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Guernsey', 'GG', 'GGY', '831', 'Guernsey' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Jersey', 'JE', 'JEY', '832', 'Jersey' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Isle of Man', 'IM', 'IMN', '833', 'Isle of Man' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Tanzania, United Republic of', 'TZ', 'TZA', '834', 'Tanzania, United Republic of' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'United States', 'US', 'USA', '840', 'United States' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Virgin Islands, U.S.', 'VI', 'VIR', '850', 'Virgin Islands, U.S.' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Burkina Faso', 'BF', 'BFA', '854', 'Burkina Faso' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Uruguay', 'UY', 'URY', '858', 'Uruguay' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Uzbekistan', 'UZ', 'UZB', '860', 'Uzbekistan' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Venezuela, Bolivarian Republic of', 'VE', 'VEN', '862', 'Venezuela, Bolivarian Republic of' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Wallis and Futuna', 'WF', 'WLF', '876', 'Wallis and Futuna' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Samoa', 'WS', 'WSM', '882', 'Samoa' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Yemen', 'YE', 'YEM', '887', 'Yemen' ,0)
	INSERT INTO [dbo].[LVAPP_ISOCOUNTRIES] ([ISOCODE],[COUNTRY],[ALPHA2],[ALPHA3],[NUMERIC3],[DESCRIPTION],[ACTIVE]) VALUES(1,'Zambia', 'ZM', 'ZMB', '894', 'Zambia' ,0)
	Print 'LVAPP_ISOCOUNTRIES table populated with defaults'

END;
GO

/*Declare local varaibles */
DECLARE @columnID INT = 0
DECLARE @ExistingTableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0

DECLARE @i INT = 0
DECLARE @NumDims INT = 0
DECLARE @Cnt VARCHAR(40)
DECLARE @SchedRollup VARCHAR(40)
DECLARE @MaxSubCat INT = 0
DECLARE @MaxSchedID INT = 0
DECLARE @MaxCat INT = 0
DECLARE @UpdateICStandard INT = 0

/* Install - Create Views - SQL Script */

IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'LV_SYMBOLDESCRIPTIONS'))
BEGIN
 EXECUTE('CREATE VIEW LV_SYMBOLDESCRIPTIONS AS SELECT dim.DIM_INDEX, dim.DIM_NAME, sym.SYM_INDEX, sym.SYM_NAME, des.LANG_CODE, des.DESCRIPTION
 FROM KLX_MASTER_SYMBOL sym, KLX_MASTER_DIM dim, KLX_SYM_DESC des
 WHERE sym.DIM_INDEX=dim.DIM_INDEX
 AND des.DESC_TYPE=1
 AND des.MAJOR_OBJ_ID=-1
 AND des.MINOR_OBJ_ID=dim.DIM_INDEX
 AND des.MICRO_OBJ_ID=sym.sym_index
 AND substring(sym.SYM_NAME,1,1) != ''_''');
	Print 'LV_SYMBOLDESCRIPTIONS View created'
END;
GO

/* VIEW LV_SYMBOLSTRINGATTRIBUTES */
IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'LV_SYMBOLSTRINGATTRIBUTES'))
BEGIN
	EXECUTE('CREATE VIEW LV_SYMBOLSTRINGATTRIBUTES AS SELECT attr.*, dim.DIM_NAME, sym.SYM_NAME, attrdefs.ATTR_NAME FROM
  (SELECT symattr.OBJ_ID/0x40000 AS ''DIM_INDEX'', symattr.OBJ_ID-(symattr.OBJ_ID/0x40000*0x40000) AS ''SYM_INDEX'', ITEM_NO, VALUE, ATTR_ID
   FROM KLX_SYMATTR_STRVAL symattr) attr,
  KLX_MASTER_DIM dim,
  KLX_MASTER_SYMBOL sym,
  KLX_ATTR_DEFS attrdefs
 WHERE attr.DIM_INDEX=dim.DIM_INDEX
 AND attr.DIM_INDEX=sym.DIM_INDEX
 AND attr.SYM_INDEX=sym.SYM_INDEX
 AND attrdefs.CLASS_ID=2
 AND attrdefs.ATTR_ID=attr.ATTR_ID
 AND substring(sym.SYM_NAME,1,1) != ''_''');
	Print 'LV_SYMBOLSTRINGATTRIBUTES View created'

END;
GO

/* VIEW LV_SYMBOLNUMERICATTRIBUTES */
IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'LV_SYMBOLNUMERICATTRIBUTES'))
BEGIN
	EXECUTE('CREATE VIEW LV_SYMBOLNUMERICATTRIBUTES AS  SELECT attr.*, dim.DIM_NAME, sym.SYM_NAME, attrdefs.ATTR_NAME FROM
  (SELECT symattr.OBJ_ID/0x40000 AS ''DIM_INDEX'', symattr.OBJ_ID-(symattr.OBJ_ID/0x40000*0x40000) AS ''SYM_INDEX'', ITEM_NO, VALUE, ATTR_ID
   FROM KLX_SYMATTR_NUMVAL symattr) attr,
  KLX_MASTER_DIM dim,
  KLX_MASTER_SYMBOL sym,
  KLX_ATTR_DEFS attrdefs
 WHERE attr.DIM_INDEX=dim.DIM_INDEX
 AND attr.DIM_INDEX=sym.DIM_INDEX
 AND attr.SYM_INDEX=sym.SYM_INDEX
 AND attrdefs.CLASS_ID=2
 AND attrdefs.ATTR_ID=attr.ATTR_ID
 AND substring(sym.SYM_NAME,1,1) != ''_''');
	Print 'LV_SYMBOLNUMERICATTRIBUTES View created'
 END;
GO

/*Declare local varaibles */
DECLARE @columnID INT = 0
DECLARE @ExistingTableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0

DECLARE @i INT = 0
DECLARE @NumDims INT = 0
DECLARE @Cnt VARCHAR(40)
DECLARE @SchedRollup VARCHAR(40)
DECLARE @MaxSubCat INT = 0
DECLARE @MaxSchedID INT = 0
DECLARE @MaxCat INT = 0
DECLARE @UpdateICStandard INT = 0

/* Base Task Admin Table */
/* Check if Table is registered*/
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_TASKS');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_TASKS', 0);
	PRINT 'LVAPP_TASKS table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_TASKS table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'ID', 'autointeger', '1')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'CATEGORY', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'DESCRIPTION', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (4, @tableID, 'DUE_DATE', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (5, @tableID, 'START_DATE', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (6, @tableID, 'COMPLETION_DATE', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (7, @tableID, 'TASK_PERIOD', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (8, @tableID, 'ENTITY', 'symbol', 'ENTITIES')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (9, @tableID, 'JURISDICTION_LEVEL', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (10, @tableID, 'JURISDICTION', 'symbol', 'DETAILS')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (11, @tableID, 'FORM', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (12, @tableID, 'TASK_TYPE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (13, @tableID, 'TASK_DUE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (14, @tableID, 'METHOD', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (15, @tableID, 'AMOUNT', 'number', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (16, @tableID, 'PROCESSED_DATE', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (17, @tableID, 'ADDRESS', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (18, @tableID, 'NOTES', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (19, @tableID, 'ATTACHMENTS', 'file', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (20, @tableID, 'OWNER', 'autouser', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (21, @tableID, 'WORKFLOW', 'boolean', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (22, @tableID, 'PREPARER', 'userlist', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (23, @tableID, 'REVIEWER', 'userlist', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (24, @tableID, 'APPROVER', 'userlist', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (25, @tableID, 'STATUS', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (26, @tableID, 'ASSIGNED', 'userlist', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (27, @tableID, 'STATUS_PROCESSING', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (28, @tableID, 'STATUS_NOTIFICATION', 'boolean', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (29, @tableID, 'REMINDER_LINK', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (30, @tableID, 'READ_ONLY', 'boolean', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (31, @tableID , 'RECURR_FREQUENCY', 'string', '');
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (32, @tableID , 'RECURR_DATE_DESC', 'string', '');
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (33, @tableID , 'RECURR_PERIOD', 'string', '');
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (34, @tableID , 'WFPROFILE', 'string', '');
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (35, @tableID , 'WFPROFILE_ENTITY', 'symbol', 'ENTITIES');

	PRINT 'LVAPP_TASKS Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_TASKS Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_TASKS')
	BEGIN
		PRINT 'LVAPP_TASKS table exists'
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
  CREATE TABLE [dbo].[LVAPP_TASKS](
	  [ID] [int] NOT NULL,
	  [CATEGORY] [varchar](255),
	  [DESCRIPTION] [varchar](4000),
	  [DUE_DATE] [datetime],
	  [START_DATE] [datetime],
	  [COMPLETION_DATE] [datetime],
	  [TASK_PERIOD] [varchar](100),
	  [ENTITY] [int] NOT NULL,
	  [JURISDICTION_LEVEL] [varchar](100) NOT NULL,
	  [JURISDICTION] [int],
	  [FORM] [varchar](255),
	  [TASK_TYPE] [varchar](100),
	  [TASK_DUE] [varchar](100),
	  [METHOD] [varchar](255),
	  [AMOUNT] [float] NOT NULL,
	  [PROCESSED_DATE] [datetime],
	  [ADDRESS] [varchar](255),
	  [NOTES] [varchar](4000),
	  [ATTACHMENTS] [varchar](100),
	  [OWNER] [int] NOT NULL,
	  [WORKFLOW] [int] NOT NULL,
	  [PREPARER] [varchar](4000),
	  [REVIEWER] [varchar](4000),
	  [APPROVER] [varchar](4000),
	  [ASSIGNED] [varchar](4000),
	  [STATUS] [varchar](100) NOT NULL,
	  [STATUS_PROCESSING] [varchar](100),
	  [STATUS_NOTIFICATION] [int] NOT NULL,
	  [REMINDER_LINK] [varchar](255),
	  [READ_ONLY] [int] NOT NULL,
	  [RECURR_FREQUENCY] [varchar](100), 
	  [RECURR_DATE_DESC] [varchar](800), 
	  [RECURR_PERIOD] [varchar](100), 
	  [WFPROFILE] [varchar](800), 
	  [WFPROFILE_ENTITY] [int],
	  CONSTRAINT pk_LVAPP_TASKS PRIMARY KEY (ID)
  ) ON [KLX_BASE_DAT]
	SET ANSI_PADDING OFF
	Print 'LVAPP_TASKS table created'
END; 

/* Task Reminders */
/* Check if Table is registered*/
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_TASKREMINDERS');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_TASKREMINDERS', 0);
	PRINT 'LVAPP_TASKREMINDERS table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_TASKREMINDERS table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'ID', 'autointeger','1')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'DESCRIPTION', 'string','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'NOTICE_TYPE', 'string','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (4, @tableID, 'NOTICE_DAY', 'number','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (5, @tableID, 'CHANGE_FIELD', 'string','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (6, @tableID, 'EMAIL_SUBJECT', 'string','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (7, @tableID, 'EMAIL_BODY', 'string','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (8, @tableID, 'EMAIL_ALLLONGVIEW', 'boolean','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (9, @tableID, 'EMAIL_SPECIFIC', 'userlist','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (10, @tableID, 'EMAIL_OTHER', 'string','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (11, @tableID, 'EMAIL_ALLPREPARERS', 'boolean','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (12, @tableID, 'EMAIL_ALLREVIEWERS', 'boolean','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (13, @tableID, 'EMAIL_ALLAPPROVERS', 'boolean','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (14, @tableID, 'EMAIL_ALLASSIGNED', 'boolean', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (15, @tableID, 'STATUS_FILTER', 'string','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (16, @tableID, 'REMINDER_CATEGORY', 'string','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (17, @tableID, 'DAILY_RECURRENCE', 'boolean','')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (18, @tableID, 'EMAIL_TO', 'string','')
	PRINT 'LVAPP_TASKREMINDERS Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_TASKREMINDERS Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_TASKREMINDERS')
	BEGIN
		PRINT 'LVAPP_TASKREMINDERS table exists'
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
  CREATE TABLE [dbo].[LVAPP_TASKREMINDERS](
  	  [ID] [int] NOT NULL,
	  [DESCRIPTION] [varchar](100) NULL,
	  [NOTICE_TYPE] [varchar](100) NULL,
	  [NOTICE_DAY] [float] NOT NULL,
	  [CHANGE_FIELD] [varchar](100) NULL,
	  [EMAIL_SUBJECT] [varchar](255) NULL,
	  [EMAIL_BODY] [varchar](4000) NULL,
	  [EMAIL_ALLLONGVIEW] [int] NOT NULL,
	  [EMAIL_SPECIFIC] [varchar](4000) NULL,
	  [EMAIL_OTHER] [varchar](4000) NULL,
	  [EMAIL_ALLPREPARERS] [int] NOT NULL,
	  [EMAIL_ALLREVIEWERS] [int] NOT NULL,
	  [EMAIL_ALLAPPROVERS] [int] NOT NULL,
	  [EMAIL_ALLASSIGNED] [int] NOT NULL,
	  [STATUS_FILTER] [varchar](200) NULL,
	  [REMINDER_CATEGORY] [varchar](4000) NULL,
	  [DAILY_RECURRENCE] [int] NULL,
	  [EMAIL_TO] [varchar](4000) NULL,
	  CONSTRAINT pk_LVAPP_TASKREMINDERS PRIMARY KEY (ID)
  ) ON [KLX_BASE_DAT]
	SET ANSI_PADDING OFF
	Print 'LVAPP_TASKREMINDERS table created'
END; 


/* Recurrence Calendar */
/* Check if Table is registered*/
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_RECURRENCE');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_RECURRENCE', 0);
	PRINT 'LVAPP_RECURRENCE table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_RECURRENCE table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'FREQUENCY', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'DATE_DESCRIPTION', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'PERIOD_1', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (4, @tableID, 'PERIOD_2', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (5, @tableID, 'PERIOD_3', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (6, @tableID, 'PERIOD_4', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (7, @tableID, 'PERIOD_5', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (8, @tableID, 'PERIOD_6', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (9, @tableID, 'PERIOD_7', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (10, @tableID, 'PERIOD_8', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (11, @tableID, 'PERIOD_9', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (12, @tableID, 'PERIOD_10', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (13, @tableID, 'PERIOD_11', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (14, @tableID, 'PERIOD_12', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (15, @tableID, 'PERIOD_13', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (16, @tableID, 'PERIOD_14', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (17, @tableID, 'PERIOD_15', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (18, @tableID, 'PERIOD_16', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (19, @tableID, 'PERIOD_17', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (20, @tableID, 'PERIOD_18', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (21, @tableID, 'PERIOD_19', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (22, @tableID, 'PERIOD_20', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (23, @tableID, 'PERIOD_21', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (24, @tableID, 'PERIOD_22', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (25, @tableID, 'PERIOD_23', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (26, @tableID, 'PERIOD_24', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (27, @tableID, 'PERIOD_25', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (28, @tableID, 'PERIOD_26', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (29, @tableID, 'PERIOD_27', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (30, @tableID, 'PERIOD_28', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (31, @tableID, 'PERIOD_29', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (32, @tableID, 'PERIOD_30', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (33, @tableID, 'PERIOD_31', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (34, @tableID, 'PERIOD_32', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (35, @tableID, 'PERIOD_33', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (36, @tableID, 'PERIOD_34', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (37, @tableID, 'PERIOD_35', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (38, @tableID, 'PERIOD_36', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (39, @tableID, 'PERIOD_37', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (40, @tableID, 'PERIOD_38', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (41, @tableID, 'PERIOD_39', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (42, @tableID, 'PERIOD_40', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (43, @tableID, 'PERIOD_41', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (44, @tableID, 'PERIOD_42', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (45, @tableID, 'PERIOD_43', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (46, @tableID, 'PERIOD_44', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (47, @tableID, 'PERIOD_45', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (48, @tableID, 'PERIOD_46', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (49, @tableID, 'PERIOD_47', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (50, @tableID, 'PERIOD_48', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (51, @tableID, 'PERIOD_49', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (52, @tableID, 'PERIOD_50', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (53, @tableID, 'PERIOD_51', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (54, @tableID, 'PERIOD_52', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (55, @tableID, 'PERIOD_53', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (56, @tableID, 'PUSH_UPDATE', 'boolean', '')
	PRINT 'LVAPP_RECURRENCE Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_RECURRENCE Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_RECURRENCE')
	BEGIN
		PRINT 'LVAPP_RECURRENCE table exists'
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
	CREATE TABLE [dbo].[LVAPP_RECURRENCE](
		[FREQUENCY] [varchar](100)  NOT NULL,
		[DATE_DESCRIPTION] [varchar](800) NOT NULL,
		[PERIOD_1] [datetime] NULL,
		[PERIOD_2] [datetime] NULL,
		[PERIOD_3] [datetime] NULL,
		[PERIOD_4] [datetime] NULL,
		[PERIOD_5] [datetime] NULL,
		[PERIOD_6] [datetime] NULL,
		[PERIOD_7] [datetime] NULL,
		[PERIOD_8] [datetime] NULL,
		[PERIOD_9] [datetime] NULL,
		[PERIOD_10] [datetime] NULL,
		[PERIOD_11] [datetime] NULL,
		[PERIOD_12] [datetime] NULL,
		[PERIOD_13] [datetime] NULL,
		[PERIOD_14] [datetime] NULL,
		[PERIOD_15] [datetime] NULL,
		[PERIOD_16] [datetime] NULL,
		[PERIOD_17] [datetime] NULL,
		[PERIOD_18] [datetime] NULL,
		[PERIOD_19] [datetime] NULL,
		[PERIOD_20] [datetime] NULL,
		[PERIOD_21] [datetime] NULL,
		[PERIOD_22] [datetime] NULL,
		[PERIOD_23] [datetime] NULL,
		[PERIOD_24] [datetime] NULL,
		[PERIOD_25] [datetime] NULL,
		[PERIOD_26] [datetime] NULL,
		[PERIOD_27] [datetime] NULL,
		[PERIOD_28] [datetime] NULL,
		[PERIOD_29] [datetime] NULL,
		[PERIOD_30] [datetime] NULL,
		[PERIOD_31] [datetime] NULL,
		[PERIOD_32] [datetime] NULL,
		[PERIOD_33] [datetime] NULL,
		[PERIOD_34] [datetime] NULL,
		[PERIOD_35] [datetime] NULL,
		[PERIOD_36] [datetime] NULL,
		[PERIOD_37] [datetime] NULL,
		[PERIOD_38] [datetime] NULL,
		[PERIOD_39] [datetime] NULL,
		[PERIOD_40] [datetime] NULL,
		[PERIOD_41] [datetime] NULL,
		[PERIOD_42] [datetime] NULL,
		[PERIOD_43] [datetime] NULL,
		[PERIOD_44] [datetime] NULL,
		[PERIOD_45] [datetime] NULL,
		[PERIOD_46] [datetime] NULL,
		[PERIOD_47] [datetime] NULL,
		[PERIOD_48] [datetime] NULL,
		[PERIOD_49] [datetime] NULL,
		[PERIOD_50] [datetime] NULL,
		[PERIOD_51] [datetime] NULL,
		[PERIOD_52] [datetime] NULL,
		[PERIOD_53] [datetime] NULL,
		[PUSH_UPDATE] [int] NOT NULL,
		CONSTRAINT pk_LVAPP_RECURRENCE PRIMARY KEY (FREQUENCY,DATE_DESCRIPTION)
	) ON [KLX_BASE_DAT]
	SET ANSI_PADDING OFF
	Print 'LVAPP_RECURRENCE table created'
END; 

/* WORKFLOW PROFILE Calendar */

/* Check if Table is registered*/
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_WFPROFILE');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_WFPROFILE', 0);
	PRINT 'LVAPP_WFPROFILE table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_WFPROFILE table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'PROFILE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'SCOPE_ENTITY', 'SYMBOL', 'ENTITIES')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'PREPARER', 'USERLIST', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (4, @tableID, 'REVIEWER', 'USERLIST', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (5, @tableID, 'APPROVER', 'USERLIST', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (6, @tableID, 'ASSIGNED', 'USERLIST', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (7, @tableID, 'PUSH_UPDATE', 'boolean', '')
	PRINT 'LVAPP_WFPROFILE Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_WFPROFILE Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_WFPROFILE')
	BEGIN
		PRINT 'LVAPP_WFPROFILE table exists'
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
	CREATE TABLE [dbo].[LVAPP_WFPROFILE](
		[PROFILE] [varchar](800)  NOT NULL,
		[SCOPE_ENTITY] [int] NOT NULL,
		[PREPARER] [varchar](4000) NULL,
		[REVIEWER] [varchar](4000) NULL,
		[APPROVER] [varchar](4000) NULL,
		[ASSIGNED] [varchar](4000) NULL,
		[PUSH_UPDATE] [int] NOT NULL,
		CONSTRAINT pk_LVAPP_WFPROFILE PRIMARY KEY (PROFILE,SCOPE_ENTITY)
	) ON [KLX_BASE_DAT]
	SET ANSI_PADDING OFF
	Print 'LVAPP_WFPROFILE table created'
END; 

/* Base Task Template Table */
/* Check if Table is registered*/
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_TASKTEMPLATE');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_TASKTEMPLATE', 0);
	PRINT 'LVAPP_TASKTEMPLATE table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_TASKTEMPLATE table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'ID', 'AUTOINTEGER', '1')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'TASK_GROUPING', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'CATEGORY', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (4, @tableID, 'DESCRIPTION', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (5, @tableID, 'FREQUENCY', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (6, @tableID, 'RECURRENCE_LINE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (7, @tableID, 'START_DATE', 'number', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (8, @tableID, 'ENTITY', 'symbol', 'ENTITIES')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (9, @tableID, 'ENTITY_DEPTH', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (10, @tableID, 'WORKFLOW_PROFILE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (11, @tableID, 'WORKFLOW', 'BOOLEAN', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (12, @tableID, 'PREPARER', 'USERLIST', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (13, @tableID, 'REVIEWER', 'USERLIST', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (14, @tableID, 'APPROVER', 'USERLIST', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (15, @tableID, 'ASSIGNED', 'USERLIST', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (16, @tableID, 'JURISDICTION_LEVEL', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (17, @tableID, 'JURISDICTION', 'symbol', 'DETAILS')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (18, @tableID, 'FORM', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (19, @tableID, 'TASK_TYPE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (20, @tableID, 'ADDRESS', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (21, @tableID, 'NOTES', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (22, @tableID, 'STATUS_NOTIFICATION', 'BOOLEAN', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (23, @tableID, 'REMINDER_LINK', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (24, @tableID, 'TASK_PERIOD', 'string', '')
	PRINT 'LVAPP_TASKTEMPLATE Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_TASKTEMPLATE Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_TASKTEMPLATE')
	BEGIN
		PRINT 'LVAPP_TASKTEMPLATE table exists'
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
  CREATE TABLE [dbo].[LVAPP_TASKTEMPLATE](
    [ID] [Int] NOT NULL,
    [TASK_GROUPING] [varchar](800) NOT NULL,
    [CATEGORY] [varchar](255) ,
    [DESCRIPTION] [varchar](4000) ,
    [FREQUENCY] [varchar](100) NOT NULL,
    [RECURRENCE_LINE] [varchar](800) ,
    [START_DATE] [float] ,
    [ENTITY] [int] NOT NULL,
    [ENTITY_DEPTH] [varchar](5) NOT NULL,
    [WORKFLOW_PROFILE] [varchar](800) ,
    [WORKFLOW] [Int] NOT NULL,
    [PREPARER] [varchar](4000) ,
    [REVIEWER] [varchar](4000) ,
    [APPROVER] [varchar](4000) ,
    [ASSIGNED] [varchar](4000) ,
    [JURISDICTION_LEVEL] [varchar](100) NOT NULL,
    [JURISDICTION] [Int] ,
    [FORM] [Varchar](255) ,
    [TASK_TYPE] [varchar](100) ,
    [ADDRESS] [varchar](255) ,
    [NOTES] [varchar](4000) ,
    [STATUS_NOTIFICATION] [int] NOT NULL,
    [REMINDER_LINK] [varchar](255) ,
    [TASK_PERIOD] [varchar](100) NOT NULL,
	  CONSTRAINT pk_LVAPP_TASKTEMPLATE PRIMARY KEY (ID)
  ) ON [KLX_BASE_DAT]
	SET ANSI_PADDING OFF
	Print 'LVAPP_TASKTEMPLATE table created'
END; 

/* Base Task Generation Table */
/* Check if Table is registered*/
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_TASKGENERATE');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_TASKGENERATE', 0);
	PRINT 'LVAPP_TASKGENERATE table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_TASKGENERATE table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'TASKGEN_ID', 'AUTOINTEGER', '1')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'TASK_GROUPING', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'FREQUENCY', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (4, @tableID, 'DATERANGE_START', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (5, @tableID, 'DATERANGE_END', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (6, @tableID, 'APPLY_ENTITIES', 'symbol', 'ENTITIES')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (7, @tableID, 'TASK_PERIOD', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (8, @tableID, 'TASKGEN_APPLY', 'BOOLEAN', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (9, @tableID, 'LAST_RUN', 'string', '')
	PRINT 'LVAPP_TASKGENERATE Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_TASKGENERATE Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_TASKGENERATE')
	BEGIN
		PRINT 'LVAPP_TASKGENERATE table exists'
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
  CREATE TABLE [dbo].[LVAPP_TASKGENERATE](
    [TASKGEN_ID] [Int] NOT NULL,
    [TASK_GROUPING] [varchar](800) NOT NULL,
    [FREQUENCY] [varchar](100) NOT NULL,
    [DATERANGE_START] [varchar](20) NOT NULL,
    [DATERANGE_END] [varchar](20) ,
    [APPLY_ENTITIES] [int] ,
    [TASK_PERIOD] [varchar](100) ,
    [TASKGEN_APPLY] [int] NOT NULL,
    [LAST_RUN] [varchar](200) ,
	  CONSTRAINT pk_LVAPP_TASKGENERATE PRIMARY KEY (TASKGEN_ID)
  ) ON [KLX_BASE_DAT]
	SET ANSI_PADDING OFF
	Print 'LVAPP_TASKGENERATE table created'
END;

/* Install - Create Views - For Task Mangement Support - SQL Script */

IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'LV_VIEW_TASKUSERROLES'))
BEGIN
	EXECUTE('CREATE VIEW LV_VIEW_TASKUSERROLES AS SELECT T1.ID, T2.singleUser AS ''User'', ''Preparer'' AS ''Role''
 FROM
 (
  SELECT tasks.*,
  CAST(replace(replace(tasks.PREPARER,''('',''<X>''),'')'',''</X>'') as XML) as my_Xml 
  FROM LVAPP_TASKS tasks,
  KLX_MASTER_SYMBOL sym1,
  KLX_MASTER_SYMBOL sym2
  WHERE sym1.DIM_INDEX=2 AND sym1.SYM_INDEX=tasks.ENTITY AND substring(sym1.SYM_NAME,1,1)!=''_''
  AND sym2.DIM_INDEX=3 AND sym2.SYM_INDEX=tasks.JURISDICTION AND substring(sym2.SYM_NAME,1,1)!=''_''
 ) T1
 CROSS APPLY
 ( 
  SELECT U.USER_NAME as singleUser
  FROM T1.my_Xml.nodes(''X'') as my_Data(D), LV_USER_MAIN U
  WHERE U.USER_ID=my_Data.D.value(''.'',''int'')
 ) T2
UNION
 SELECT T1.ID, T2.singleUser AS ''User'', ''Reviewer'' AS ''Role''
 FROM
 (
  SELECT tasks.*,
  CAST(replace(replace(tasks.REVIEWER,''('',''<X>''),'')'',''</X>'') as XML) as my_Xml 
  FROM LVAPP_TASKS tasks,
  KLX_MASTER_SYMBOL sym1,
  KLX_MASTER_SYMBOL sym2
  WHERE sym1.DIM_INDEX=2 AND sym1.SYM_INDEX=tasks.ENTITY AND substring(sym1.SYM_NAME,1,1)!=''_''
  AND sym2.DIM_INDEX=3 AND sym2.SYM_INDEX=tasks.JURISDICTION AND substring(sym2.SYM_NAME,1,1)!=''_''
 ) T1
 CROSS APPLY
 ( 
  SELECT U.USER_NAME as singleUser
  FROM T1.my_Xml.nodes(''X'') as my_Data(D), LV_USER_MAIN U
  WHERE U.USER_ID=my_Data.D.value(''.'',''int'')
 ) T2
UNION
 SELECT T1.ID, T2.singleUser AS ''User'', ''Approver'' AS ''Role''
 FROM
 (
  SELECT tasks.*,
  CAST(replace(replace(tasks.APPROVER,''('',''<X>''),'')'',''</X>'') as XML) as my_Xml 
  FROM LVAPP_TASKS tasks,
  KLX_MASTER_SYMBOL sym1,
  KLX_MASTER_SYMBOL sym2
  WHERE sym1.DIM_INDEX=2 AND sym1.SYM_INDEX=tasks.ENTITY AND substring(sym1.SYM_NAME,1,1)!=''_''
  AND sym2.DIM_INDEX=3 AND sym2.SYM_INDEX=tasks.JURISDICTION AND substring(sym2.SYM_NAME,1,1)!=''_''
 ) T1
 CROSS APPLY
 ( 
  SELECT U.USER_NAME as singleUser
  FROM T1.my_Xml.nodes(''X'') as my_Data(D), LV_USER_MAIN U
  WHERE U.USER_ID=my_Data.D.value(''.'',''int'')
 ) T2
UNION
 SELECT T1.ID, T2.singleUser AS ''User'', ''Assigned'' AS ''Role''
 FROM
 (
  SELECT tasks.*,
  CAST(replace(replace(tasks.ASSIGNED,''('',''<X>''),'')'',''</X>'') as XML) as my_Xml 
  FROM LVAPP_TASKS tasks,
  KLX_MASTER_SYMBOL sym1,
  KLX_MASTER_SYMBOL sym2
  WHERE sym1.DIM_INDEX=2 AND sym1.SYM_INDEX=tasks.ENTITY AND substring(sym1.SYM_NAME,1,1)!=''_''
  AND sym2.DIM_INDEX=3 AND sym2.SYM_INDEX=tasks.JURISDICTION AND substring(sym2.SYM_NAME,1,1)!=''_''
 ) T1
 CROSS APPLY
 ( 
  SELECT U.USER_NAME as singleUser
  FROM T1.my_Xml.nodes(''X'') as my_Data(D), LV_USER_MAIN U
  WHERE U.USER_ID=my_Data.D.value(''.'',''int'')
 ) T2')

END;

IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'LV_VIEW_TASKS'))
BEGIN
	EXECUTE('CREATE VIEW LV_VIEW_TASKS AS 
 SELECT
  tasks.*, 
  sym1.SYM_NAME as ''ENTITY_NAME'',
  symDesc1.DESCRIPTION as ''ENTITY_DESCRIPTION'',
  sym2.SYM_NAME as ''JURISDICTION_NAME'',
  symDesc2.DESCRIPTION as ''JURISDICTION_DESCRIPTION'',
  symAttr1.VALUE as ''COUNTRY_CODE'',
  symAttr2.VALUE as ''COUNTRY''
FROM
  LVAPP_TASKS tasks,
  KLX_MASTER_SYMBOL sym1,
  KLX_SYM_DESC symDesc1, 
  KLX_MASTER_SYMBOL sym2,
  KLX_SYM_DESC symDesc2,
  KLX_ATTR_DEFS attr1,
  KLX_SYMATTR_STRVAL symAttr1,
  KLX_ATTR_DEFS attr2,
  KLX_SYMATTR_STRVAL symAttr2
 WHERE
  sym1.DIM_INDEX=2 AND sym1.SYM_INDEX=tasks.ENTITY AND substring(sym1.SYM_NAME,1,1)!=''_''
  AND symDesc1.DESC_TYPE=1 AND symDesc1.MAJOR_OBJ_ID=-1 AND symDesc1.MINOR_OBJ_ID=sym1.DIM_INDEX AND symDesc1.MICRO_OBJ_ID=sym1.SYM_INDEX AND symDesc1.LANG_CODE=''EN''
  AND sym2.DIM_INDEX=3 AND sym2.SYM_INDEX=tasks.JURISDICTION AND substring(sym2.SYM_NAME,1,1)!=''_''
  AND symDesc2.DESC_TYPE=1 AND symDesc2.MAJOR_OBJ_ID=-1 AND symDesc2.MINOR_OBJ_ID=sym2.DIM_INDEX AND symDesc2.MICRO_OBJ_ID=sym2.SYM_INDEX AND symDesc2.LANG_CODE=''EN''
  AND attr1.ATTR_NAME=''AZTaxEntityCountry''
  AND symAttr1.ATTR_ID=attr1.ATTR_ID AND symAttr1.OBJ_ID=(2*0x40000)+tasks.ENTITY
  AND attr2.ATTR_NAME=''AZTaxEntityCountryDescription''
  AND symAttr2.ATTR_ID=attr2.ATTR_ID AND symAttr2.OBJ_ID=(2*0x40000)+tasks.ENTITY')
END; 

/* LV_VIEW_TASKS */
/* Check if Table is registered*/
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LV_VIEW_TASKS');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LV_VIEW_TASKS', 0);
	PRINT 'LV_VIEW_TASKS table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LV_VIEW_TASKS table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'ID', 'autointeger', '1')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'CATEGORY', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'DESCRIPTION', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (4, @tableID, 'DUE_DATE', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (5, @tableID, 'START_DATE', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (6, @tableID, 'COMPLETION_DATE', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (7, @tableID, 'TASK_PERIOD', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (8, @tableID, 'ENTITY', 'symbol', 'ENTITIES')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (9, @tableID, 'JURISDICTION_LEVEL', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (10, @tableID, 'JURISDICTION', 'symbol', 'DETAILS')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (11, @tableID, 'FORM', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (12, @tableID, 'TASK_TYPE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (13, @tableID, 'TASK_DUE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (14, @tableID, 'METHOD', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (15, @tableID, 'AMOUNT', 'number', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (16, @tableID, 'PROCESSED_DATE', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (17, @tableID, 'ADDRESS', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (18, @tableID, 'NOTES', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (19, @tableID, 'ATTACHMENTS', 'file', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (20, @tableID, 'OWNER', 'autouser', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (21, @tableID, 'WORKFLOW', 'boolean', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (22, @tableID, 'PREPARER', 'userlist', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (23, @tableID, 'REVIEWER', 'userlist', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (24, @tableID, 'APPROVER', 'userlist', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (25, @tableID, 'ASSIGNED', 'userlist', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (26, @tableID, 'STATUS', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (27, @tableID, 'STATUS_PROCESSING', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (28, @tableID, 'STATUS_NOTIFICATION', 'boolean', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (29, @tableID, 'REMINDER_LINK', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (30, @tableID, 'READ_ONLY', 'boolean', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (31, @tableID , 'RECURR_FREQUENCY', 'string', '');
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (32, @tableID , 'RECURR_DATE_DESC', 'string', '');
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (33, @tableID , 'RECURR_PERIOD', 'string', '');
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (34, @tableID , 'WFPROFILE', 'string', '');
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (35, @tableID , 'WFPROFILE_ENTITY', 'symbol', 'ENTITIES');
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (36, @tableID, 'ENTITY_NAME', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (37, @tableID, 'ENTITY_DESCRIPTION', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (38, @tableID, 'JURISDICTION_NAME', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (39, @tableID, 'JURISDICTION_DESCRIPTION', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (40, @tableID, 'COUNTRY_CODE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (41, @tableID, 'COUNTRY', 'string', '')
	PRINT 'LV_VIEW_TASKS Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LV_VIEW_TASKS Columns have been previously registered'
END;

/* LV_VIEW_TASKUSERROLES */
/* Check if Table is registered*/
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LV_VIEW_TASKUSERROLES');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LV_VIEW_TASKUSERROLES', 0);
	PRINT 'LV_VIEW_TASKUSERROLES table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LV_VIEW_TASKUSERROLES table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'ID', 'autointeger', '1')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'User', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'Role', 'string', '')
	PRINT 'LV_VIEW_TASKUSERROLES Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LV_VIEW_TASKUSERROLES Columns have been previously registered'
END;
GO

/*Declare local varaibles */
DECLARE @columnID INT = 0
DECLARE @ExistingTableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0

DECLARE @i INT = 0
DECLARE @NumDims INT = 0
DECLARE @Cnt VARCHAR(40)
DECLARE @SchedRollup VARCHAR(40)
DECLARE @MaxSubCat INT = 0
DECLARE @MaxSchedID INT = 0
DECLARE @MaxCat INT = 0
DECLARE @UpdateICStandard INT = 0

/* CBC XML */
/* Check if Table is registered*/
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_CBC_XML');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_CBC_XML', 0);
	PRINT 'LVAPP_CBC_XML table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_CBC_XML table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'ID', 'autointeger', '1')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'PERIOD', 'symbol', 'TIMEPER')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'ENTITY', 'symbol', 'ENTITIES')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (4, @tableID, 'FILINGAGENCY', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (5, @tableID, 'LAST_MESSAGEREFID', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (6, @tableID, 'TIMESTAMP', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (7, @tableID, 'LASTFILETYPE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (8, @tableID, 'SENDINGENTITYIN', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (9, @tableID, 'MESSAGETYPE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (10, @tableID, 'LANGUAGETAG', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (11, @tableID, 'WARNINGTEXT', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (12, @tableID, 'CONTACTINFO', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (13, @tableID, 'MESSAGEREFERENCEID', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (14, @tableID, 'FILINGINSTANCE', 'number', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (15, @tableID, 'REPORTINGROLE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (16, @tableID, 'REPORTINGCOUNTRYCODE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (17, @tableID, 'TRANSMITTINGCOUNTRY', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (18, @tableID, 'REDOCTYPEINDIC', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (19, @tableID, 'REDOCREFID', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (20, @tableID, 'RDOCTYPEINDIC', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (21, @tableID, 'RDOCREFID', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (22, @tableID, 'AIDOCTYPEINDIC', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (23, @tableID, 'AIDOCREFID', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (24, @tableID, 'SUBMISSIONFILENAME', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (25, @tableID, 'REPORTINGPERIOD', 'date', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (26, @tableID, 'CERTIFICATIONNAME', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (27, @tableID, 'CERTIFICATIONPOSITION', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (28, @tableID, 'CERTIFICATIONOTHER', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (29, @tableID, 'CONTACTNAME', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (30, @tableID, 'CONTACTPOSITION', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (31, @tableID, 'CONTACTOTHER', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (32, @tableID, 'COTYPE', 'string', '')
  INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (33, @tableID, 'FILESUBMITTED', 'boolean', '')
	PRINT 'LVAPP_CBC_XML Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_CBC_XML Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_CBC_XML')
	BEGIN
		PRINT 'LVAPP_CBC_XML table exists'
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
  CREATE TABLE [dbo].[LVAPP_CBC_XML](
	  [ID] [int] NOT NULL,
	  [PERIOD] [int] NOT NULL,
	  [ENTITY] [int] NOT NULL,
	  [FILINGAGENCY] [varchar](50),
	  [LAST_MESSAGEREFID] [varchar](50),
	  [TIMESTAMP] [varchar](100),
	  [LASTFILETYPE] [varchar](10),
	  [SENDINGENTITYIN] [varchar](100),
	  [MESSAGETYPE] [varchar](10),
	  [LANGUAGETAG] [varchar](10),
	  [WARNINGTEXT] [varchar](4000),
	  [CONTACTINFO] [varchar](500),
	  [MESSAGEREFERENCEID] [varchar](50),
	  [FILINGINSTANCE] [float],
	  [REPORTINGROLE] [varchar](10),
	  [REPORTINGCOUNTRYCODE] [varchar](10),
	  [TRANSMITTINGCOUNTRY] [varchar](10),
	  [REDOCTYPEINDIC] [varchar](100),
	  [REDOCREFID] [varchar](100),
	  [RDOCTYPEINDIC] [varchar](100),
	  [RDOCREFID] [varchar](100),
	  [AIDOCTYPEINDIC] [varchar](100),
	  [AIDOCREFID] [varchar](100),
	  [SUBMISSIONFILENAME] [varchar](100),
	  [REPORTINGPERIOD] [datetime],
	  [CERTIFICATIONNAME] [varchar](200),
	  [CERTIFICATIONPOSITION] [varchar](200),
	  [CERTIFICATIONOTHER] [varchar](200),
	  [CONTACTNAME] [varchar](200),
	  [CONTACTPOSITION] [varchar](200),
	  [CONTACTOTHER] [varchar](200),
	  [COTYPE] [varchar](200),
	  [FILESUBMITTED] [int] NOT NULL,
	  CONSTRAINT pk_LVAPP_CBC_XML PRIMARY KEY (ID)
  ) ON [KLX_BASE_DAT]
	SET ANSI_PADDING OFF
	Print 'LVAPP_CBC_XML table created'
END; 
GO

/*Declare local varaibles */
DECLARE @columnID INT = 0
DECLARE @ExistingTableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0

DECLARE @i INT = 0
DECLARE @NumDims INT = 0
DECLARE @Cnt VARCHAR(40)
DECLARE @SchedRollup VARCHAR(40)
DECLARE @MaxSubCat INT = 0
DECLARE @MaxSchedID INT = 0
DECLARE @MaxCat INT = 0
DECLARE @UpdateICStandard INT = 0

/* Various Updates */
UPDATE KLX_ATTR_DEFS SET Attr_Name = 'STaxEntitiesHierarchies' WHERE Attr_Name = 'STaxEntityHierarchies';

/*update group access*/

BEGIN
IF EXISTS (SELECT * FROM [dbo].[KLX_JE_SUBCATEGORIES] WHERE JE_CATEGORY = 'S')
	Set @MaxSubCat = (SELECT (MAX(SUB_CATEGORY)) FROM [dbo].[KLX_JE_SUBCATEGORIES])
	
	IF @MaxSubCat < 200 
		SET @MaxSubCat = 200
END;

/*Create NCI Schedule*/
Set @MaxSchedID = (SELECT MAX(SCHEDULE_ID) FROM KLX_SCHEDULES)

IF NOT EXISTS (SELECT SCHEDULE_ID FROM [dbo].[KLX_SCHEDULES] WHERE SCHEDULE_NAME = 'NCI')
BEGIN
	Set @MaxSchedID = @MaxSchedID + 1
	INSERT INTO [dbo].[KLX_SCHEDULES] VALUES(@MaxSchedID,'NCI',1,'B:1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16')
	INSERT INTO [dbo].[KLX_SCHED_DIMS] VALUES (@MaxSchedID,0,'Subsidiaries',4,'ENTITIES;ZElimAllowICTransactions=TRUE',17,'')	

	DELETE FROM [dbo].[KLX_DESC] where MAJOR_OBJ_ID = @MaxSchedId AND DESC_TYPE = 5
	INSERT INTO [dbo].[KLX_DESC] VALUES(5,'EN', @MaxSchedID,-1,-1,'Non-Controlling Interests')	  
END;

/*Create ICSource Schedule*/
IF NOT EXISTS (SELECT SCHEDULE_ID FROM [dbo].[KLX_SCHEDULES] WHERE SCHEDULE_NAME = 'ICSource')
BEGIN
	Set @MaxSchedID = @MaxSchedID + 1
	INSERT INTO [dbo].[KLX_SCHEDULES] VALUES(@MaxSchedID,'ICSource',0,'B:1,2,3,5,6,7,8,9,10,11,12,13,14,15,16E:1')
	INSERT INTO [dbo].[KLX_SCHED_DIMS] VALUES (@MaxSchedID,0,'Contras',4,'ENTITIES;ZElimAllowICTransactions=TRUE',0,'')	

	DELETE FROM [dbo].[KLX_DESC] where MAJOR_OBJ_ID = @MaxSchedId AND DESC_TYPE = 5
	INSERT INTO [dbo].[KLX_DESC] VALUES(5,'EN',@MaxSchedID,-1,-1,'Intercompany Adjustments')	  
END;

/*Create the NCI JE Subcategory*/
IF NOT EXISTS (SELECT DESC_TYPE FROM [dbo].[KLX_DESC] WHERE DESCRIPTION = 'Non-Controlling Interests' AND DESC_TYPE = 6)
BEGIN
	Set @MaxSubCat = @MaxSubCat + 1
	INSERT INTO [dbo].[KLX_JE_SUBCATEGORIES] VALUES ('S',@MaxSubCat,(SELECT SCHEDULE_ID FROM [dbo].[KLX_SCHEDULES] WHERE SCHEDULE_NAME = 'NCI'),0)

	DELETE FROM [dbo].[KLX_DESC] where MAJOR_OBJ_ID = 0 AND MINOR_OBJ_ID = @MaxSubCat AND DESC_TYPE = 6
	INSERT INTO [dbo].[KLX_DESC] VALUES (6,'EN',0,@MaxSubCat,-1,'Non-Controlling Interests')
END

/*Create the EQP JE Subcategory*/

IF NOT EXISTS (SELECT DESC_TYPE FROM [dbo].[KLX_DESC] WHERE DESCRIPTION = 'Equity Pickup' AND DESC_TYPE = 6)
BEGIN
	Set @MaxSubCat = @MaxSubCat + 1
	INSERT INTO [dbo].[KLX_JE_SUBCATEGORIES] VALUES ('S',@MaxSubCat,(SELECT SCHEDULE_ID FROM [dbo].[KLX_SCHEDULES] WHERE SCHEDULE_NAME = 'NCI'),0)

	DELETE FROM [dbo].[KLX_DESC] where MAJOR_OBJ_ID = 0 AND MINOR_OBJ_ID = @MaxSubCat AND DESC_TYPE = 6
	INSERT INTO [dbo].[KLX_DESC] VALUES (6,'EN',0,@MaxSubCat,-1,'Equity Pickup')
END

/*Create the ICSource Subcategory*/
IF NOT EXISTS (SELECT DESC_TYPE FROM [dbo].[KLX_DESC] WHERE DESCRIPTION = 'Intercompany Adjustments' AND DESC_TYPE = 6)
BEGIN
	Set @MaxSubCat = @MaxSubCat + 1
	INSERT INTO [dbo].[KLX_JE_SUBCATEGORIES] VALUES ('S',@MaxSubCat,(SELECT SCHEDULE_ID FROM [dbo].[KLX_SCHEDULES] WHERE SCHEDULE_NAME = 'ICSource'),1)

	DELETE FROM [dbo].[KLX_DESC] where MAJOR_OBJ_ID = 0 AND MINOR_OBJ_ID = @MaxSubCat AND DESC_TYPE = 6
	INSERT INTO [dbo].[KLX_DESC] VALUES (6,'EN',0,@MaxSubCat,-1,'Intercompany Adjustments')
END

/*Update ICStandard to RollUp for Entities*/
Set @UpdateICStandard = (SELECT COUNT(SCHEDULE_NOROLLDIM) from KLX_SCHEDULES where SCHEDULE_NAME='ICStandard' AND SCHEDULE_NOROLLDIM LIKE '%3%')

IF @UpdateICStandard = 1
BEGIN
SET @NumDims = (SELECT COUNT(*) from [dbo].[KLX_MASTER_DIM] where DIM_NAME not like 'UNUSED%')
SET @i = 1
SET @SchedRollup = 'B:'
WHILE (@i <= @NumDims) 
BEGIN
	IF @i = 3
		SET @Cnt = ''
	ELSE
	IF @i = @NumDims
		SET @Cnt = cast(@i as varchar) + 'E:1'
		ELSE
			SET @Cnt = cast(@i as varchar) + ','
			SET @SchedRollup = @SchedRollup + @Cnt
			SET @i = @i + 1
END;

UPDATE [dbo].[KLX_SCHEDULES] SET SCHEDULE_NOROLLDIM = @SchedRollup WHERE SCHEDULE_ID = 5 AND SCHEDULE_NAME = 'ICStandard'

/*Update the Cache Files*/
UPDATE [dbo].[KLX_STATUS] SET STATUS = STATUS + 1 Where PARAMETER like 'SYMCACHE%'
END;
GO

/*Declare local varaibles */
DECLARE @columnID INT = 0
DECLARE @ExistingTableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0

DECLARE @i INT = 0
DECLARE @NumDims INT = 0
DECLARE @Cnt VARCHAR(40)
DECLARE @SchedRollup VARCHAR(40)
DECLARE @MaxSubCat INT = 0
DECLARE @MaxSchedID INT = 0
DECLARE @MaxCat INT = 0
DECLARE @UpdateICStandard INT = 0

/* Check if Table is registered*/
SET @maxtableID =  (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'LVAPP_EVENTTRIGGER');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
	INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'LVAPP_EVENTTRIGGER', 0);
	PRINT 'LVAPP_EVENTTRIGGER table has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'LVAPP_EVENTTRIGGER table has been previously registered'
END;

/* Check if Table's columns are registered */ 
SELECT @rowCount = COUNT(TABLEID) FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @ExistingTableID;
If @rowCount IS Null
BEGIN
  Set @rowCount = 0;
END;
 
If @rowCount = 0
BEGIN
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(1, @tableID, 'ID', 'autointeger', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(2, @tableID, 'PROCESSTYPE', 'STRING', '')
	INSERT INTO LV_APPTABLE_COLUMNS (COLUMNID, TABLEID, COLUMNNAME, DATATYPE, DATAVALUES) VALUES(3, @tableID, 'PARAMS', 'STRING', '')
	PRINT 'LVAPP_EVENTTRIGGER Columns have been registered'
END
ELSE
BEGIN
	PRINT 'LVAPP_EVENTTRIGGER Columns have been previously registered'
END;

/* Check if Table exists */ 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'LVAPP_EVENTTRIGGER')
	BEGIN
		PRINT 'LVAPP_EVENTTRIGGER table exists'
	END
Else
	BEGIN
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON
	CREATE TABLE [dbo].LVAPP_EVENTTRIGGER (
		[ID] int NOT NULL,
		[PROCESSTYPE] varchar(15) NOT NULL,
		[PARAMS] varchar(4000) ,
		CONSTRAINT pk_LVAPP_EVENTTRIGGER PRIMARY KEY ([ID])
    ) ON [KLX_BASE_DAT]
	SET ANSI_PADDING OFF
	Print 'LVAPP_EVENTTRIGGER table created'
END; 
GO

/*Declare local varaibles */
DECLARE @columnID INT = 0
DECLARE @ExistingTableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0

DECLARE @i INT = 0
DECLARE @NumDims INT = 0
DECLARE @Cnt VARCHAR(40)
DECLARE @SchedRollup VARCHAR(40)
DECLARE @MaxSubCat INT = 0
DECLARE @MaxSchedID INT = 0
DECLARE @MaxCat INT = 0
DECLARE @UpdateICStandard INT = 0

/* VIEW SLNS_JE_DETAIL */

/* Determine how many dimensions are defined in the system */
SET @NumDims = (SELECT COUNT(*) from [dbo].[KLX_MASTER_DIM] where DIM_NAME not like 'UNUSED%')

/* check if VIEW SLNS_JE_DETAIL exists */
/* IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'SLNS_JE_DETAIL')) */

/* rebuild the SLNS_JE_DETAIL view */
IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = 'SLNS_JE_DETAIL'))
BEGIN
	drop view SLNS_JE_DETAIL;
END;

BEGIN

   /* SLNS_JE_DETAIL View Creation for 6 Dimension system */
   IF @NumDims = 6
	BEGIN
		EXECUTE('Create view SLNS_JE_DETAIL as
			select a.je_id AS "JE_ID", 
			b.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIODDESC",
			a.je_category as "CATEGORY",
			d.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			d.DESC_SUMMARY_E as "DESCRIPTION",
			a.line_number as "LINE_NUMBER",
			c.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIODDESC",
			a.dim_0_index as "DIM_0_INDEX",
			a.numeric_value as "NUMERIC_VALUE",
			a.dim_2_index as "DIM_2_INDEX",
			a.dim_3_index as "DIM_3_INDEX",
			a.dim_4_index as "DIM_4_INDEX",
			a.dim_5_index as "DIM_5_INDEX"
			from KLX_JEL_DETAIL a, KLX_MASTER_SYMBOL b, KLX_MASTER_SYMBOL c, KLX_JE_HEADER d
			where ( a.JE_ID = d.JE_ID AND a.CREATED_TP_IDX = d.CREATED_TP_IDX ) AND
			( a.CREATED_TP_IDX = b.SYM_INDEX AND b.DIM_INDEX=1 AND a.CREATED_TP_IDX=d.CREATED_TP_IDX ) AND
			( a.DIM_1_INDEX = c.SYM_INDEX and c.DIM_INDEX=1 ) AND
			( a.JE_CATEGORY = d.JE_CATEGORY )
			UNION ALL select g.je_id AS "JE_ID", 
			h.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIOD_DESC",
			g.je_category as "CATEGORY",
			j.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			j.DESC_SUMMARY_E as "DESCRIPTION",
			g.line_number as "LINE_NUMBER",
			i.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIOD_DESC",
			g.dim_0_index as "DIM_0_INDEX",
			g.numeric_value as "NUMERIC_VALUE",
			g.dim_2_index as "DIM_2_INDEX",
			g.dim_3_index as "DIM_3_INDEX",
			g.dim_4_index as "DIM_4_INDEX",
			g.dim_5_index as "DIM_5_INDEX"
			from KLX_JEC_DETAIL g, KLX_MASTER_SYMBOL h, KLX_MASTER_SYMBOL i, KLX_JE_HEADER j
			where ( g.JE_ID = j.JE_ID AND g.CREATED_TP_IDX = j.CREATED_TP_IDX ) AND
			( g.CREATED_TP_IDX = h.SYM_INDEX AND h.DIM_INDEX=1 AND g.CREATED_TP_IDX=j.CREATED_TP_IDX ) AND
			( g.DIM_1_INDEX = i.SYM_INDEX and i.DIM_INDEX=1 ) AND
			( g.JE_CATEGORY = j.JE_CATEGORY );');
	END

   /* SLNS_JE_DETAIL View Creation for 7 Dimension system */
   IF @NumDims = 7
	BEGIN
		EXECUTE('Create view SLNS_JE_DETAIL as
			select a.je_id AS "JE_ID", 
			b.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIODDESC",
			a.je_category as "CATEGORY",
			d.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			d.DESC_SUMMARY_E as "DESCRIPTION",
			a.line_number as "LINE_NUMBER",
			c.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIODDESC",
			a.dim_0_index as "DIM_0_INDEX",
			a.numeric_value as "NUMERIC_VALUE",
			a.dim_2_index as "DIM_2_INDEX",
			a.dim_3_index as "DIM_3_INDEX",
			a.dim_4_index as "DIM_4_INDEX",
			a.dim_5_index as "DIM_5_INDEX",
			a.dim_6_index as "DIM_6_INDEX"
			from KLX_JEL_DETAIL a, KLX_MASTER_SYMBOL b, KLX_MASTER_SYMBOL c, KLX_JE_HEADER d
			where ( a.JE_ID = d.JE_ID AND a.CREATED_TP_IDX = d.CREATED_TP_IDX ) AND
			( a.CREATED_TP_IDX = b.SYM_INDEX AND b.DIM_INDEX=1 AND a.CREATED_TP_IDX=d.CREATED_TP_IDX ) AND
			( a.DIM_1_INDEX = c.SYM_INDEX and c.DIM_INDEX=1 ) AND
			( a.JE_CATEGORY = d.JE_CATEGORY )
			UNION ALL select g.je_id AS "JE_ID", 
			h.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIOD_DESC",
			g.je_category as "CATEGORY",
			j.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			j.DESC_SUMMARY_E as "DESCRIPTION",
			g.line_number as "LINE_NUMBER",
			i.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIOD_DESC",
			g.dim_0_index as "DIM_0_INDEX",
			g.numeric_value as "NUMERIC_VALUE",
			g.dim_2_index as "DIM_2_INDEX",
			g.dim_3_index as "DIM_3_INDEX",
			g.dim_4_index as "DIM_4_INDEX",
			g.dim_5_index as "DIM_5_INDEX",
			g.dim_6_index as "DIM_6_INDEX"
			from KLX_JEC_DETAIL g, KLX_MASTER_SYMBOL h, KLX_MASTER_SYMBOL i, KLX_JE_HEADER j
			where ( g.JE_ID = j.JE_ID AND g.CREATED_TP_IDX = j.CREATED_TP_IDX ) AND
			( g.CREATED_TP_IDX = h.SYM_INDEX AND h.DIM_INDEX=1 AND g.CREATED_TP_IDX=j.CREATED_TP_IDX ) AND
			( g.DIM_1_INDEX = i.SYM_INDEX and i.DIM_INDEX=1 ) AND
			( g.JE_CATEGORY = j.JE_CATEGORY );');
	END

   /* SLNS_JE_DETAIL View Creation for 8 Dimension system */
   IF @NumDims = 8
	BEGIN
		EXECUTE('Create view SLNS_JE_DETAIL as
			select a.je_id AS "JE_ID", 
			b.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIODDESC",
			a.je_category as "CATEGORY",
			d.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			d.DESC_SUMMARY_E as "DESCRIPTION",
			a.line_number as "LINE_NUMBER",
			c.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIODDESC",
			a.dim_0_index as "DIM_0_INDEX",
			a.numeric_value as "NUMERIC_VALUE",
			a.dim_2_index as "DIM_2_INDEX",
			a.dim_3_index as "DIM_3_INDEX",
			a.dim_4_index as "DIM_4_INDEX",
			a.dim_5_index as "DIM_5_INDEX",
			a.dim_6_index as "DIM_6_INDEX",
			a.dim_7_index as "DIM_7_INDEX"
			from KLX_JEL_DETAIL a, KLX_MASTER_SYMBOL b, KLX_MASTER_SYMBOL c, KLX_JE_HEADER d
			where ( a.JE_ID = d.JE_ID AND a.CREATED_TP_IDX = d.CREATED_TP_IDX ) AND
			( a.CREATED_TP_IDX = b.SYM_INDEX AND b.DIM_INDEX=1 AND a.CREATED_TP_IDX=d.CREATED_TP_IDX ) AND
			( a.DIM_1_INDEX = c.SYM_INDEX and c.DIM_INDEX=1 ) AND
			( a.JE_CATEGORY = d.JE_CATEGORY )
			UNION ALL select g.je_id AS "JE_ID", 
			h.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIOD_DESC",
			g.je_category as "CATEGORY",
			j.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			j.DESC_SUMMARY_E as "DESCRIPTION",
			g.line_number as "LINE_NUMBER",
			i.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIOD_DESC",
			g.dim_0_index as "DIM_0_INDEX",
			g.numeric_value as "NUMERIC_VALUE",
			g.dim_2_index as "DIM_2_INDEX",
			g.dim_3_index as "DIM_3_INDEX",
			g.dim_4_index as "DIM_4_INDEX",
			g.dim_5_index as "DIM_5_INDEX",
			g.dim_6_index as "DIM_6_INDEX",
			g.dim_7_index as "DIM_7_INDEX"
			from KLX_JEC_DETAIL g, KLX_MASTER_SYMBOL h, KLX_MASTER_SYMBOL i, KLX_JE_HEADER j
			where ( g.JE_ID = j.JE_ID AND g.CREATED_TP_IDX = j.CREATED_TP_IDX ) AND
			( g.CREATED_TP_IDX = h.SYM_INDEX AND h.DIM_INDEX=1 AND g.CREATED_TP_IDX=j.CREATED_TP_IDX ) AND
			( g.DIM_1_INDEX = i.SYM_INDEX and i.DIM_INDEX=1 ) AND
			( g.JE_CATEGORY = j.JE_CATEGORY );');
	END

   /* SLNS_JE_DETAIL View Creation for 9 Dimension system */
   IF @NumDims = 9
	BEGIN
		EXECUTE('Create view SLNS_JE_DETAIL as
			select a.je_id AS "JE_ID", 
			b.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIODDESC",
			a.je_category as "CATEGORY",
			d.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			d.DESC_SUMMARY_E as "DESCRIPTION",
			a.line_number as "LINE_NUMBER",
			c.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIODDESC",
			a.dim_0_index as "DIM_0_INDEX",
			a.numeric_value as "NUMERIC_VALUE",
			a.dim_2_index as "DIM_2_INDEX",
			a.dim_3_index as "DIM_3_INDEX",
			a.dim_4_index as "DIM_4_INDEX",
			a.dim_5_index as "DIM_5_INDEX",
			a.dim_6_index as "DIM_6_INDEX",
			a.dim_7_index as "DIM_7_INDEX",
			a.dim_8_index as "DIM_8_INDEX"
			from KLX_JEL_DETAIL a, KLX_MASTER_SYMBOL b, KLX_MASTER_SYMBOL c, KLX_JE_HEADER d
			where ( a.JE_ID = d.JE_ID AND a.CREATED_TP_IDX = d.CREATED_TP_IDX ) AND
			( a.CREATED_TP_IDX = b.SYM_INDEX AND b.DIM_INDEX=1 AND a.CREATED_TP_IDX=d.CREATED_TP_IDX ) AND
			( a.DIM_1_INDEX = c.SYM_INDEX and c.DIM_INDEX=1 ) AND
			( a.JE_CATEGORY = d.JE_CATEGORY )
			UNION ALL select g.je_id AS "JE_ID", 
			h.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIOD_DESC",
			g.je_category as "CATEGORY",
			j.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			j.DESC_SUMMARY_E as "DESCRIPTION",
			g.line_number as "LINE_NUMBER",
			i.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIOD_DESC",
			g.dim_0_index as "DIM_0_INDEX",
			g.numeric_value as "NUMERIC_VALUE",
			g.dim_2_index as "DIM_2_INDEX",
			g.dim_3_index as "DIM_3_INDEX",
			g.dim_4_index as "DIM_4_INDEX",
			g.dim_5_index as "DIM_5_INDEX",
			g.dim_6_index as "DIM_6_INDEX",
			g.dim_7_index as "DIM_7_INDEX",
			g.dim_8_index as "DIM_8_INDEX"
			from KLX_JEC_DETAIL g, KLX_MASTER_SYMBOL h, KLX_MASTER_SYMBOL i, KLX_JE_HEADER j
			where ( g.JE_ID = j.JE_ID AND g.CREATED_TP_IDX = j.CREATED_TP_IDX ) AND
			( g.CREATED_TP_IDX = h.SYM_INDEX AND h.DIM_INDEX=1 AND g.CREATED_TP_IDX=j.CREATED_TP_IDX ) AND
			( g.DIM_1_INDEX = i.SYM_INDEX and i.DIM_INDEX=1 ) AND
			( g.JE_CATEGORY = j.JE_CATEGORY );');
	END

   /* SLNS_JE_DETAIL View Creation for 10 Dimension system */
   IF @NumDims = 10
	BEGIN
		EXECUTE('Create view SLNS_JE_DETAIL as
			select a.je_id AS "JE_ID", 
			b.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIODDESC",
			a.je_category as "CATEGORY",
			d.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			d.DESC_SUMMARY_E as "DESCRIPTION",
			a.line_number as "LINE_NUMBER",
			c.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIODDESC",
			a.dim_0_index as "DIM_0_INDEX",
			a.numeric_value as "NUMERIC_VALUE",
			a.dim_2_index as "DIM_2_INDEX",
			a.dim_3_index as "DIM_3_INDEX",
			a.dim_4_index as "DIM_4_INDEX",
			a.dim_5_index as "DIM_5_INDEX",
			a.dim_6_index as "DIM_6_INDEX",
			a.dim_7_index as "DIM_7_INDEX",
			a.dim_8_index as "DIM_8_INDEX",
			a.dim_9_index as "DIM_9_INDEX"
			from KLX_JEL_DETAIL a, KLX_MASTER_SYMBOL b, KLX_MASTER_SYMBOL c, KLX_JE_HEADER d
			where ( a.JE_ID = d.JE_ID AND a.CREATED_TP_IDX = d.CREATED_TP_IDX ) AND
			( a.CREATED_TP_IDX = b.SYM_INDEX AND b.DIM_INDEX=1 AND a.CREATED_TP_IDX=d.CREATED_TP_IDX ) AND
			( a.DIM_1_INDEX = c.SYM_INDEX and c.DIM_INDEX=1 ) AND
			( a.JE_CATEGORY = d.JE_CATEGORY )
			UNION ALL select g.je_id AS "JE_ID", 
			h.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIOD_DESC",
			g.je_category as "CATEGORY",
			j.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			j.DESC_SUMMARY_E as "DESCRIPTION",
			g.line_number as "LINE_NUMBER",
			i.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIOD_DESC",
			g.dim_0_index as "DIM_0_INDEX",
			g.numeric_value as "NUMERIC_VALUE",
			g.dim_2_index as "DIM_2_INDEX",
			g.dim_3_index as "DIM_3_INDEX",
			g.dim_4_index as "DIM_4_INDEX",
			g.dim_5_index as "DIM_5_INDEX",
			g.dim_6_index as "DIM_6_INDEX",
			g.dim_7_index as "DIM_7_INDEX",
			g.dim_8_index as "DIM_8_INDEX",
			g.dim_9_index as "DIM_9_INDEX"
			from KLX_JEC_DETAIL g, KLX_MASTER_SYMBOL h, KLX_MASTER_SYMBOL i, KLX_JE_HEADER j
			where ( g.JE_ID = j.JE_ID AND g.CREATED_TP_IDX = j.CREATED_TP_IDX ) AND
			( g.CREATED_TP_IDX = h.SYM_INDEX AND h.DIM_INDEX=1 AND g.CREATED_TP_IDX=j.CREATED_TP_IDX ) AND
			( g.DIM_1_INDEX = i.SYM_INDEX and i.DIM_INDEX=1 ) AND
			( g.JE_CATEGORY = j.JE_CATEGORY );');
	END

   /* SLNS_JE_DETAIL View Creation for 11 Dimension system */
   IF @NumDims = 11
	BEGIN
		EXECUTE('Create view SLNS_JE_DETAIL as
			select a.je_id AS "JE_ID", 
			b.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIODDESC",
			a.je_category as "CATEGORY",
			d.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			d.DESC_SUMMARY_E as "DESCRIPTION",
			a.line_number as "LINE_NUMBER",
			c.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIODDESC",
			a.dim_0_index as "DIM_0_INDEX",
			a.numeric_value as "NUMERIC_VALUE",
			a.dim_2_index as "DIM_2_INDEX",
			a.dim_3_index as "DIM_3_INDEX",
			a.dim_4_index as "DIM_4_INDEX",
			a.dim_5_index as "DIM_5_INDEX",
			a.dim_6_index as "DIM_6_INDEX",
			a.dim_7_index as "DIM_7_INDEX",
			a.dim_8_index as "DIM_8_INDEX",
			a.dim_9_index as "DIM_9_INDEX",
			a.dim_10_index as "DIM_10_INDEX"
			from KLX_JEL_DETAIL a, KLX_MASTER_SYMBOL b, KLX_MASTER_SYMBOL c, KLX_JE_HEADER d
			where ( a.JE_ID = d.JE_ID AND a.CREATED_TP_IDX = d.CREATED_TP_IDX ) AND
			( a.CREATED_TP_IDX = b.SYM_INDEX AND b.DIM_INDEX=1 AND a.CREATED_TP_IDX=d.CREATED_TP_IDX ) AND
			( a.DIM_1_INDEX = c.SYM_INDEX and c.DIM_INDEX=1 ) AND
			( a.JE_CATEGORY = d.JE_CATEGORY )
			UNION ALL select g.je_id AS "JE_ID", 
			h.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIOD_DESC",
			g.je_category as "CATEGORY",
			j.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			j.DESC_SUMMARY_E as "DESCRIPTION",
			g.line_number as "LINE_NUMBER",
			i.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIOD_DESC",
			g.dim_0_index as "DIM_0_INDEX",
			g.numeric_value as "NUMERIC_VALUE",
			g.dim_2_index as "DIM_2_INDEX",
			g.dim_3_index as "DIM_3_INDEX",
			g.dim_4_index as "DIM_4_INDEX",
			g.dim_5_index as "DIM_5_INDEX",
			g.dim_6_index as "DIM_6_INDEX",
			g.dim_7_index as "DIM_7_INDEX",
			g.dim_8_index as "DIM_8_INDEX",
			g.dim_9_index as "DIM_9_INDEX",
			g.dim_10_index as "DIM_10_INDEX"
			from KLX_JEC_DETAIL g, KLX_MASTER_SYMBOL h, KLX_MASTER_SYMBOL i, KLX_JE_HEADER j
			where ( g.JE_ID = j.JE_ID AND g.CREATED_TP_IDX = j.CREATED_TP_IDX ) AND
			( g.CREATED_TP_IDX = h.SYM_INDEX AND h.DIM_INDEX=1 AND g.CREATED_TP_IDX=j.CREATED_TP_IDX ) AND
			( g.DIM_1_INDEX = i.SYM_INDEX and i.DIM_INDEX=1 ) AND
			( g.JE_CATEGORY = j.JE_CATEGORY );');
	END

   /* SLNS_JE_DETAIL View Creation for 12 Dimension system */
   IF @NumDims = 12
	BEGIN
		EXECUTE('Create view SLNS_JE_DETAIL as
			select a.je_id AS "JE_ID", 
			b.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIODDESC",
			a.je_category as "CATEGORY",
			d.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			d.DESC_SUMMARY_E as "DESCRIPTION",
			a.line_number as "LINE_NUMBER",
			c.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIODDESC",
			a.dim_0_index as "DIM_0_INDEX",
			a.numeric_value as "NUMERIC_VALUE",
			a.dim_2_index as "DIM_2_INDEX",
			a.dim_3_index as "DIM_3_INDEX",
			a.dim_4_index as "DIM_4_INDEX",
			a.dim_5_index as "DIM_5_INDEX",
			a.dim_6_index as "DIM_6_INDEX",
			a.dim_7_index as "DIM_7_INDEX",
			a.dim_8_index as "DIM_8_INDEX",
			a.dim_9_index as "DIM_9_INDEX",
			a.dim_10_index as "DIM_10_INDEX",
			a.dim_11_index as "DIM_11_INDEX"
			from KLX_JEL_DETAIL a, KLX_MASTER_SYMBOL b, KLX_MASTER_SYMBOL c, KLX_JE_HEADER d
			where ( a.JE_ID = d.JE_ID AND a.CREATED_TP_IDX = d.CREATED_TP_IDX ) AND
			( a.CREATED_TP_IDX = b.SYM_INDEX AND b.DIM_INDEX=1 AND a.CREATED_TP_IDX=d.CREATED_TP_IDX ) AND
			( a.DIM_1_INDEX = c.SYM_INDEX and c.DIM_INDEX=1 ) AND
			( a.JE_CATEGORY = d.JE_CATEGORY )
			UNION ALL select g.je_id AS "JE_ID", 
			h.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIOD_DESC",
			g.je_category as "CATEGORY",
			j.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			j.DESC_SUMMARY_E as "DESCRIPTION",
			g.line_number as "LINE_NUMBER",
			i.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIOD_DESC",
			g.dim_0_index as "DIM_0_INDEX",
			g.numeric_value as "NUMERIC_VALUE",
			g.dim_2_index as "DIM_2_INDEX",
			g.dim_3_index as "DIM_3_INDEX",
			g.dim_4_index as "DIM_4_INDEX",
			g.dim_5_index as "DIM_5_INDEX",
			g.dim_6_index as "DIM_6_INDEX",
			g.dim_7_index as "DIM_7_INDEX",
			g.dim_8_index as "DIM_8_INDEX",
			g.dim_9_index as "DIM_9_INDEX",
			g.dim_10_index as "DIM_10_INDEX",
			g.dim_11_index as "DIM_11_INDEX"
			from KLX_JEC_DETAIL g, KLX_MASTER_SYMBOL h, KLX_MASTER_SYMBOL i, KLX_JE_HEADER j
			where ( g.JE_ID = j.JE_ID AND g.CREATED_TP_IDX = j.CREATED_TP_IDX ) AND
			( g.CREATED_TP_IDX = h.SYM_INDEX AND h.DIM_INDEX=1 AND g.CREATED_TP_IDX=j.CREATED_TP_IDX ) AND
			( g.DIM_1_INDEX = i.SYM_INDEX and i.DIM_INDEX=1 ) AND
			( g.JE_CATEGORY = j.JE_CATEGORY );');
	END

   /* SLNS_JE_DETAIL View Creation for 13 Dimension system */
   IF @NumDims = 13
	BEGIN
		EXECUTE('Create view SLNS_JE_DETAIL as
			select a.je_id AS "JE_ID", 
			b.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIODDESC",
			a.je_category as "CATEGORY",
			d.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			d.DESC_SUMMARY_E as "DESCRIPTION",
			a.line_number as "LINE_NUMBER",
			c.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIODDESC",
			a.dim_0_index as "DIM_0_INDEX",
			a.numeric_value as "NUMERIC_VALUE",
			a.dim_2_index as "DIM_2_INDEX",
			a.dim_3_index as "DIM_3_INDEX",
			a.dim_4_index as "DIM_4_INDEX",
			a.dim_5_index as "DIM_5_INDEX",
			a.dim_6_index as "DIM_6_INDEX",
			a.dim_7_index as "DIM_7_INDEX",
			a.dim_8_index as "DIM_8_INDEX",
			a.dim_9_index as "DIM_9_INDEX",
			a.dim_10_index as "DIM_10_INDEX",
			a.dim_11_index as "DIM_11_INDEX",
			a.dim_12_index as "DIM_12_INDEX"
			from KLX_JEL_DETAIL a, KLX_MASTER_SYMBOL b, KLX_MASTER_SYMBOL c, KLX_JE_HEADER d
			where ( a.JE_ID = d.JE_ID AND a.CREATED_TP_IDX = d.CREATED_TP_IDX ) AND
			( a.CREATED_TP_IDX = b.SYM_INDEX AND b.DIM_INDEX=1 AND a.CREATED_TP_IDX=d.CREATED_TP_IDX ) AND
			( a.DIM_1_INDEX = c.SYM_INDEX and c.DIM_INDEX=1 ) AND
			( a.JE_CATEGORY = d.JE_CATEGORY )
			UNION ALL select g.je_id AS "JE_ID", 
			h.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIOD_DESC",
			g.je_category as "CATEGORY",
			j.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			j.DESC_SUMMARY_E as "DESCRIPTION",
			g.line_number as "LINE_NUMBER",
			i.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIOD_DESC",
			g.dim_0_index as "DIM_0_INDEX",
			g.numeric_value as "NUMERIC_VALUE",
			g.dim_2_index as "DIM_2_INDEX",
			g.dim_3_index as "DIM_3_INDEX",
			g.dim_4_index as "DIM_4_INDEX",
			g.dim_5_index as "DIM_5_INDEX",
			g.dim_6_index as "DIM_6_INDEX",
			g.dim_7_index as "DIM_7_INDEX",
			g.dim_8_index as "DIM_8_INDEX",
			g.dim_9_index as "DIM_9_INDEX",
			g.dim_10_index as "DIM_10_INDEX",
			g.dim_11_index as "DIM_11_INDEX",
			g.dim_12_index as "DIM_12_INDEX"
			from KLX_JEC_DETAIL g, KLX_MASTER_SYMBOL h, KLX_MASTER_SYMBOL i, KLX_JE_HEADER j
			where ( g.JE_ID = j.JE_ID AND g.CREATED_TP_IDX = j.CREATED_TP_IDX ) AND
			( g.CREATED_TP_IDX = h.SYM_INDEX AND h.DIM_INDEX=1 AND g.CREATED_TP_IDX=j.CREATED_TP_IDX ) AND
			( g.DIM_1_INDEX = i.SYM_INDEX and i.DIM_INDEX=1 ) AND
			( g.JE_CATEGORY = j.JE_CATEGORY );');
	END

   /* SLNS_JE_DETAIL View Creation for 14 Dimension system */
   IF @NumDims = 14
	BEGIN
		EXECUTE('Create view SLNS_JE_DETAIL as
			select a.je_id AS "JE_ID", 
			b.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIODDESC",
			a.je_category as "CATEGORY",
			d.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			d.DESC_SUMMARY_E as "DESCRIPTION",
			a.line_number as "LINE_NUMBER",
			c.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIODDESC",
			a.dim_0_index as "DIM_0_INDEX",
			a.numeric_value as "NUMERIC_VALUE",
			a.dim_2_index as "DIM_2_INDEX",
			a.dim_3_index as "DIM_3_INDEX",
			a.dim_4_index as "DIM_4_INDEX",
			a.dim_5_index as "DIM_5_INDEX",
			a.dim_6_index as "DIM_6_INDEX",
			a.dim_7_index as "DIM_7_INDEX",
			a.dim_8_index as "DIM_8_INDEX",
			a.dim_9_index as "DIM_9_INDEX",
			a.dim_10_index as "DIM_10_INDEX",
			a.dim_11_index as "DIM_11_INDEX",
			a.dim_12_index as "DIM_12_INDEX",
			a.dim_13_index as "DIM_13_INDEX"
			from KLX_JEL_DETAIL a, KLX_MASTER_SYMBOL b, KLX_MASTER_SYMBOL c, KLX_JE_HEADER d
			where ( a.JE_ID = d.JE_ID AND a.CREATED_TP_IDX = d.CREATED_TP_IDX ) AND
			( a.CREATED_TP_IDX = b.SYM_INDEX AND b.DIM_INDEX=1 AND a.CREATED_TP_IDX=d.CREATED_TP_IDX ) AND
			( a.DIM_1_INDEX = c.SYM_INDEX and c.DIM_INDEX=1 ) AND
			( a.JE_CATEGORY = d.JE_CATEGORY )
			UNION ALL select g.je_id AS "JE_ID", 
			h.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIOD_DESC",
			g.je_category as "CATEGORY",
			j.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			j.DESC_SUMMARY_E as "DESCRIPTION",
			g.line_number as "LINE_NUMBER",
			i.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIOD_DESC",
			g.dim_0_index as "DIM_0_INDEX",
			g.numeric_value as "NUMERIC_VALUE",
			g.dim_2_index as "DIM_2_INDEX",
			g.dim_3_index as "DIM_3_INDEX",
			g.dim_4_index as "DIM_4_INDEX",
			g.dim_5_index as "DIM_5_INDEX",
			g.dim_6_index as "DIM_6_INDEX",
			g.dim_7_index as "DIM_7_INDEX",
			g.dim_8_index as "DIM_8_INDEX",
			g.dim_9_index as "DIM_9_INDEX",
			g.dim_10_index as "DIM_10_INDEX",
			g.dim_11_index as "DIM_11_INDEX",
			g.dim_12_index as "DIM_12_INDEX",
			g.dim_13_index as "DIM_13_INDEX"
			from KLX_JEC_DETAIL g, KLX_MASTER_SYMBOL h, KLX_MASTER_SYMBOL i, KLX_JE_HEADER j
			where ( g.JE_ID = j.JE_ID AND g.CREATED_TP_IDX = j.CREATED_TP_IDX ) AND
			( g.CREATED_TP_IDX = h.SYM_INDEX AND h.DIM_INDEX=1 AND g.CREATED_TP_IDX=j.CREATED_TP_IDX ) AND
			( g.DIM_1_INDEX = i.SYM_INDEX and i.DIM_INDEX=1 ) AND
			( g.JE_CATEGORY = j.JE_CATEGORY );');
	END

   /* SLNS_JE_DETAIL View Creation for 15 Dimension system */
   IF @NumDims = 15
	BEGIN
		EXECUTE('Create view SLNS_JE_DETAIL as
			select a.je_id AS "JE_ID", 
			b.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIODDESC",
			a.je_category as "CATEGORY",
			d.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			d.DESC_SUMMARY_E as "DESCRIPTION",
			a.line_number as "LINE_NUMBER",
			c.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIODDESC",
			a.dim_0_index as "DIM_0_INDEX",
			a.numeric_value as "NUMERIC_VALUE",
			a.dim_2_index as "DIM_2_INDEX",
			a.dim_3_index as "DIM_3_INDEX",
			a.dim_4_index as "DIM_4_INDEX",
			a.dim_5_index as "DIM_5_INDEX",
			a.dim_6_index as "DIM_6_INDEX",
			a.dim_7_index as "DIM_7_INDEX",
			a.dim_8_index as "DIM_8_INDEX",
			a.dim_9_index as "DIM_9_INDEX",
			a.dim_10_index as "DIM_10_INDEX",
			a.dim_11_index as "DIM_11_INDEX",
			a.dim_12_index as "DIM_12_INDEX",
			a.dim_13_index as "DIM_13_INDEX",
			a.dim_14_index as "DIM_14_INDEX"
			from KLX_JEL_DETAIL a, KLX_MASTER_SYMBOL b, KLX_MASTER_SYMBOL c, KLX_JE_HEADER d
			where ( a.JE_ID = d.JE_ID AND a.CREATED_TP_IDX = d.CREATED_TP_IDX ) AND
			( a.CREATED_TP_IDX = b.SYM_INDEX AND b.DIM_INDEX=1 AND a.CREATED_TP_IDX=d.CREATED_TP_IDX ) AND
			( a.DIM_1_INDEX = c.SYM_INDEX and c.DIM_INDEX=1 ) AND
			( a.JE_CATEGORY = d.JE_CATEGORY )
			UNION ALL select g.je_id AS "JE_ID", 
			h.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIOD_DESC",
			g.je_category as "CATEGORY",
			j.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			j.DESC_SUMMARY_E as "DESCRIPTION",
			g.line_number as "LINE_NUMBER",
			i.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIOD_DESC",
			g.dim_0_index as "DIM_0_INDEX",
			g.numeric_value as "NUMERIC_VALUE",
			g.dim_2_index as "DIM_2_INDEX",
			g.dim_3_index as "DIM_3_INDEX",
			g.dim_4_index as "DIM_4_INDEX",
			g.dim_5_index as "DIM_5_INDEX",
			g.dim_6_index as "DIM_6_INDEX",
			g.dim_7_index as "DIM_7_INDEX",
			g.dim_8_index as "DIM_8_INDEX",
			g.dim_9_index as "DIM_9_INDEX",
			g.dim_10_index as "DIM_10_INDEX",
			g.dim_11_index as "DIM_11_INDEX",
			g.dim_12_index as "DIM_12_INDEX",
			g.dim_13_index as "DIM_13_INDEX",
			g.dim_14_index as "DIM_14_INDEX"
			from KLX_JEC_DETAIL g, KLX_MASTER_SYMBOL h, KLX_MASTER_SYMBOL i, KLX_JE_HEADER j
			where ( g.JE_ID = j.JE_ID AND g.CREATED_TP_IDX = j.CREATED_TP_IDX ) AND
			( g.CREATED_TP_IDX = h.SYM_INDEX AND h.DIM_INDEX=1 AND g.CREATED_TP_IDX=j.CREATED_TP_IDX ) AND
			( g.DIM_1_INDEX = i.SYM_INDEX and i.DIM_INDEX=1 ) AND
			( g.JE_CATEGORY = j.JE_CATEGORY );');
	END

   /* SLNS_JE_DETAIL View Creation for 16 Dimension system */
   IF @NumDims = 16
	BEGIN
		EXECUTE('Create view SLNS_JE_DETAIL as
			select a.je_id AS "JE_ID", 
			b.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIODDESC",
			a.je_category as "CATEGORY",
			d.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			d.DESC_SUMMARY_E as "DESCRIPTION",
			a.line_number as "LINE_NUMBER",
			c.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIODDESC",
			a.dim_0_index as "DIM_0_INDEX",
			a.numeric_value as "NUMERIC_VALUE",
			a.dim_2_index as "DIM_2_INDEX",
			a.dim_3_index as "DIM_3_INDEX",
			a.dim_4_index as "DIM_4_INDEX",
			a.dim_5_index as "DIM_5_INDEX",
			a.dim_6_index as "DIM_6_INDEX",
			a.dim_7_index as "DIM_7_INDEX",
			a.dim_8_index as "DIM_8_INDEX",
			a.dim_9_index as "DIM_9_INDEX",
			a.dim_10_index as "DIM_10_INDEX",
			a.dim_11_index as "DIM_11_INDEX",
			a.dim_12_index as "DIM_12_INDEX",
			a.dim_13_index as "DIM_13_INDEX",
			a.dim_14_index as "DIM_14_INDEX",
			a.dim_15_index as "DIM_15_INDEX"
			from KLX_JEL_DETAIL a, KLX_MASTER_SYMBOL b, KLX_MASTER_SYMBOL c, KLX_JE_HEADER d
			where ( a.JE_ID = d.JE_ID AND a.CREATED_TP_IDX = d.CREATED_TP_IDX ) AND
			( a.CREATED_TP_IDX = b.SYM_INDEX AND b.DIM_INDEX=1 AND a.CREATED_TP_IDX=d.CREATED_TP_IDX ) AND
			( a.DIM_1_INDEX = c.SYM_INDEX and c.DIM_INDEX=1 ) AND
			( a.JE_CATEGORY = d.JE_CATEGORY )
			UNION ALL select g.je_id AS "JE_ID", 
			h.sym_name as "CREATION_PERIOD",
			''CPD'' as "CREATION_PERIOD_DESC",
			g.je_category as "CATEGORY",
			j.SUB_CATEGORY as "SUB_CATEGORY",
			''SUB'' as "SUB_CATEGORYDESC",
			j.DESC_SUMMARY_E as "DESCRIPTION",
			g.line_number as "LINE_NUMBER",
			i.sym_name as "POST_PERIOD",
			''PPD'' as "POST_PERIOD_DESC",
			g.dim_0_index as "DIM_0_INDEX",
			g.numeric_value as "NUMERIC_VALUE",
			g.dim_2_index as "DIM_2_INDEX",
			g.dim_3_index as "DIM_3_INDEX",
			g.dim_4_index as "DIM_4_INDEX",
			g.dim_5_index as "DIM_5_INDEX",
			g.dim_6_index as "DIM_6_INDEX",
			g.dim_7_index as "DIM_7_INDEX",
			g.dim_8_index as "DIM_8_INDEX",
			g.dim_9_index as "DIM_9_INDEX",
			g.dim_10_index as "DIM_10_INDEX",
			g.dim_11_index as "DIM_11_INDEX",
			g.dim_12_index as "DIM_12_INDEX",
			g.dim_13_index as "DIM_13_INDEX",
			g.dim_14_index as "DIM_14_INDEX",
			g.dim_15_index as "DIM_15_INDEX"
			from KLX_JEC_DETAIL g, KLX_MASTER_SYMBOL h, KLX_MASTER_SYMBOL i, KLX_JE_HEADER j
			where ( g.JE_ID = j.JE_ID AND g.CREATED_TP_IDX = j.CREATED_TP_IDX ) AND
			( g.CREATED_TP_IDX = h.SYM_INDEX AND h.DIM_INDEX=1 AND g.CREATED_TP_IDX=j.CREATED_TP_IDX ) AND
			( g.DIM_1_INDEX = i.SYM_INDEX and i.DIM_INDEX=1 ) AND
			( g.JE_CATEGORY = j.JE_CATEGORY );');
	END

   Print 'SLNS_JE_DETAIL View created'
END;
GO

/* Register SLNS_JE_DETAIL */
/* Declare local variables */
DECLARE @ExistingTableID INT = 0
DECLARE @maxtableID INT = 0
DECLARE @tableID INT = 0
DECLARE @rowCount INT = 0
DECLARE @NumDims INT = 0

SET @NumDims = (SELECT COUNT(*) from [dbo].[KLX_MASTER_DIM] where DIM_NAME not like 'UNUSED%')
Set @maxtableID = (SELECT ISNULL(MAX(TABLEID),0) FROM LV_APPTABLES);

/* Check if View is registered*/
SET @ExistingTableID = (SELECT ISNULL(MAX(TableID),0) FROM LV_APPTABLES where TABLENAME = 'SLNS_JE_DETAIL');

If @ExistingTableID = 0 
BEGIN
	Set @maxtableID = @maxtableID + 1;
	SET @tableID = @maxtableID;
	Set @ExistingTableID = @maxtableID;
  INSERT INTO [dbo].[LV_APPTABLES] ([TABLEID] ,[TABLENAME] ,[USERCOLUMNSECURITY]) VALUES (@tableID, 'SLNS_JE_DETAIL', 0);
  PRINT 'SLNS_JE_DETAILS view has been registered'
END
ELSE
BEGIN
	SET @tableID = @ExistingTableID;
	PRINT 'SLNS_JE_DETAIL view has been previously registered'
END;

/* register (or re-register) the columns */ 
BEGIN
	DELETE FROM LV_APPTABLE_COLUMNS WHERE TABLEID = @tableID;

	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (1, @tableID, 'JE_ID', 'AUTOINTEGER', '1')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (2, @tableID, 'CREATION_PERIOD', 'STRING', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (3, @tableID, 'CREATION_PERIODDESC', 'STRING', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (4, @tableID, 'CATEGORY', 'STRING', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (5, @tableID, 'SUB_CATEGORY', 'AUTOINTEGER', '1')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (6, @tableID, 'SUB_CATEGORYDESC', 'STRING', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (7, @tableID, 'DESCRIPTION', 'STRING', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (8, @tableID, 'LINE_NUMBER', 'AUTOINTEGER', '1')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (9, @tableID, 'POST_PERIOD', 'STRING', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (10, @tableID, 'POST_PERIODDESC', 'STRING', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (11, @tableID, 'DIM_0_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=0))
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (12, @tableID, 'NUMERIC_VALUE', 'NUMBER', '')
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (13, @tableID, 'DIM_2_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=2))
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (14, @tableID, 'DIM_3_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=3))
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (15, @tableID, 'DIM_4_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=4))
	INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (16, @tableID, 'DIM_5_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=5))
	IF @NumDims >= 7
		BEGIN
			INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (17, @tableID, 'DIM_6_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=6))
		END
	IF @NumDims >= 8
		BEGIN
			INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (18, @tableID, 'DIM_7_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=7))
		END
	IF @NumDims >= 9
		BEGIN
			INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (19, @tableID, 'DIM_8_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=8))
		END
	IF @NumDims >= 10
		BEGIN
			INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (20, @tableID, 'DIM_9_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=9))
		END
	IF @NumDims >= 11
		BEGIN
			INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (21, @tableID, 'DIM_10_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=10))
		END
	IF @NumDims >= 12
		BEGIN
			INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (22, @tableID, 'DIM_11_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=11))
		END
	IF @NumDims >= 13
		BEGIN
			INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (23, @tableID, 'DIM_12_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=12))
		END
	IF @NumDims >= 14
		BEGIN
			INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (24, @tableID, 'DIM_13_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=13))
		END
	IF @NumDims >= 15
		BEGIN
			INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (25, @tableID, 'DIM_14_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=14))
		END
	IF @NumDims >= 16
		BEGIN
			INSERT INTO [dbo].[LV_APPTABLE_COLUMNS] ([COLUMNID], [TABLEID], [COLUMNNAME], [DATATYPE], [DATAVALUES]) VALUES (26, @tableID, 'DIM_15_INDEX', 'SYMBOL', (Select DIM_NAME from KLX_MASTER_DIM where dim_index=15))
		END

	PRINT 'SLNS_JE_DETAIL Columns have been registered'

END;
GO

/***End of Script ***/
