
CREATE TABLE [dbo].[KLX_MASTER_DIM] (
	[DIM_INDEX]		[int] NOT NULL,
	[DIM_NAME]		[varchar] (31) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_DESC] (
	[DESC_TYPE]		[int] NOT NULL,
	[LANG_CODE]		[varchar] (2) NOT NULL,
	[MAJOR_OBJ_ID]		[int] NOT NULL,
	[MINOR_OBJ_ID]		[int] NOT NULL,
	[MICRO_OBJ_ID]		[int] NOT NULL,
	[DESCRIPTION]		[varchar] (255) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_MASTER_SYMBOL] (
	[DIM_INDEX]		[int] NOT NULL,
	[SYM_INDEX]		[int] NOT NULL,
	[SYM_CHILDSORT]		[int] NOT NULL,
	[SYM_FLAG]		[int] NOT NULL,
	[CRDR_TYPE]		[int] NOT NULL,
	[SYM_PARTITION]		[int] NOT NULL,
	[SYM_STATUS]		[int] NOT NULL,
	[SYM_NAME]		[varchar] (31) NOT NULL,
	[CREATED]		[datetime] NOT NULL,
	[LAST_MOD]		[datetime] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_SYM_DESC] (
	[DESC_TYPE]		[int] NOT NULL,
	[LANG_CODE]		[varchar] (2) NOT NULL,
	[MAJOR_OBJ_ID]		[int] NOT NULL,
	[MINOR_OBJ_ID]		[int] NOT NULL,
	[MICRO_OBJ_ID]		[int] NOT NULL,
	[DESCRIPTION]		[varchar] (255) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_PARENT_CHILD] (
	[DIM_INDEX]		[int] NOT NULL,
	[SYM_INDEX]		[int] NOT NULL,
	[PARENT_INDEX]		[int] NOT NULL,
	[PARENT_NAME]		[varchar] (31) NOT NULL,
	[SYM_WEIGHT]		[int] NOT NULL,
	[SYM_PRIORITY]		[int] NOT NULL,
	[CREATED]		[datetime] NOT NULL,
	[LAST_MOD]		[datetime] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_ATTRIBUTES] (
	[CLASS_ID]		[int] NOT NULL,
	[CLASS_NAME]		[varchar] (31) NOT NULL,
	[CLASS_DESC]		[varchar] (100) NOT NULL,
	[DEFN_TABLE]		[varchar] (20) NOT NULL,
	[OBJ_DEFN_TABLE]		[varchar] (20) NOT NULL,
	[OBJ_NUM_TABLE]		[varchar] (20) NOT NULL,
	[OBJ_STR_TABLE]		[varchar] (20) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_ATTR_DEFS] (
	[CLASS_ID]		[int] NOT NULL,
	[ATTR_ID]		[int] NOT NULL,
	[ATTR_NAME]		[varchar] (31) NOT NULL,
	[ATTR_TYPE]		[int] NOT NULL,
	[ATTR_NUM]		[float] NOT NULL,
	[ATTR_STR]		[varchar] (4000) NOT NULL,
	[ATTR_ATTR]		[varchar] (2) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_SYMATTR_NUMVAL] (
	[OBJ_ID]		[int] NOT NULL,
	[ATTR_ID]		[int] NOT NULL,
	[ITEM_NO]		[int] NOT NULL,
	[VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_SYMATTR_STRVAL] (
	[OBJ_ID]		[int] NOT NULL,
	[ATTR_ID]		[int] NOT NULL,
	[ITEM_NO]		[int] NOT NULL,
	[VALUE]		[varchar] (4000) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_SYSATTR_NUMVAL] (
	[OBJ_ID]		[int] NOT NULL,
	[ATTR_ID]		[int] NOT NULL,
	[ITEM_NO]		[int] NOT NULL,
	[VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_SYSATTR_STRVAL] (
	[OBJ_ID]		[int] NOT NULL,
	[ATTR_ID]		[int] NOT NULL,
	[ITEM_NO]		[int] NOT NULL,
	[VALUE]		[varchar] (4000) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_USRATTR_NUMVAL] (
	[OBJ_ID]		[int] NOT NULL,
	[ATTR_ID]		[int] NOT NULL,
	[ITEM_NO]		[int] NOT NULL,
	[VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_USRATTR_STRVAL] (
	[OBJ_ID]		[int] NOT NULL,
	[ATTR_ID]		[int] NOT NULL,
	[ITEM_NO]		[int] NOT NULL,
	[VALUE]		[varchar] (4000) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_USER_GRP_ACC] (
	[OBJ_ID]		[int] NOT NULL,
	[DIM_INDEX]		[int] NOT NULL,
	[PARENT_INDEX]		[int] NOT NULL,
	[ACCESS_LEVEL]		[int] NOT NULL,
	[SYM_ACCESS]		[varchar] (1) NOT NULL,
	[ACCESS_PRIORITY]		[int] NOT NULL,
	[ROLE_ID]		[int] NOT NULL,
	[INHERIT]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_USER_SYM_ACC] (
	[OBJ_ID]		[int] NOT NULL,
	[DIM_INDEX]		[int] NOT NULL,
	[PARENT_INDEX]		[int] NOT NULL,
	[ACCESS_LEVEL]		[int] NOT NULL,
	[SYM_ACCESS]		[varchar] (1) NOT NULL,
	[ACCESS_PRIORITY]		[int] NOT NULL,
	[ROLE_ID]		[int] NOT NULL,
	[INHERIT]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_OBJ_STAMPS] (
	[STAMP_TYPE]		[int] NOT NULL,
	[CLASS_ID]		[int] NOT NULL,
	[OBJ_ID]		[int] NOT NULL,
	[STAMP_ID]		[int] NOT NULL,
	[STAMP]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_STATUS] (
	[PARAMETER]		[varchar] (63) NOT NULL,
	[STATUS]		[varchar] (255) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_PARTITIONS] (
	[PART_ID]		[int] NOT NULL,
	[DIM_0_PART]		[int] NOT NULL,
	[DIM_1_PART]		[int] NOT NULL,
	[DIM_2_PART]		[int] NOT NULL,
	[DIM_3_PART]		[int] NOT NULL,
	[DIM_4_PART]		[int] NOT NULL,
	[DIM_5_PART]		[int] NOT NULL,
	[DIM_6_PART]		[int] NOT NULL,
	[DIM_7_PART]		[int] NOT NULL,
	[PART_NAME]		[varchar] (100) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WEB_PG_GROUPS] (
	[GROUP_ID]		[int] NOT NULL,
	[PAGE_ID]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WEB_PAGES] (
	[PAGE_ID]		[int] NOT NULL,
	[PAGE_NAME]		[varchar] (63) NOT NULL,
	[PAGE_DESC]		[varchar] (100) NOT NULL,
	[PARENT_PAGE_ID]		[int] NOT NULL,
	[PAGE_PRIORITY]		[int] NOT NULL,
	[PAGE_ICON]		[varchar] (255) NOT NULL,
	[PAGE_ATTR]		[int] NOT NULL,
	[PAGE_STYLESHEET]		[varchar] (255) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WEB_PANELS] (
	[PANEL_ID]		[int] NOT NULL,
	[PANEL_NAME]		[varchar] (255) NOT NULL,
	[PANEL_DESC]		[varchar] (255) NOT NULL,
	[PANEL_EXT_DESC]		[varchar] (1280) NOT NULL,
	[PANEL_TYPE]		[int] NOT NULL,
	[PANEL_ICON]		[varchar] (255) NOT NULL,
	[PANEL_CONTENT_TYPE]		[int] NOT NULL,
	[PANEL_OPTIONS]		[varchar] (255) NOT NULL,
	[PANEL_ATTR]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WEB_PANEL_ITMS] (
	[PANEL_ID]		[int] NOT NULL,
	[ITEM_NO]		[int] NOT NULL,
	[ITEM_TEXT_HREF]		[varchar] (4000) NOT NULL,
	[ITEM_DESC]		[varchar] (100) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WEB_PG_PANELS] (
	[PAGE_ID]		[int] NOT NULL,
	[PANEL_ID]		[int] NOT NULL,
	[ASSIGNMENT_TYPE]		[int] NOT NULL,
	[OBJ_ID]		[int] NOT NULL,
	[REGION]		[int] NOT NULL,
	[POSITION]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_JE_HEADER] (
	[JE_ID]		[int] NOT NULL,
	[CREATED_TP_IDX]		[int] NOT NULL,
	[JE_CATEGORY]		[varchar] (1) NOT NULL,
	[SUB_CATEGORY]		[int] NOT NULL,
	[CREATED]		[datetime] NOT NULL,
	[LAST_MOD]		[datetime] NOT NULL,
	[POST_TP_IDX]		[int] NOT NULL,
	[JE_TYPE]		[varchar] (1) NOT NULL,
	[JE_FINANCIAL]		[varchar] (1) NOT NULL,
	[JE_CALCULATED]		[varchar] (1) NOT NULL,
	[JE_SHARED]		[varchar] (1) NOT NULL,
	[JE_RECURRING]		[varchar] (1) NOT NULL,
	[JE_STATUS]		[varchar] (1) NOT NULL,
	[CREATOR]		[varchar] (63) NOT NULL,
	[JE_APPID]		[varchar] (31) NOT NULL,
	[DESC_SUMMARY_E]		[varchar] (100) NOT NULL,
	[DESC_SUMMARY_F]		[varchar] (100) NOT NULL,
	[DESC_DETAIL_E]		[varchar] (1280) NOT NULL,
	[DESC_DETAIL_F]		[varchar] (1280) NOT NULL,
	[LOCKEDUSER]		[varchar] (63) NOT NULL,
	[LOCKEDSID]		[int] NOT NULL,
	[LINK_ID]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_JE_SUBCATEGORIES] (
	[JE_CATEGORY]		[varchar] (1) NOT NULL,
	[SUB_CATEGORY]		[int] NOT NULL,
	[SCHEDULE_ID]		[int] NOT NULL,
	[RECLASS_FLAG]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_JE_GROUPS] (
	[JE_ID]		[int] NOT NULL,
	[CREATED_TP_IDX]		[int] NOT NULL,
	[JE_CATEGORY]		[varchar] (1) NOT NULL,
	[GROUP_TYPE]		[int] NOT NULL,
	[GROUP_ID]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_JEC_DETAIL] (
	[JE_ID]		[int] NOT NULL,
	[CREATED_TP_IDX]		[int] NOT NULL,
	[JE_CATEGORY]		[varchar] (1) NOT NULL,
	[LINE_NUMBER]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_JEL_DETAIL] (
	[JE_ID]		[int] NOT NULL,
	[CREATED_TP_IDX]		[int] NOT NULL,
	[JE_CATEGORY]		[varchar] (1) NOT NULL,
	[LINE_NUMBER]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_JET_DETAIL] (
	[JE_ID]		[int] NOT NULL,
	[CREATED_TP_IDX]		[int] NOT NULL,
	[JE_CATEGORY]		[varchar] (1) NOT NULL,
	[LINE_NUMBER]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_JESL_DETAIL] (
	[JE_ID]		[int] NOT NULL,
	[CREATED_TP_IDX]		[int] NOT NULL,
	[JE_CATEGORY]		[varchar] (1) NOT NULL,
	[LINE_NUMBER]		[int] NOT NULL,
	[SUB_LINE_NUMBER]		[int] NOT NULL,
	[SCHEDULE_ID]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_JE_HEADER_BAK000] (
	[JE_ID]		[int] NOT NULL,
	[CREATED_TP_IDX]		[int] NOT NULL,
	[JE_CATEGORY]		[varchar] (1) NOT NULL,
	[SUB_CATEGORY]		[int] NOT NULL,
	[CREATED]		[datetime] NOT NULL,
	[LAST_MOD]		[datetime] NOT NULL,
	[POST_TP_IDX]		[int] NOT NULL,
	[JE_TYPE]		[varchar] (1) NOT NULL,
	[JE_FINANCIAL]		[varchar] (1) NOT NULL,
	[JE_CALCULATED]		[varchar] (1) NOT NULL,
	[JE_SHARED]		[varchar] (1) NOT NULL,
	[JE_RECURRING]		[varchar] (1) NOT NULL,
	[JE_STATUS]		[varchar] (1) NOT NULL,
	[CREATOR]		[varchar] (63) NOT NULL,
	[JE_APPID]		[varchar] (31) NOT NULL,
	[DESC_SUMMARY_E]		[varchar] (100) NOT NULL,
	[DESC_SUMMARY_F]		[varchar] (100) NOT NULL,
	[DESC_DETAIL_E]		[varchar] (1280) NOT NULL,
	[DESC_DETAIL_F]		[varchar] (1280) NOT NULL,
	[LOCKEDUSER]		[varchar] (63) NOT NULL,
	[LOCKEDSID]		[int] NOT NULL,
	[LINK_ID]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_JEC_DETAIL_BAK000] (
	[JE_ID]		[int] NOT NULL,
	[CREATED_TP_IDX]		[int] NOT NULL,
	[JE_CATEGORY]		[varchar] (1) NOT NULL,
	[LINE_NUMBER]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_JEL_DETAIL_BAK000] (
	[JE_ID]		[int] NOT NULL,
	[CREATED_TP_IDX]		[int] NOT NULL,
	[JE_CATEGORY]		[varchar] (1) NOT NULL,
	[LINE_NUMBER]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_JET_DETAIL_BAK000] (
	[JE_ID]		[int] NOT NULL,
	[CREATED_TP_IDX]		[int] NOT NULL,
	[JE_CATEGORY]		[varchar] (1) NOT NULL,
	[LINE_NUMBER]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_JE_FILE_ATTACHMENT] (
	[JE_ID]		[int] NOT NULL,
	[CREATED_TP_IDX]		[int] NOT NULL,
	[JE_CATEGORY]		[varchar] (1) NOT NULL,
	[FILE_DIR_GUID]		[varchar] (100) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_IC_HEADER] (
	[TRANS_ID]		[int] NOT NULL,
	[SCHEDULE_ID]		[int] NOT NULL,
	[JE_ID]		[int] NOT NULL,
	[CREATED_TP_IDX]		[int] NOT NULL,
	[REPORTER]		[int] NOT NULL,
	[CONTRA_REPORTER]		[int] NOT NULL,
	[OFFSET_ACCOUNT]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[STATUS]		[int] NOT NULL,
	[PART_ID]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_IC_STOCK] (
	[STOCK_ID]		[int] NOT NULL,
	[INV_ID]		[int] NOT NULL,
	[LINE_NUMBER]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_IC_TRANS_ELIM] (
	[TRANS_ID]		[int] NOT NULL,
	[ELIM_ENTITY]		[int] NOT NULL,
	[LINE_NUMBER]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_ICC_TXN] (
	[TRANS_ID]		[int] NOT NULL,
	[ACCOUNT]		[int] NOT NULL,
	[TIMEPERIOD]		[int] NOT NULL,
	[FIXED_DIM1]		[int] NOT NULL,
	[FIXED_DIM2]		[int] NOT NULL,
	[FIXED_DIM3]		[int] NOT NULL,
	[FIXED_DIM4]		[int] NOT NULL,
	[FIXED_DIM5]		[int] NOT NULL,
	[LINE_NUMBER]		[int] NOT NULL,
	[AMOUNT]		[float] NOT NULL,
	[POSTED_ACC_AMT]		[float] NOT NULL,
	[POSTED_OFFSET_AMT]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_ICL_TXN] (
	[TRANS_ID]		[int] NOT NULL,
	[ACCOUNT]		[int] NOT NULL,
	[TIMEPERIOD]		[int] NOT NULL,
	[FIXED_DIM1]		[int] NOT NULL,
	[FIXED_DIM2]		[int] NOT NULL,
	[FIXED_DIM3]		[int] NOT NULL,
	[FIXED_DIM4]		[int] NOT NULL,
	[FIXED_DIM5]		[int] NOT NULL,
	[LINE_NUMBER]		[int] NOT NULL,
	[AMOUNT]		[float] NOT NULL,
	[POSTED_ACC_AMT]		[float] NOT NULL,
	[POSTED_OFFSET_AMT]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_ICT_TXN] (
	[TRANS_ID]		[int] NOT NULL,
	[ACCOUNT]		[int] NOT NULL,
	[TIMEPERIOD]		[int] NOT NULL,
	[FIXED_DIM1]		[int] NOT NULL,
	[FIXED_DIM2]		[int] NOT NULL,
	[FIXED_DIM3]		[int] NOT NULL,
	[FIXED_DIM4]		[int] NOT NULL,
	[FIXED_DIM5]		[int] NOT NULL,
	[LINE_NUMBER]		[int] NOT NULL,
	[AMOUNT]		[float] NOT NULL,
	[POSTED_ACC_AMT]		[float] NOT NULL,
	[POSTED_OFFSET_AMT]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_IC_OWN_PCT] (
	[ACCOUNT]		[int] NOT NULL,
	[TIMEPERIOD]		[int] NOT NULL,
	[REPORTER]		[int] NOT NULL,
	[CONTRA_REPORTER]		[int] NOT NULL,
	[SCHEDULE_ID]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[FIXED_DIM1]		[int] NOT NULL,
	[FIXED_DIM2]		[int] NOT NULL,
	[FIXED_DIM3]		[int] NOT NULL,
	[FIXED_DIM4]		[int] NOT NULL,
	[FIXED_DIM5]		[int] NOT NULL,
	[TYPE]		[int] NOT NULL,
	[VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_IC_OBJECT] (
	[IC_OBJ_ID]		[int] NOT NULL,
	[IC_OBJ_NAME]		[varchar] (31) NOT NULL,
	[IC_OBJ_OFFSET_ACCT]		[int] NOT NULL,
	[IC_OBJ_TYPE]		[int] NOT NULL,
	[IC_OBJ_SUB_CATEGORY]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_SCHEDULES] (
	[SCHEDULE_ID]		[int] NOT NULL,
	[SCHEDULE_NAME]		[varchar] (31) NOT NULL,
	[SCHEDULE_TYPE]		[int] NOT NULL,
	[SCHEDULE_NOROLLDIM]		[varchar] (100) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_SCHED_DIMS] (
	[SCHEDULE_ID]		[int] NOT NULL,
	[EXTRADIM_INDEX]		[int] NOT NULL,
	[EXTRADIM_NAME]		[varchar] (31) NOT NULL,
	[EXTRADIM_TYPE]		[int] NOT NULL,
	[EXTRADIM_DEFN]		[varchar] (4000) NOT NULL,
	[EXTRADIM_ATTR]		[int] NOT NULL,
	[EXTRADIM_OTHER]		[varchar] (1280) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_BATCH] (
	[BATCH_ID]		[int] NOT NULL,
	[CREATED]		[datetime] NOT NULL,
	[SID]		[int] NOT NULL,
	[SENDER]		[varchar] (63) NOT NULL,
	[MATH_SRVR_STATUS]		[int] NOT NULL,
	[COMMENTS]		[varchar] (100) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_BATCH_DETAIL] (
	[BATCH_ID]		[int] NOT NULL,
	[SERVER_TYPE]		[int] NOT NULL,
	[SERVER_FAMILY]		[int] NOT NULL,
	[TABLE_TYPE]		[int] NOT NULL,
	[REF_1_ID]		[int] NOT NULL,
	[REF_2_ID]		[int] NOT NULL,
	[REF_3_ID]		[int] NOT NULL,
	[SERVER_ID]		[int] NOT NULL,
	[SENDER_ID]		[int] NOT NULL,
	[START_DATE]		[datetime] NOT NULL,
	[END_DATE]		[datetime] NOT NULL,
	[STATUS]		[int] NOT NULL,
	[FILENAME]		[varchar] (100) NOT NULL,
	[COMMENTS]		[varchar] (100) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_BATCH_QUEINFO] (
	[QID]		[int] NOT NULL,
	[SID]		[int] NOT NULL,
	[USERNAME]		[varchar] (63) NOT NULL,
	[FILENAME]		[varchar] (100) NOT NULL,
	[QUE_INFO]		[varchar] (100) NOT NULL,
	[QUE_DATE]		[datetime] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_BATCH_FROM_EVENT] (
	[BATCH_ID]		[int] NOT NULL,
	[FROM_EVENT_ID]		[int] NOT NULL,
	[CREATED]		[datetime] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_BATCH_AREA_DETAIL] (
	[BATCH_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_DATALOCKS] (
	[LOCK_ID]		[int] NOT NULL,
	[USERID]		[varchar] (63) NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[DIM_0_LEVEL]		[int] NOT NULL,
	[DIM_1_LEVEL]		[int] NOT NULL,
	[DIM_2_LEVEL]		[int] NOT NULL,
	[DIM_3_LEVEL]		[int] NOT NULL,
	[DIM_4_LEVEL]		[int] NOT NULL,
	[DIM_5_LEVEL]		[int] NOT NULL,
	[DIM_6_LEVEL]		[int] NOT NULL,
	[DIM_7_LEVEL]		[int] NOT NULL,
	[DESCRIPTION]		[varchar] (100) NOT NULL,
	[LOCK_TIME]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_SCHEDLOCKS] (
	[LOCK_ID]		[int] NOT NULL,
	[USERID]		[varchar] (63) NOT NULL,
	[SCHEDULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[DIM_0_LEVEL]		[int] NOT NULL,
	[DIM_1_LEVEL]		[int] NOT NULL,
	[DIM_2_LEVEL]		[int] NOT NULL,
	[DIM_3_LEVEL]		[int] NOT NULL,
	[DIM_4_LEVEL]		[int] NOT NULL,
	[DIM_5_LEVEL]		[int] NOT NULL,
	[DIM_6_LEVEL]		[int] NOT NULL,
	[DIM_7_LEVEL]		[int] NOT NULL,
	[EDIM_0_LEVEL]		[int] NOT NULL,
	[EDIM_1_LEVEL]		[int] NOT NULL,
	[EDIM_2_LEVEL]		[int] NOT NULL,
	[DESCRIPTION]		[varchar] (100) NOT NULL,
	[LOCK_TIME]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WFTASK] (
	[WF_ID]		[int] NOT NULL,
	[WF_TYPE]		[int] NOT NULL,
	[WF_PROCESS]		[int] NOT NULL,
	[WF_DESTINATION]		[int] NOT NULL,
	[WF_NAME]		[varchar] (100) NOT NULL,
	[WF_VIEW]		[varchar] (255) NOT NULL,
	[CREATOR_ID]		[int] NOT NULL,
	[WF_CREATED]		[datetime] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WFTASK_STATE] (
	[WF_ID]		[int] NOT NULL,
	[USER_ID]		[int] NOT NULL,
	[WF_MODIFIED]		[datetime] NOT NULL,
	[WF_COMMENT]		[varchar] (4000) NOT NULL,
	[WF_STATUS]		[int] NOT NULL,
	[WF_SHARED]		[varchar] (1) NOT NULL,
	[WF_ACTIVE]		[varchar] (1) NOT NULL,
	[WF_OVERWRITE]		[varchar] (1) NOT NULL,
	[WF_CERTIFIED]		[varchar] (1) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WFTASK_HIERMAP] (
	[WF_ID]		[int] NOT NULL,
	[DIM_INDEX]		[int] NOT NULL,
	[SYM_INDEX]		[int] NOT NULL,
	[SYM_LEVEL]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WFTASK_DATA] (
	[WF_ID]		[int] NOT NULL,
	[DIM_INDEX]		[int] NOT NULL,
	[SYM_INDEX]		[int] NOT NULL,
	[SYM_LEVEL]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WFTASK_USER] (
	[WF_ID]		[int] NOT NULL,
	[CLASS_ID]		[int] NOT NULL,
	[OBJ_ID]		[int] NOT NULL,
	[WF_ROLE]		[varchar] (1) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WFTASK_LOG] (
	[WF_ID]		[int] NOT NULL,
	[USER_ID]		[int] NOT NULL,
	[WF_MODIFIED]		[datetime] NOT NULL,
	[WF_COMMENT]		[varchar] (4000) NOT NULL,
	[WF_STATUS]		[int] NOT NULL,
	[WF_SHARED]		[varchar] (1) NOT NULL,
	[WF_ACTIVE]		[varchar] (1) NOT NULL,
	[WF_OVERWRITE]		[varchar] (1) NOT NULL,
	[WF_CERTIFIED]		[varchar] (1) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WFAREA_STATE] (
	[WF_ID]		[int] NOT NULL,
	[DIM_INDEX]		[int] NOT NULL,
	[SYM_INDEX]		[int] NOT NULL,
	[USER_ID]		[int] NOT NULL,
	[WF_MODIFIED]		[datetime] NOT NULL,
	[WF_COMMENT]		[varchar] (4000) NOT NULL,
	[WF_STATUS]		[int] NOT NULL,
	[WF_SHARED]		[varchar] (1) NOT NULL,
	[WF_ACTIVE]		[varchar] (1) NOT NULL,
	[WF_OVERWRITE]		[varchar] (1) NOT NULL,
	[WF_CERTIFIED]		[varchar] (1) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WFAREA_LOG] (
	[WF_ID]		[int] NOT NULL,
	[DIM_INDEX]		[int] NOT NULL,
	[SYM_INDEX]		[int] NOT NULL,
	[USER_ID]		[int] NOT NULL,
	[WF_MODIFIED]		[datetime] NOT NULL,
	[WF_COMMENT]		[varchar] (4000) NOT NULL,
	[WF_STATUS]		[int] NOT NULL,
	[WF_SHARED]		[varchar] (1) NOT NULL,
	[WF_ACTIVE]		[varchar] (1) NOT NULL,
	[WF_OVERWRITE]		[varchar] (1) NOT NULL,
	[WF_CERTIFIED]		[varchar] (1) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WF_EMAIL] (
	[WF_ID]		[int] NOT NULL,
	[WF_FROM_STATUS]		[int] NOT NULL,
	[WF_TO_STATUS]		[int] NOT NULL,
	[EMAIL_TO]		[varchar] (10) NOT NULL,
	[EMAIL_CC]		[varchar] (10) NOT NULL,
	[EMAIL_SUBJECT]		[varchar] (255) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_WFTASK_LOCK] (
	[LOCK_ID]		[int] NOT NULL,
	[WF_ID]		[int] NOT NULL,
	[DIM_INDEX]		[int] NOT NULL,
	[SYM_INDEX]		[int] NOT NULL,
	[USER_ID]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_MODEL] (
	[RULE_ID]		[int] NOT NULL,
	[RULE_TYPE]		[int] NOT NULL,
	[MRULE]		[varchar] (1280) NOT NULL,
	[LINE_NUM]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_SYMBOL_STATS] (
	[DIM_INDEX]		[int] NOT NULL,
	[SYM_INDEX]		[int] NOT NULL,
	[FAMILY]		[int] NOT NULL,
	[TYPE]		[int] NOT NULL,
	[DATACOUNT]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_SHARED_FILES] (
	[GRP_ID]		[int] NOT NULL,
	[FILE_TYPE]		[int] NOT NULL,
	[FILE_NAME]		[varchar] (100) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_FILE_CAT_ASSIGNMENT] (
	[FILE_NAME]		[varchar] (100) NOT NULL,
	[CATEGORY_ID]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_CATEGORIES] (
	[CATEGORY_ID]		[int] NOT NULL,
	[CATEGORY_NAME]		[varchar] (100) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_EVENT_ACTION] (
	[EVENT_ID]		[int] NOT NULL,
	[RULE_ID]		[int] NOT NULL,
	[LAST_ACTION]		[datetime] NOT NULL,
	[PENDING]		[int] NOT NULL,
	[FILENAME]		[varchar] (100) NOT NULL,
	[IN_PROGRESS]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_EVENT] (
	[EVENT_ID]		[int] NOT NULL,
	[RULE_ID]		[int] NOT NULL,
	[START_DATE]		[datetime] NOT NULL,
	[END_DATE]		[datetime] NOT NULL,
	[STATUS]		[int] NOT NULL,
	[COMMENTS]		[varchar] (100) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_EVENT_FROM_BATCH] (
	[EVENT_ID]		[int] NOT NULL,
	[FROM_BATCH_ID]		[int] NOT NULL,
	[CREATED]		[datetime] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_EVENT_AREA_DETAIL] (
	[EVENT_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_ROLE] (
	[ROLE_ID]		[int] NOT NULL,
	[ROLE_NAME]		[varchar] (31) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_ROLE_ACC] (
	[ROLE_ID]		[int] NOT NULL,
	[ROLE_TYPE]		[int] NOT NULL,
	[DIM_INDEX]		[int] NOT NULL,
	[PARENT_INDEX]		[int] NOT NULL,
	[ACCESS_LEVEL]		[int] NOT NULL,
	[SYM_ACCESS]		[varchar] (1) NOT NULL,
	[ACCESS_PRIORITY]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_DATA_STATUS] (
	[STATUS_ID]		[int] NOT NULL,
	[STATUS_NAME]		[varchar] (31) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_AREA_SPEC] (
	[AREA_ID]		[int] NOT NULL,
	[DIM_INDEX]		[int] NOT NULL,
	[SYM_INDEX]		[int] NOT NULL,
	[AREA_LEVEL]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_AREA_STATE] (
	[AREA_ID]		[int] NOT NULL,
	[SCHEDULE_ID]		[int] NOT NULL,
	[STATUS_ID]		[int] NOT NULL,
	[LAST_UPDATE]		[datetime] NOT NULL,
	[AREA_COMMENT]		[varchar] (4000) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_SYM_MAPS] (
	[MAP_INDEX]		[int] NOT NULL,
	[DIM_INDEX]		[int] NOT NULL,
	[SCHEDULE_ID]		[int] NOT NULL,
	[LOCKED_USER]		[varchar] (63) NOT NULL,
	[LOCKED_SID]		[int] NOT NULL,
	[MAP_NAME]		[varchar] (255) NOT NULL,
	[TAG]		[varchar] (255) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_SYM_MAPPINGS] (
	[MAP_INDEX]		[int] NOT NULL,
	[MAPPING_INDEX]		[int] NOT NULL,
	[SYM_INDEX]		[int] NOT NULL,
	[METHOD]		[int] NOT NULL,
	[EXPRESSION]		[varchar] (255) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_FILE_DATA] (
	[FILE_GUID]		[binary] (16) NOT NULL,
	[VERSION_ID]		[int] NOT NULL DEFAULT (1),
	[MIME_TYPE]		[varchar] (256) NOT NULL,
	[ENCODING]		[varchar] (256) NOT NULL,
	[LENGTH]		[int] NOT NULL,
	[DATA]		[image] NOT NULL,
	[CREATED_BY]		[varchar] (256) NOT NULL,
	[CREATION_TIMESTAMP]		[datetime] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_FILE_DESC] (
	[FILE_GUID]		[binary] (16) NOT NULL,
	[FILE_NAME]		[varchar] (896) NOT NULL,
	[FILE_DIR_ID]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_FILE_DIR] (
	[ID]		[int] NOT NULL,
	[DIR_NAME]		[varchar] (256) NOT NULL,
	[PARENT_ID]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_USER_MAIN] (
	[USER_ID]		[int] NOT NULL,
	[USER_NAME]		[varchar] (63) NOT NULL,
	[DESCRIPTION]		[varchar] (100) NOT NULL,
	[LAST_UPDATE]		[datetime] NOT NULL,
	[LAST_LOGIN]		[datetime] NOT NULL,
	[FAIL_ATTEMPT]		[int] NOT NULL,
	[DOMAIN]		[varchar] (50) NOT NULL,
	[AUTH_TYPE]		[int] NOT NULL,
	[USER_STATUS]		[int] NOT NULL,
	[CREATE_DATE]		[datetime] NOT NULL,
	[DELETE_DATE]		[datetime] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_USER_PASSWORD_HISTORY] (
	[HISTORY_KEY]		[int] NOT NULL,
	[USER_ID]		[int] NOT NULL,
	[CREATE_DATE]		[datetime] NOT NULL,
	[PASSWORD]		[varchar] (100) NOT NULL,
	[SALT]		[varchar] (63) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_USER_DETAILS] (
	[USER_ID]		[int] NOT NULL,
	[LAST_NAME]		[varchar] (50) NOT NULL,
	[FIRST_NAME]		[varchar] (50) NOT NULL,
	[EMAIL]		[varchar] (100) NOT NULL,
	[OFFICE_PHONE]		[varchar] (50) NOT NULL,
	[HOME_PHONE]		[varchar] (50) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_USER_LICENSES] (
	[USER_ID]		[int] NOT NULL,
	[LICENSES]		[varchar] (63) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_USER_PASSWORD] (
	[USER_ID]		[int] NOT NULL,
	[PASSWORD]		[varchar] (100) NOT NULL,
	[PASSWORD_DATE]		[datetime] NOT NULL,
	[PASSWORD_RESET]		[int] NOT NULL,
	[PASSWORD_RESET_EXPIRY]		[int] NOT NULL,
	[PASSWORD_RESET_TOKEN]		[varchar] (63) NOT NULL,
	[SALT]		[varchar] (63) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_GROUP_MAIN] (
	[GROUP_ID]		[int] NOT NULL,
	[NAME]		[varchar] (63) NOT NULL,
	[CREATE_TIME]		[datetime] NOT NULL,
	[UPDATE_TIME]		[datetime] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_USER_GROUP] (
	[USER_ID]		[int] NOT NULL,
	[GROUP_ID]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_OPERATIONS] (
	[OPERATION_ID]		[int] NOT NULL,
	[NAME]		[varchar] (63) NOT NULL,
	[DESCRIPTION]		[varchar] (100) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_GROUP_OPERATIONS] (
	[GROUP_ID]		[int] NOT NULL,
	[OPERATION_ID]		[int] NOT NULL,
	[OBJECT_ID]		[int] NOT NULL,
	[LAST_UPDATE]		[datetime] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_USER_OPERATIONS] (
	[USER_ID]		[int] NOT NULL,
	[OPERATION_ID]		[int] NOT NULL,
	[OBJECT_ID]		[int] NOT NULL,
	[LAST_UPDATE]		[datetime] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_AUDIT_METADATA] (
	[DATE_TIME]		[datetime] NOT NULL,
	[USER_NAME]		[varchar] (63) NOT NULL,
	[IP]		[varchar] (63) NOT NULL,
	[CATEGORY]		[int] NOT NULL,
	[ACTIVITY]		[varchar] (4000) NOT NULL,
	[ID]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_APPTABLES] (
	[TABLEID]		[int] NOT NULL,
	[TABLENAME]		[varchar] (30) NOT NULL,
	[USERCOLUMNSECURITY]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_APPTABLE_COLUMNS] (
	[COLUMNID]		[int] NOT NULL,
	[TABLEID]		[int] NOT NULL,
	[COLUMNNAME]		[varchar] (30) NOT NULL,
	[DATATYPE]		[varchar] (20) NOT NULL,
	[DATAVALUES]		[varchar] (4000) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_ITEMS] (
	[ID]		[int] NOT NULL,
	[NAME]		[varchar] (63) NOT NULL,
	[TYPE]		[varchar] (63) NOT NULL,
	[PROPERTIES]		[varchar] (4000) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_ITEM_RELATIONSHIPS] (
	[PARENT_ID]		[int] NOT NULL,
	[SEQUENCE]		[int] NOT NULL,
	[CHILD_ID]		[int] NOT NULL,
	[PROPERTIES]		[varchar] (4000) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[LV_ITEM_GROUP] (
	[ITEM_ID]		[int] NOT NULL,
	[GROUP_ID]		[int] NOT NULL,
	[SEQUENCE]		[int] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_ACN_P000_CELLS] (
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_ALN_P000_CELLS] (
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_APN_P000_CELLS] (
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_ATN_P000_CELLS] (
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_AVN_P000_CELLS] (
	[RULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_JCN_P000_CELLS] (
	[SCHEDULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_JLN_P000_CELLS] (
	[SCHEDULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_JPN_P000_CELLS] (
	[SCHEDULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_JTN_P000_CELLS] (
	[SCHEDULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_JVN_P000_CELLS] (
	[RULE_ID]		[int] NOT NULL,
	[SCHEDULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_SCN_P000_CELLS] (
	[SCHEDULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_SLN_P000_CELLS] (
	[SCHEDULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_SLS_P000_CELLS] (
	[SCHEDULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[STRING_VALUE]		[varchar] (4000) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_SPN_P000_CELLS] (
	[SCHEDULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_STN_P000_CELLS] (
	[SCHEDULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_SVN_P000_CELLS] (
	[RULE_ID]		[int] NOT NULL,
	[SCHEDULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_SLN_P000_AUDIT] (
	[BATCH_ID]		[int] NOT NULL,
	[SCHEDULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[EDIM_0_INDEX]		[int] NOT NULL,
	[EDIM_1_INDEX]		[int] NOT NULL,
	[EDIM_2_INDEX]		[int] NOT NULL,
	[DELTA_VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_UCN_P000_CELLS] (
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_ULN_P000_CELLS] (
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_ULS_P000_CELLS] (
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[STRING_VALUE]		[varchar] (4000) NOT NULL
)
ON [KLX_BASE_DAT]
GO



CREATE TABLE [dbo].[KLX_UPN_P000_CELLS] (
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_UTN_P000_CELLS] (
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_UVN_P000_CELLS] (
	[RULE_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[NUMERIC_VALUE]		[float] NOT NULL
)
ON [KLX_DERIVED_DAT]
GO



CREATE TABLE [dbo].[KLX_ULN_P000_AUDIT] (
	[BATCH_ID]		[int] NOT NULL,
	[DIM_0_INDEX]		[int] NOT NULL,
	[DIM_1_INDEX]		[int] NOT NULL,
	[DIM_2_INDEX]		[int] NOT NULL,
	[DIM_3_INDEX]		[int] NOT NULL,
	[DIM_4_INDEX]		[int] NOT NULL,
	[DIM_5_INDEX]		[int] NOT NULL,
	[DIM_6_INDEX]		[int] NOT NULL,
	[DIM_7_INDEX]		[int] NOT NULL,
	[DELTA_VALUE]		[float] NOT NULL
)
ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_MASTER_DIM_PK] ON [dbo].[KLX_MASTER_DIM]([DIM_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_DESC_PK] ON [dbo].[KLX_DESC]([DESC_TYPE], [LANG_CODE], [MAJOR_OBJ_ID], [MINOR_OBJ_ID], [MICRO_OBJ_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_MASTER_SYMBOL_PK] ON [dbo].[KLX_MASTER_SYMBOL]([DIM_INDEX], [SYM_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE INDEX [KLX_MASTER_SYMBOL_IDX1] ON [dbo].[KLX_MASTER_SYMBOL]([SYM_NAME]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_SYM_DESC_PK] ON [dbo].[KLX_SYM_DESC]([DESC_TYPE], [LANG_CODE], [MAJOR_OBJ_ID], [MINOR_OBJ_ID], [MICRO_OBJ_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_PARENT_CHILD_PK] ON [dbo].[KLX_PARENT_CHILD]([DIM_INDEX], [SYM_INDEX], [PARENT_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_ATTRIBUTES_PK] ON [dbo].[KLX_ATTRIBUTES]([CLASS_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_ATTR_DEFS_PK] ON [dbo].[KLX_ATTR_DEFS]([ATTR_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE INDEX [KLX_ATTR_DEFS_IDX1] ON [dbo].[KLX_ATTR_DEFS]([ATTR_NAME]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_SYMATTR_NUMVAL_PK] ON [dbo].[KLX_SYMATTR_NUMVAL]([OBJ_ID], [ATTR_ID], [ITEM_NO]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_SYMATTR_STRVAL_PK] ON [dbo].[KLX_SYMATTR_STRVAL]([OBJ_ID], [ATTR_ID], [ITEM_NO]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_SYSATTR_NUMVAL_PK] ON [dbo].[KLX_SYSATTR_NUMVAL]([OBJ_ID], [ATTR_ID], [ITEM_NO]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_SYSATTR_STRVAL_PK] ON [dbo].[KLX_SYSATTR_STRVAL]([OBJ_ID], [ATTR_ID], [ITEM_NO]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_USRATTR_NUMVAL_PK] ON [dbo].[KLX_USRATTR_NUMVAL]([OBJ_ID], [ATTR_ID], [ITEM_NO]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_USRATTR_STRVAL_PK] ON [dbo].[KLX_USRATTR_STRVAL]([OBJ_ID], [ATTR_ID], [ITEM_NO]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_USER_GRP_ACC_PK] ON [dbo].[KLX_USER_GRP_ACC]([OBJ_ID], [DIM_INDEX], [PARENT_INDEX], [ACCESS_LEVEL], [ROLE_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_USER_SYM_ACC_PK] ON [dbo].[KLX_USER_SYM_ACC]([OBJ_ID], [DIM_INDEX], [PARENT_INDEX], [ACCESS_LEVEL], [ROLE_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_OBJ_STAMPS_PK] ON [dbo].[KLX_OBJ_STAMPS]([STAMP_TYPE], [CLASS_ID], [OBJ_ID], [STAMP_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_STATUS_PK] ON [dbo].[KLX_STATUS]([PARAMETER]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_PARTITIONS_PK] ON [dbo].[KLX_PARTITIONS]([PART_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE INDEX [KLX_PARTITIONS_IDX1] ON [dbo].[KLX_PARTITIONS]([DIM_7_PART], [DIM_6_PART], [DIM_5_PART], [DIM_4_PART], [DIM_3_PART], [DIM_2_PART], [DIM_0_PART], [DIM_1_PART]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_WEB_PG_GROUPS_PK] ON [dbo].[KLX_WEB_PG_GROUPS]([GROUP_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_WEB_PAGES_PK] ON [dbo].[KLX_WEB_PAGES]([PAGE_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE INDEX [KLX_WEB_PAGES_IDX1] ON [dbo].[KLX_WEB_PAGES]([PAGE_NAME]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_WEB_PANELS_PK] ON [dbo].[KLX_WEB_PANELS]([PANEL_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE INDEX [KLX_WEB_PANELS_IDX1] ON [dbo].[KLX_WEB_PANELS]([PANEL_NAME]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_WEB_PANEL_ITMS_PK] ON [dbo].[KLX_WEB_PANEL_ITMS]([PANEL_ID], [ITEM_NO]) ON [KLX_BASE_DAT]
GO


CREATE CLUSTERED INDEX [KLX_WEB_PG_PANELS_PK] ON [dbo].[KLX_WEB_PG_PANELS]([PAGE_ID], [ASSIGNMENT_TYPE]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_JE_HEADER_PK] ON [dbo].[KLX_JE_HEADER]([JE_CATEGORY], [CREATED_TP_IDX], [JE_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_JE_SUBCATEGORIES_PK] ON [dbo].[KLX_JE_SUBCATEGORIES]([JE_CATEGORY], [SUB_CATEGORY]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_JE_GROUPS_PK] ON [dbo].[KLX_JE_GROUPS]([JE_CATEGORY], [CREATED_TP_IDX], [JE_ID], [GROUP_ID]) ON [KLX_BASE_DAT]
GO


CREATE CLUSTERED INDEX [KLX_JEC_DETAIL_PK] ON [dbo].[KLX_JEC_DETAIL]([JE_CATEGORY], [CREATED_TP_IDX], [JE_ID], [LINE_NUMBER]) ON [KLX_BASE_DAT]
GO


CREATE CLUSTERED INDEX [KLX_JEL_DETAIL_PK] ON [dbo].[KLX_JEL_DETAIL]([JE_CATEGORY], [CREATED_TP_IDX], [JE_ID], [LINE_NUMBER]) ON [KLX_BASE_DAT]
GO


CREATE CLUSTERED INDEX [KLX_JET_DETAIL_PK] ON [dbo].[KLX_JET_DETAIL]([JE_CATEGORY], [CREATED_TP_IDX], [JE_ID], [LINE_NUMBER]) ON [KLX_BASE_DAT]
GO


CREATE CLUSTERED INDEX [KLX_JESL_DETAIL_PK] ON [dbo].[KLX_JESL_DETAIL]([JE_CATEGORY], [CREATED_TP_IDX], [JE_ID], [LINE_NUMBER], [SUB_LINE_NUMBER]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_JE_HEADER_BAK000_PK] ON [dbo].[KLX_JE_HEADER_BAK000]([JE_CATEGORY], [CREATED_TP_IDX], [JE_ID]) ON [KLX_BASE_DAT]
GO


CREATE CLUSTERED INDEX [KLX_JEC_DETAIL_BAK000_PK] ON [dbo].[KLX_JEC_DETAIL_BAK000]([JE_CATEGORY], [CREATED_TP_IDX], [JE_ID], [LINE_NUMBER]) ON [KLX_BASE_DAT]
GO


CREATE CLUSTERED INDEX [KLX_JEL_DETAIL_BAK000_PK] ON [dbo].[KLX_JEL_DETAIL_BAK000]([JE_CATEGORY], [CREATED_TP_IDX], [JE_ID], [LINE_NUMBER]) ON [KLX_BASE_DAT]
GO


CREATE CLUSTERED INDEX [KLX_JET_DETAIL_BAK000_PK] ON [dbo].[KLX_JET_DETAIL_BAK000]([JE_CATEGORY], [CREATED_TP_IDX], [JE_ID], [LINE_NUMBER]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_JE_FILE_ATTACHMENT_PK] ON [dbo].[KLX_JE_FILE_ATTACHMENT]([JE_CATEGORY], [CREATED_TP_IDX], [JE_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_IC_HEADER_PK] ON [dbo].[KLX_IC_HEADER]([TRANS_ID]) ON [KLX_BASE_DAT]
GO


CREATE INDEX [KLX_IC_HEADER_IDX1] ON [dbo].[KLX_IC_HEADER]([REPORTER], [CONTRA_REPORTER]) ON [KLX_BASE_DAT]
GO


CREATE INDEX [KLX_IC_HEADER_IDX2] ON [dbo].[KLX_IC_HEADER]([CONTRA_REPORTER]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_IC_STOCK_PK] ON [dbo].[KLX_IC_STOCK]([STOCK_ID], [INV_ID], [LINE_NUMBER]) ON [KLX_BASE_DAT]
GO


CREATE INDEX [KLX_IC_STOCK_IDX1] ON [dbo].[KLX_IC_STOCK]([STOCK_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_IC_TRANS_ELIM_PK] ON [dbo].[KLX_IC_TRANS_ELIM]([TRANS_ID], [ELIM_ENTITY], [LINE_NUMBER]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_ICC_TXN_PK] ON [dbo].[KLX_ICC_TXN]([TRANS_ID], [ACCOUNT], [TIMEPERIOD], [FIXED_DIM1], [FIXED_DIM2], [FIXED_DIM3], [FIXED_DIM4], [FIXED_DIM5], [LINE_NUMBER]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_ICL_TXN_PK] ON [dbo].[KLX_ICL_TXN]([TRANS_ID], [ACCOUNT], [TIMEPERIOD], [FIXED_DIM1], [FIXED_DIM2], [FIXED_DIM3], [FIXED_DIM4], [FIXED_DIM5], [LINE_NUMBER]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_ICT_TXN_PK] ON [dbo].[KLX_ICT_TXN]([TRANS_ID], [ACCOUNT], [TIMEPERIOD], [FIXED_DIM1], [FIXED_DIM2], [FIXED_DIM3], [FIXED_DIM4], [FIXED_DIM5], [LINE_NUMBER]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_IC_OWN_PCT_PK] ON [dbo].[KLX_IC_OWN_PCT]([ACCOUNT], [TIMEPERIOD], [REPORTER], [CONTRA_REPORTER], [SCHEDULE_ID], [EDIM_2_INDEX], [EDIM_1_INDEX], [EDIM_0_INDEX], [FIXED_DIM1], [FIXED_DIM2], [FIXED_DIM3], [FIXED_DIM4], [FIXED_DIM5], [TYPE], [VALUE]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_IC_OBJECT_PK] ON [dbo].[KLX_IC_OBJECT]([IC_OBJ_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE INDEX [KLX_IC_OBJECT_IDX1] ON [dbo].[KLX_IC_OBJECT]([IC_OBJ_NAME], [IC_OBJ_OFFSET_ACCT], [IC_OBJ_SUB_CATEGORY]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_SCHEDULES_PK] ON [dbo].[KLX_SCHEDULES]([SCHEDULE_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_SCHED_DIMS_PK] ON [dbo].[KLX_SCHED_DIMS]([SCHEDULE_ID], [EXTRADIM_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_BATCH_PK] ON [dbo].[KLX_BATCH]([BATCH_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_BATCH_DETAIL_PK] ON [dbo].[KLX_BATCH_DETAIL]([BATCH_ID], [SERVER_ID], [REF_2_ID], [REF_3_ID], [FILENAME]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_BATCH_FROM_EVENT_PK] ON [dbo].[KLX_BATCH_FROM_EVENT]([BATCH_ID], [FROM_EVENT_ID]) ON [KLX_BASE_DAT]
GO


CREATE CLUSTERED INDEX [KLX_BATCH_AREA_DETAIL_PK] ON [dbo].[KLX_BATCH_AREA_DETAIL]([BATCH_ID]) ON [KLX_BASE_DAT]
GO


CREATE CLUSTERED INDEX [KLX_DATALOCKS_PK] ON [dbo].[KLX_DATALOCKS]([LOCK_ID]) ON [KLX_BASE_DAT]
GO


CREATE CLUSTERED INDEX [KLX_SCHEDLOCKS_PK] ON [dbo].[KLX_SCHEDLOCKS]([LOCK_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_WFTASK_PK] ON [dbo].[KLX_WFTASK]([WF_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_WFTASK_STATE_PK] ON [dbo].[KLX_WFTASK_STATE]([WF_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_WFTASK_HIERMAP_PK] ON [dbo].[KLX_WFTASK_HIERMAP]([WF_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_WFTASK_DATA_PK] ON [dbo].[KLX_WFTASK_DATA]([WF_ID], [DIM_INDEX], [SYM_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_WFTASK_USER_PK] ON [dbo].[KLX_WFTASK_USER]([WF_ID], [CLASS_ID], [OBJ_ID], [WF_ROLE]) ON [KLX_BASE_DAT]
GO


CREATE CLUSTERED INDEX [KLX_WFTASK_LOG_PK] ON [dbo].[KLX_WFTASK_LOG]([WF_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_WFAREA_STATE_PK] ON [dbo].[KLX_WFAREA_STATE]([WF_ID], [DIM_INDEX], [SYM_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE CLUSTERED INDEX [KLX_WFAREA_LOG_PK] ON [dbo].[KLX_WFAREA_LOG]([WF_ID], [DIM_INDEX], [SYM_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_WF_EMAIL_PK] ON [dbo].[KLX_WF_EMAIL]([WF_ID], [WF_FROM_STATUS], [WF_TO_STATUS]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_WFTASK_LOCK_PK] ON [dbo].[KLX_WFTASK_LOCK]([LOCK_ID], [WF_ID], [DIM_INDEX], [SYM_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_MODEL_PK] ON [dbo].[KLX_MODEL]([RULE_ID], [LINE_NUM]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_SYMBOL_STATS_PK] ON [dbo].[KLX_SYMBOL_STATS]([DIM_INDEX], [SYM_INDEX], [FAMILY], [TYPE]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_FILE_CAT_ASSIGNMENT_PK] ON [dbo].[KLX_FILE_CAT_ASSIGNMENT]([FILE_NAME], [CATEGORY_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_CATEGORIES_PK] ON [dbo].[KLX_CATEGORIES]([CATEGORY_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE INDEX [KLX_CATEGORIES_IDX1] ON [dbo].[KLX_CATEGORIES]([CATEGORY_NAME]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_EVENT_ACTION_PK] ON [dbo].[LV_EVENT_ACTION]([EVENT_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_EVENT_PK] ON [dbo].[LV_EVENT]([EVENT_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_EVENT_FROM_BATCH_PK] ON [dbo].[LV_EVENT_FROM_BATCH]([EVENT_ID], [FROM_BATCH_ID]) ON [KLX_BASE_DAT]
GO


CREATE CLUSTERED INDEX [LV_EVENT_AREA_DETAIL_PK] ON [dbo].[LV_EVENT_AREA_DETAIL]([EVENT_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_ROLE_PK] ON [dbo].[LV_ROLE]([ROLE_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE INDEX [LV_ROLE_IDX1] ON [dbo].[LV_ROLE]([ROLE_NAME]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_ROLE_ACC_PK] ON [dbo].[LV_ROLE_ACC]([ROLE_ID], [ROLE_TYPE], [DIM_INDEX], [PARENT_INDEX], [ACCESS_LEVEL]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_DATA_STATUS_PK] ON [dbo].[LV_DATA_STATUS]([STATUS_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE INDEX [LV_DATA_STATUS_IDX1] ON [dbo].[LV_DATA_STATUS]([STATUS_NAME]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_AREA_SPEC_PK] ON [dbo].[LV_AREA_SPEC]([AREA_ID], [DIM_INDEX], [SYM_INDEX], [AREA_LEVEL]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_AREA_STATE_PK] ON [dbo].[LV_AREA_STATE]([AREA_ID], [SCHEDULE_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_SYM_MAPS_PK] ON [dbo].[LV_SYM_MAPS]([MAP_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE INDEX [LV_SYM_MAPS_IDX1] ON [dbo].[LV_SYM_MAPS]([MAP_NAME]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_SYM_MAPPINGS_PK] ON [dbo].[LV_SYM_MAPPINGS]([MAP_INDEX], [MAPPING_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_FILE_DATA_PK] ON [dbo].[LV_FILE_DATA]([FILE_GUID], [VERSION_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_FILE_DESC_PK] ON [dbo].[LV_FILE_DESC]([FILE_GUID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE INDEX [LV_FILE_DESC_IDX1] ON [dbo].[LV_FILE_DESC]([FILE_NAME], [FILE_DIR_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_FILE_DIR_PK] ON [dbo].[LV_FILE_DIR]([ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE INDEX [LV_FILE_DIR_IDX1] ON [dbo].[LV_FILE_DIR]([DIR_NAME], [PARENT_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_USER_MAIN_PK] ON [dbo].[LV_USER_MAIN]([USER_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_USER_PASSWORD_HISTORY_PK] ON [dbo].[LV_USER_PASSWORD_HISTORY]([HISTORY_KEY]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_USER_DETAILS_PK] ON [dbo].[LV_USER_DETAILS]([USER_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_USER_LICENSES_PK] ON [dbo].[LV_USER_LICENSES]([USER_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_USER_PASSWORD_PK] ON [dbo].[LV_USER_PASSWORD]([USER_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_GROUP_MAIN_PK] ON [dbo].[LV_GROUP_MAIN]([GROUP_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE INDEX [LV_GROUP_MAIN_IDX1] ON [dbo].[LV_GROUP_MAIN]([NAME]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_USER_GROUP_PK] ON [dbo].[LV_USER_GROUP]([USER_ID], [GROUP_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_OPERATIONS_PK] ON [dbo].[LV_OPERATIONS]([OPERATION_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE INDEX [LV_OPERATIONS_IDX1] ON [dbo].[LV_OPERATIONS]([NAME]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_GROUP_OPERATIONS_PK] ON [dbo].[LV_GROUP_OPERATIONS]([GROUP_ID], [OPERATION_ID], [OBJECT_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_USER_OPERATIONS_PK] ON [dbo].[LV_USER_OPERATIONS]([USER_ID], [OPERATION_ID], [OBJECT_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_AUDIT_ME_AUD_PK] ON [dbo].[LV_AUDIT_METADATA]([ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_APPTABLES_PK] ON [dbo].[LV_APPTABLES]([TABLEID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_APPTABLE_COLUMNS_PK] ON [dbo].[LV_APPTABLE_COLUMNS]([COLUMNID], [TABLEID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_ITEMS_PK] ON [dbo].[LV_ITEMS]([ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_ITEM_RELATIONSHIPS_PK] ON [dbo].[LV_ITEM_RELATIONSHIPS]([PARENT_ID], [SEQUENCE]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [LV_ITEM_GROUP_PK] ON [dbo].[LV_ITEM_GROUP]([ITEM_ID], [GROUP_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_ACN_P000_PK] ON [dbo].[KLX_ACN_P000_CELLS]([DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_ALN_P000_PK] ON [dbo].[KLX_ALN_P000_CELLS]([DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_APN_P000_PK] ON [dbo].[KLX_APN_P000_CELLS]([DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_ATN_P000_PK] ON [dbo].[KLX_ATN_P000_CELLS]([DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_AVN_P000_PK] ON [dbo].[KLX_AVN_P000_CELLS]([RULE_ID], [DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_JCN_P000_PK] ON [dbo].[KLX_JCN_P000_CELLS]([SCHEDULE_ID], [DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX], [EDIM_2_INDEX], [EDIM_1_INDEX], [EDIM_0_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_JLN_P000_PK] ON [dbo].[KLX_JLN_P000_CELLS]([SCHEDULE_ID], [DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX], [EDIM_2_INDEX], [EDIM_1_INDEX], [EDIM_0_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_JPN_P000_PK] ON [dbo].[KLX_JPN_P000_CELLS]([SCHEDULE_ID], [DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX], [EDIM_2_INDEX], [EDIM_1_INDEX], [EDIM_0_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_JTN_P000_PK] ON [dbo].[KLX_JTN_P000_CELLS]([SCHEDULE_ID], [DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX], [EDIM_2_INDEX], [EDIM_1_INDEX], [EDIM_0_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_JVN_P000_PK] ON [dbo].[KLX_JVN_P000_CELLS]([RULE_ID], [SCHEDULE_ID], [DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX], [EDIM_2_INDEX], [EDIM_1_INDEX], [EDIM_0_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_SCN_P000_PK] ON [dbo].[KLX_SCN_P000_CELLS]([SCHEDULE_ID], [DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX], [EDIM_2_INDEX], [EDIM_1_INDEX], [EDIM_0_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_SLN_P000_PK] ON [dbo].[KLX_SLN_P000_CELLS]([SCHEDULE_ID], [DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX], [EDIM_2_INDEX], [EDIM_1_INDEX], [EDIM_0_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_SLS_P000_PK] ON [dbo].[KLX_SLS_P000_CELLS]([SCHEDULE_ID], [DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX], [EDIM_2_INDEX], [EDIM_1_INDEX], [EDIM_0_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_SPN_P000_PK] ON [dbo].[KLX_SPN_P000_CELLS]([SCHEDULE_ID], [DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX], [EDIM_2_INDEX], [EDIM_1_INDEX], [EDIM_0_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_STN_P000_PK] ON [dbo].[KLX_STN_P000_CELLS]([SCHEDULE_ID], [DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX], [EDIM_2_INDEX], [EDIM_1_INDEX], [EDIM_0_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_SVN_P000_PK] ON [dbo].[KLX_SVN_P000_CELLS]([RULE_ID], [SCHEDULE_ID], [DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX], [EDIM_2_INDEX], [EDIM_1_INDEX], [EDIM_0_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE CLUSTERED INDEX [KLX_SLN_P000_AUD_PK] ON [dbo].[KLX_SLN_P000_AUDIT]([BATCH_ID]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_UCN_P000_PK] ON [dbo].[KLX_UCN_P000_CELLS]([DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_ULN_P000_PK] ON [dbo].[KLX_ULN_P000_CELLS]([DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_ULS_P000_PK] ON [dbo].[KLX_ULS_P000_CELLS]([DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX]) ON [KLX_BASE_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_UPN_P000_PK] ON [dbo].[KLX_UPN_P000_CELLS]([DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_UTN_P000_PK] ON [dbo].[KLX_UTN_P000_CELLS]([DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE UNIQUE CLUSTERED INDEX [KLX_UVN_P000_PK] ON [dbo].[KLX_UVN_P000_CELLS]([RULE_ID], [DIM_7_INDEX], [DIM_6_INDEX], [DIM_5_INDEX], [DIM_4_INDEX], [DIM_3_INDEX], [DIM_2_INDEX], [DIM_0_INDEX], [DIM_1_INDEX]) ON [KLX_DERIVED_DAT]
GO


CREATE CLUSTERED INDEX [KLX_ULN_P000_AUD_PK] ON [dbo].[KLX_ULN_P000_AUDIT]([BATCH_ID]) ON [KLX_BASE_DAT]
GO


CREATE NONCLUSTERED INDEX [IDX_KLX_BATCH_DETAIL_STATUS_INC_END_DATE] ON [dbo].[KLX_BATCH_DETAIL] ([STATUS]) INCLUDE ([END_DATE])
GO


CREATE NONCLUSTERED INDEX [IDX_KLX_BATCH_AREA_DETAIL_D2IDX] ON [dbo].[KLX_BATCH_AREA_DETAIL] (DIM_2_INDEX)
GO


CREATE NONCLUSTERED INDEX [IDX_LV_EVENT_STATUS_INC_RULEID_ENDDATE] ON [dbo].[LV_EVENT] ([STATUS]) INCLUDE (RULE_ID,[END_DATE])
GO


CREATE NONCLUSTERED INDEX [IDX_LV_EVENT_AREA_DETAIL_D2IDX] ON [dbo].[LV_EVENT_AREA_DETAIL] (DIM_2_INDEX)
GO


CREATE FUNCTION [dbo].[GET_CHILD_DIR_ID](@parentId AS INTEGER, @childName AS
varchar(256)) RETURNS integer
AS
BEGIN
  DECLARE  @child integer
	  SET @child = (SELECT ID from LV_FILE_DIR where ([PARENT_ID] = -1 or [PARENT_ID] = @parentId )and [DIR_NAME] = @childName)
	IF @child IS NULL
	   set @child = 0
	return @child
END
GO


CREATE PROCEDURE [dbo].[GET_DIRECTORY_ID_AUTOCREATE] @path VARCHAR(2000), @id INTEGER
OUTPUT
AS
BEGIN
   DECLARE @dirName	VARCHAR(256)
   DECLARE @k integer 	/*k is the position relative the start of path*/
   DECLARE @p integer	/*p is the position of '\' relative to k*/
   DECLARE @parId integer
   SET @id =1
   DECLARE @remlen integer
	SET @k=1
	SET @p=1
   SET @parId = -1
	SET @remlen = len(@path)
	WHILE (@p>0 and @id>0)
	  BEGIN
		SET @p = CHARINDEX('\',RIGHT(@path,@remlen))
		IF (@p>0)
		BEGIN
		   SET @dirName = SUBSTRING(@path, @k, @p-1)
		   set @remlen = @remlen - @p
		   SET @k = @k+@p
		   SET @id = [dbo].GET_CHILD_DIR_ID(@id, @dirName)
		   if (@id > 0)
			SET @parId = @id
		END
	end
	/*at this point parId is the id of the rightmost ancestor that exists on
the path*/
	if (@id > 0) /*the directory already exists*/
	   return @id
   while (@p>0)
	BEGIN
	    BEGIN TRAN GETDIR
		set @id = (select MAX(ID) from LV_FILE_DIR)
	    IF @id IS NULL
	       set @id = 0
	    set @id = @id + 1
	  	INSERT INTO LV_FILE_DIR (ID, DIR_NAME, PARENT_ID) values (@id, @dirName, @parId)
		set @parId = @id
		SET @p = CHARINDEX('\',RIGHT(@path, @remlen))
		if (@p>0)
		BEGIN
		   set @dirName = substring(@path,@k, @p-1)
		   set @remlen = @remlen - @p
		   set @k = @k + @p
		end
		COMMIT TRAN GETDIR
	end
END
GO


CREATE PROCEDURE [dbo].[GET_FILE_GUID_AUTOCREATE_DIR] @p_dirPath varchar(2000), @p_fileName varchar(896), @guid binary(16) OUTPUT
AS
BEGIN
    BEGIN TRAN
	DECLARE @directoryId integer
	execute [dbo].GET_DIRECTORY_ID_AUTOCREATE @p_dirPath ,@directoryId OUTPUT

	IF (@directoryId <0)
	   RETURN @directoryId /*PROBLEM CREATING DIRECTORY - THE returned value is the SQL Error Code*/

	DECLARE @fileGUID binary(16)
	SET @fileGUID = (SELECT max(FILE_GUID) FROM LV_FILE_DESC
			WHERE FILE_NAME = @p_fileName
			AND FILE_DIR_ID = @directoryId)

	if (@fileGUID is NULL)
	BEGIN
		SET @fileGUID = convert(binary(16),NEWID())
		INSERT INTO LV_FILE_DESC (FILE_GUID, FILE_NAME, FILE_DIR_ID)
			VALUES (@fileGUID, @p_fileName, @directoryId)
	END
	set @guid = @fileGUID

	commit TRAN
END
GO


CREATE PROCEDURE [dbo].[RESERVE_FILE_VERSION] @p_fileGUID binary(16), @newVersionId
INTEGER OUTPUT
AS
BEGIN
   BEGIN TRAN
	set @newVersionId = 0
	DECLARE @done integer
	SET @done = 0
	WHILE (@done = 0)
	BEGIN
		set @newVersionId = (select isnull(max(VERSION_ID),0)+1 from LV_FILE_DATA where FILE_GUID = @p_fileGUID)
		INSERT INTO LV_FILE_DATA (FILE_GUID, VERSION_ID, MIME_TYPE, ENCODING, LENGTH, DATA, CREATED_BY, CREATION_TIMESTAMP) 
          VALUES (@p_fileGUID, @newVersionId, ' ', ' ', 0, 0x0, ' ', GETUTCDATE())
		IF (@@ERROR = 2627)  /*unique or pk constraint violated*/
		   set @done = 0
		else
		   set @done = 1
	END
    COMMIT TRAN
END
GO


CREATE FUNCTION [dbo].[GET_DIRECTORY_ID](@path AS VARCHAR(2000)) RETURNS
integer
AS

BEGIN
   DECLARE @dirName	VARCHAR(256)
   DECLARE @k integer 	/*k is the position relative the start of path*/
   DECLARE @p integer	/*p is the position of '\' relative to k*/
   DECLARE @parId integer
   DECLARE @id integer
   SET @id =1

   DECLARE @remlen integer
   SET @k=1
   SET @p=1
   SET @remlen = len(@path)
   WHILE (@p>0 and @id>0)
   BEGIN
     SET @p = CHARINDEX('\',RIGHT(@path,@remlen))
     IF (@p>0)
	BEGIN
	   SET @dirName = SUBSTRING(@path, @k, @p-1)
	   set @remlen = @remlen - @p
	   SET @k = @k+@p
	   SET @id = [dbo].GET_CHILD_DIR_ID(@id, @dirName)
	   if (@id > 0)
	     SET @parId = @id
	END
   end
   /*at this point parId is the id of the rightmost ancestor that exists on the
path*/
   /*if (@id > 0) the directory already exists*/
   return @id
END
GO


/* Content for Attribute Tables ********************/

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 1, 'SGPMaxDims', 1, 16.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 1,-1,'Maximum Number of Dimensions') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 2, 'SGPDimensionDefaults', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 2,-1,'List of Default Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 3, 'SGPAccountsDimension', 5, 0.000000, 'ACCOUNTS', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 3,-1,'Name of the Accounts Dimension') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 4, 'SGPTimePeriodsDimension', 5, 0.000000, 'TIMEPER', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 4,-1,'Name of the Time Period Dimension') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 5, 'SGPEntitiesDimension', 5, 0.000000, 'ENTITIES', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 5,-1,'Name of the Entities Dimension') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 6, 'SGPCurrencyDimension', 5, 0.000000, 'CURRENCY', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 6,-1,'Name of the Currency Dimension') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 7, 'SGPFlowsDimension', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 7,-1,'Name of the Flows Dimension') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 9, 'SGPCurrentPeriod', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 9,-1,'Current Period') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 10, 'SGPCurrentYear', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 10,-1,'Current Year') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 11, 'SGPFloatingTimePeriods', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 11,-1,'System Attributes used as Time Period Symbols in Templates') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 12, 'SFXTimePeriodsSymbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 12,-1,'List of Time Period Symbols to Translate') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 13, 'SFXRates', 7, 0.000000, 'FXRates', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 13,-1,'List of Foreign Exchange Rates') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 14, 'SFXMethods', 7, 0.000000, 'FXMethods', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 14,-1,'List of Translation Methods') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 15, 'SFXTranslations', 7, 0.000000, 'FXTranslations', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 15,-1,'List of Currency Translations') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 16, 'SFXJE', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 16,-1,'Translate Journal Entry Details') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 17, 'SFXFlowsSymbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 17,-1,'List of Flow Symbols to Translate') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 18, 'SFXTranslationAdj', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 18,-1,'Calculate Detailed Translation Gain/Loss') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 19, 'SFXPeriodEndRate', 7, 0.000000, 'FXRate_PeriodEnd', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 19,-1,'Period End Rate Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 20, 'SFXAllowMonetaryCTAA', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 20,-1,'Allow Monetary Accounts to Generate Account Specific CTA') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 21, 'SFXFlowsOpen', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 21,-1,'List of Open Flow Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 22, 'SFXSchedule', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 22,-1,'Translate Schedule Data') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 23, 'SFXElim', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 23,-1,'Translate Eliminations') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 24, 'SElimInvestmentCurrency', 7, 0.000000, 'UNUSED', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 24,-1,'Common Currency for Investment Elimination Percentage Calculation') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 25, 'SElimAccountsCapital', 8, 0.000000, 'UNUSED', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 25,-1,'List of Capital Accounts') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 26, 'SElimAccountsInvestment', 8, 0.000000, 'UNUSED', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 26,-1,'List of Investment Accounts') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 27, 'SElimAccountsOwnership', 8, 0.000000, 'UNUSED', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 27,-1,'List of Ownership Accounts for Eliminations') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 28, 'SJED0Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 28,-1,'List of Valid ACCOUNTS Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 29, 'SJED1Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 29,-1,'List of Valid TIMEPER Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 30, 'SJED2Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 30,-1,'List of Valid ENTITIES Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 31, 'SJED3Symbols', 8, 0.000000, 'DIM3SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 31,-1,'List of Valid DETAILS Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 32, 'SJED4Symbols', 8, 0.000000, 'DIM4SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 32,-1,'List of Valid CURRENCY Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 33, 'SJED5Symbols', 8, 0.000000, 'DIM5SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 33,-1,'List of Valid SEGMENTS Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 34, 'SJED6Symbols', 8, 0.000000, 'DIM6SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 34,-1,'List of Valid ELEMENTS Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 35, 'SJED7Symbols', 8, 0.000000, 'DIM7SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 35,-1,'List of Valid CONTROLS Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 36, 'SJED8Symbols', 8, 0.000000, 'DIM8SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 36,-1,'List of Valid <Dimension 8> Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 37, 'SJED9Symbols', 8, 0.000000, 'DIM9SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 37,-1,'List of Valid <Dimension 9> Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 38, 'SJED10Symbols', 8, 0.000000, 'DIM10SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 38,-1,'List of Valid <Dimension 10> Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 39, 'SJED11Symbols', 8, 0.000000, 'DIM11SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 39,-1,'List of Valid <Dimension 11> Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 40, 'SJED12Symbols', 8, 0.000000, 'DIM12SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 40,-1,'List of Valid <Dimension 12> Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 41, 'SJED13Symbols', 8, 0.000000, 'DIM13SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 41,-1,'List of Valid <Dimension 13> Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 42, 'SJED14Symbols', 8, 0.000000, 'DIM14SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 42,-1,'List of Valid <Dimension 14> Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 43, 'SJED15Symbols', 8, 0.000000, 'DIM15SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 43,-1,'List of Valid <Dimension 15> Symbols for Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 60, 'SJED0Default', 7, 0.000000, 'DIM0SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 60,-1,'ACCOUNTS Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 61, 'SJED1Default', 7, 0.000000, 'DIM1SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 61,-1,'TIMEPER Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 62, 'SJED2Default', 7, 0.000000, 'DIM2SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 62,-1,'ENTITIES Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 63, 'SJED3Default', 7, 0.000000, 'DIM3SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 63,-1,'DETAILS Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 64, 'SJED4Default', 7, 0.000000, 'DIM4SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 64,-1,'CURRENCY Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 65, 'SJED5Default', 7, 0.000000, 'DIM5SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 65,-1,'SEGMENTS Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 66, 'SJED6Default', 7, 0.000000, 'DIM6SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 66,-1,'ELEMENTS Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 67, 'SJED7Default', 7, 0.000000, 'DIM7SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 67,-1,'CONTROLS Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 68, 'SJED8Default', 7, 0.000000, 'DIM8SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 68,-1,'<Dimension 8> Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 69, 'SJED9Default', 7, 0.000000, 'DIM9SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 69,-1,'<Dimension 9> Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 70, 'SJED10Default', 7, 0.000000, 'DIM10SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 70,-1,'<Dimension 10> Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 71, 'SJED11Default', 7, 0.000000, 'DIM11SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 71,-1,'<Dimension 11> Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 72, 'SJED12Default', 7, 0.000000, 'DIM12SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 72,-1,'<Dimension 12> Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 73, 'SJED13Default', 7, 0.000000, 'DIM13SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 73,-1,'<Dimension 13> Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 74, 'SJED14Default', 7, 0.000000, 'DIM14SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 74,-1,'<Dimension 14> Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 75, 'SJED15Default', 7, 0.000000, 'DIM15SET', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 75,-1,'<Dimension 15> Default Journal Entry Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 93, 'SJEApplicationIDEditable', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 93,-1,'Allow the Journal Entry Application ID to be Modified?') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 94, 'SJEDefaultShared', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 94,-1,'Share New Journal Entries by Default?') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 95, 'SJEPostedShared', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 95,-1,'Share Posted Journal Entries?') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 96, 'SGPTimePeriodsYTD', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 96,-1,'List of Year to Date Time Periods') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 97, 'SGPTimePeriodsActivity', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 97,-1,'List of Period Activity Time Periods') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 98, 'SRECAccountsNetIncome', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 98,-1,'List of Net Income Accounts') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 100, 'SPACPairs', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 100,-1,'List of Year to Date and Period Activity Time Period Pairs') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 102, 'SNDDD0Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 102,-1,'ACCOUNTS Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 103, 'SNDDD1Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 103,-1,'TIMEPER Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 104, 'SNDDD2Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 104,-1,'ENTITIES Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 105, 'SNDDD3Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 105,-1,'DETAILS Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 106, 'SNDDD4Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 106,-1,'CURRENCY Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 107, 'SNDDD5Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 107,-1,'SEGMENTS Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 108, 'SNDDD6Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 108,-1,'ELEMENTS Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 109, 'SNDDD7Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 109,-1,'CONTROLS Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 110, 'SNDDD8Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 110,-1,'<Dimension 8> Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 111, 'SNDDD9Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 111,-1,'<Dimension 9> Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 112, 'SNDDD10Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 112,-1,'<Dimension 10> Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 113, 'SNDDD11Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 113,-1,'<Dimension 11> Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 114, 'SNDDD12Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 114,-1,'<Dimension 12> Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 115, 'SNDDD13Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 115,-1,'<Dimension 13> Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 116, 'SNDDD14Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 116,-1,'<Dimension 14> Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 117, 'SNDDD15Default', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 117,-1,'<Dimension 15> Default Symbol for NDD') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 134, 'SNDDD0Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 134,-1,'List of Valid ACCOUNTS Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 135, 'SNDDD1Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 135,-1,'List of Valid TIMEPER Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 136, 'SNDDD2Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 136,-1,'List of Valid ENTITIES Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 137, 'SNDDD3Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 137,-1,'List of Valid DETAILS Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 138, 'SNDDD4Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 138,-1,'List of Valid CURRENCY Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 139, 'SNDDD5Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 139,-1,'List of Valid SEGMENTS Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 140, 'SNDDD6Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 140,-1,'List of Valid ELEMENTS Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 141, 'SNDDD7Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 141,-1,'List of Valid CONTROLS Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 142, 'SNDDD8Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 142,-1,'List of Valid <Dimension 8> Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 143, 'SNDDD9Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 143,-1,'List of Valid <Dimension 9> Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 144, 'SNDDD10Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 144,-1,'List of Valid <Dimension 10> Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 145, 'SNDDD11Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 145,-1,'List of Valid <Dimension 11> Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 146, 'SNDDD12Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 146,-1,'List of Valid <Dimension 12> Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 147, 'SNDDD13Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 147,-1,'List of Valid <Dimension 13> Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 148, 'SNDDD14Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 148,-1,'List of Valid <Dimension 14> Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 149, 'SNDDD15Symbols', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 149,-1,'List of Valid <Dimension 15> Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 198, 'SNDDModSymbolD0', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 198,-1,'Modulating Dimension Pattern Storage Symbol for ACCOUNTS') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 199, 'SNDDModSymbolD1', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 199,-1,'Modulating Dimension Pattern Storage Symbol for TIMEPER') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 200, 'SNDDModSymbolD2', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 200,-1,'Modulating Dimension Pattern Storage Symbol for ENTITIES') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 201, 'SNDDModSymbolD3', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 201,-1,'Modulating Dimension Pattern Storage Symbol for DETAILS') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 202, 'SNDDModSymbolD4', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 202,-1,'Modulating Dimension Pattern Storage Symbol for CURRENCY') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 203, 'SNDDModSymbolD5', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 203,-1,'Modulating Dimension Pattern Storage Symbol for SEGMENTS') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 204, 'SNDDModSymbolD6', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 204,-1,'Modulating Dimension Pattern Storage Symbol for ELEMENTS') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 205, 'SNDDModSymbolD7', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 205,-1,'Modulating Dimension Pattern Storage Symbol for CONTROLS') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 206, 'SNDDModSymbolD8', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 206,-1,'Modulating Dimension Pattern Storage Symbol for <Dimension 8>') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 207, 'SNDDModSymbolD9', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 207,-1,'Modulating Dimension Pattern Storage Symbol for <Dimension 9>') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 208, 'SNDDModSymbolD10', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 208,-1,'Modulating Dimension Pattern Storage Symbol for <Dimension 10>') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 209, 'SNDDModSymbolD11', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 209,-1,'Modulating Dimension Pattern Storage Symbol for <Dimension 11>') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 210, 'SNDDModSymbolD12', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 210,-1,'Modulating Dimension Pattern Storage Symbol for <Dimension 12>') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 211, 'SNDDModSymbolD13', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 211,-1,'Modulating Dimension Pattern Storage Symbol for <Dimension 13>') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 212, 'SNDDModSymbolD14', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 212,-1,'Modulating Dimension Pattern Storage Symbol for <Dimension 14>') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 213, 'SNDDModSymbolD15', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 213,-1,'Modulating Dimension Pattern Storage Symbol for <Dimension 15>') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 230, 'SNDDD0Type', 9, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 230,-1,'ACCOUNTS Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 231, 'SNDDD1Type', 9, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 231,-1,'TIMEPER Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 232, 'SNDDD2Type', 9, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 232,-1,'ENTITIES Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 233, 'SNDDD3Type', 9, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 233,-1,'DETAILS Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 234, 'SNDDD4Type', 9, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 234,-1,'CURRENCY Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 235, 'SNDDD5Type', 9, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 235,-1,'SEGMENTS Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 236, 'SNDDD6Type', 9, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 236,-1,'ELEMENTS Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 237, 'SNDDD7Type', 9, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 237,-1,'CONTROLS Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 238, 'SNDDD8Type', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 238,-1,'<Dimension 8> Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 239, 'SNDDD9Type', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 239,-1,'<Dimension 9> Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 240, 'SNDDD10Type', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 240,-1,'<Dimension 10> Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 241, 'SNDDD11Type', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 241,-1,'<Dimension 11> Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 242, 'SNDDD12Type', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 242,-1,'<Dimension 12> Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 243, 'SNDDD13Type', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 243,-1,'<Dimension 13> Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 244, 'SNDDD14Type', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 244,-1,'<Dimension 14> Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 245, 'SNDDD15Type', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 245,-1,'<Dimension 15> Dimension Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 262, 'SGPCompanyName', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 262,-1,'Company Name') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 263, 'SJEUnbalancedDimensions', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 263,-1,'List of Dimensions that can be Unbalanced in Journal Entries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 264, 'SGPDecimals', 1, 10.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 264,-1,'Number of decimals to round parent data in queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 265, 'SFXAccountsRoundingError', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 265,-1,'Foreign Exchange Rounding Difference Account') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 266, 'SFXAccountsBalanceSheet', 8, 0.000000, 'UNUSED', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 266,-1,'List of Balance Sheet Accounts') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 272, 'SJEDecimalsFinancial', 1, 2.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 272,-1,'Number of Decimals Used for Financial Journal Entry Values') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 273, 'SJEDecimalsNonFinancial', 1, 2.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 273,-1,'Number of Decimals Used for Non-Financial Journal Entry Values') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 275, 'SGPD0AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 275,-1,'System Attributes used for Attribute-driven ACCOUNTS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 276, 'SGPD1AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 276,-1,'System Attributes used for Attribute-driven TIMEPER Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 277, 'SGPD2AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 277,-1,'System Attributes used for Attribute-driven ENTITIES Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 278, 'SGPD3AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 278,-1,'System Attributes used for Attribute-driven DETAILS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 279, 'SGPD4AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 279,-1,'System Attributes used for Attribute-driven CURRENCY Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 280, 'SGPD5AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 280,-1,'System Attributes used for Attribute-driven SEGMENTS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 281, 'SGPD6AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 281,-1,'System Attributes used for Attribute-driven ELEMENTS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 282, 'SGPD7AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 282,-1,'System Attributes used for Attribute-driven CONTROLS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 283, 'SGPD8AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 283,-1,'System Attributes used for Attribute-driven <Dimension 8> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 284, 'SGPD9AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 284,-1,'System Attributes used for Attribute-driven <Dimension 9> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 285, 'SGPD10AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 285,-1,'System Attributes used for Attribute-driven <Dimension 10> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 286, 'SGPD11AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 286,-1,'System Attributes used for Attribute-driven <Dimension 11> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 287, 'SGPD12AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 287,-1,'System Attributes used for Attribute-driven <Dimension 12> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 288, 'SGPD13AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 288,-1,'System Attributes used for Attribute-driven <Dimension 13> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 289, 'SGPD14AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 289,-1,'System Attributes used for Attribute-driven <Dimension 14> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 290, 'SGPD15AttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 290,-1,'System Attributes used for Attribute-driven <Dimension 15> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 307, 'SGPD0AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 307,-1,'User Attributes used for Attribute-driven ACCOUNTS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 308, 'SGPD1AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 308,-1,'User Attributes used for Attribute-driven TIMEPER Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 309, 'SGPD2AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 309,-1,'User Attributes used for Attribute-driven ENTITIES Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 310, 'SGPD3AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 310,-1,'User Attributes used for Attribute-driven DETAILS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 311, 'SGPD4AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 311,-1,'User Attributes used for Attribute-driven CURRENCY Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 312, 'SGPD5AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 312,-1,'User Attributes used for Attribute-driven SEGMENTS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 313, 'SGPD6AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 313,-1,'User Attributes used for Attribute-driven ELEMENTS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 314, 'SGPD7AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 314,-1,'User Attributes used for Attribute-driven CONTROLS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 315, 'SGPD8AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 315,-1,'User Attributes used for Attribute-driven <Dimension 8> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 316, 'SGPD9AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 316,-1,'User Attributes used for Attribute-driven <Dimension 9> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 317, 'SGPD10AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 317,-1,'User Attributes used for Attribute-driven <Dimension 10> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 318, 'SGPD11AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 318,-1,'User Attributes used for Attribute-driven <Dimension 11> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 319, 'SGPD12AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 319,-1,'User Attributes used for Attribute-driven <Dimension 12> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 320, 'SGPD13AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 320,-1,'User Attributes used for Attribute-driven <Dimension 13> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 321, 'SGPD14AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 321,-1,'User Attributes used for Attribute-driven <Dimension 14> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 322, 'SGPD15AttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 322,-1,'User Attributes used for Attribute-driven <Dimension 15> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 339, 'SGPD0AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 339,-1,'Symbol Attributes used for Attribute-driven ACCOUNTS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 340, 'SGPD1AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 340,-1,'Symbol Attributes used for Attribute-driven TIMEPER Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 341, 'SGPD2AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 341,-1,'Symbol Attributes used for Attribute-driven ENTITIES Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 342, 'SGPD3AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 342,-1,'Symbol Attributes used for Attribute-driven DETAILS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 343, 'SGPD4AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 343,-1,'Symbol Attributes used for Attribute-driven CURRENCY Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 344, 'SGPD5AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 344,-1,'Symbol Attributes used for Attribute-driven SEGMENTS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 345, 'SGPD6AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 345,-1,'Symbol Attributes used for Attribute-driven ELEMENTS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 346, 'SGPD7AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 346,-1,'Symbol Attributes used for Attribute-driven CONTROLS Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 347, 'SGPD8AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 347,-1,'Symbol Attributes used for Attribute-driven <Dimension 8> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 348, 'SGPD9AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 348,-1,'Symbol Attributes used for Attribute-driven <Dimension 9> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 349, 'SGPD10AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 349,-1,'Symbol Attributes used for Attribute-driven <Dimension 10> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 350, 'SGPD11AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 350,-1,'Symbol Attributes used for Attribute-driven <Dimension 11> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 351, 'SGPD12AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 351,-1,'Symbol Attributes used for Attribute-driven <Dimension 12> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 352, 'SGPD13AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 352,-1,'Symbol Attributes used for Attribute-driven <Dimension 13> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 353, 'SGPD14AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 353,-1,'Symbol Attributes used for Attribute-driven <Dimension 14> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 354, 'SGPD15AttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 354,-1,'Symbol Attributes used for Attribute-driven <Dimension 15> Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 371, 'SGPSchedAttrSys', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 371,-1,'System Attributes used for Attribute-driven Schedule Dimension Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 372, 'SGPSchedAttrUser', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 372,-1,'User Attributes used for Attribute-driven Schedule Dimension Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 373, 'SGPSchedAttrSym', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 373,-1,'Symbol Attributes used for Attribute-driven Schedule Dimension Symbol Selections') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 374, 'SJEKeepDeleted', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 374,-1,'Retain Deleted Journal Entries in Database?') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 375, 'SGPSubmissionRules', 9, 0.000000, 'OFF', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 375,-1,'Handle Duplicate Data Submissions for Rules') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 376, 'SGPForecastForecastPeriods', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 376,-1,'List of Forecast Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 377, 'SPACSkipStaticSymbols', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 377,-1,'Skip Static Symbols in Dimensions Other than Accounts?') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 379, 'SGPTBAccount', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 379,-1,'Trial Balance Account Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 380, 'SGPTBAssetsAccount', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 380,-1,'Total Assets Account Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 381, 'SGPTBLiabEquityAccount', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 381,-1,'Total Liabilities & S/H Equity Account Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 382, 'SGPTBOperatingProfitAccount', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 382,-1,'Operating Profit Account Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 383, 'SGPTBEBITAccount', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 383,-1,'Earnings Before Interest & Taxes Account Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 384, 'SGPTBNetIncomeAccount', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 384,-1,'Net Income Account Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 385, 'SGPTBCompIncomeAccount', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 385,-1,'Comprehensive Income Account Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 386, 'SGPCurrencySymbol', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 386,-1,'Currencies Root Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 387, 'SGPForecastActualPeriods', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 387,-1,'List of Forecast Actual Symbols') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 388, 'SGPForecastPeriod', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 388,-1,'Current Forecast Period') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 389, 'SGPBudgetPeriod', 7, 0.000000, '  ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 389,-1,'Current Budget Period') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 390, 'SGPDecimalsLeaf', 1, 10.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 390,-1,'Number of decimals to round leaf data in queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 391, 'SGPDecimalsSubmissions', 1, 10.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 391,-1,'Number of decimals to round data in submissions') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 392, 'SGPDecimalsZero', 1, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 392,-1,'Number of decimals to consider for determining values of zero') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 500, 'SWFUseVisibility', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 500,-1,'Use Data Visibility') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 501, 'SWFUseGlobalVisibility', 9, 0.000000, 'TRUE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 501,-1,'Use Global Data Visibility') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 502, 'SWFAdminEMail', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 502,-1,'Administrator E-mail Address') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 503, 'SWFAdminDesc', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 503,-1,'Administrator Description') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 504, 'SWFLogDataChanges', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 504,-1,'Enable Log of Data Changes') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 505, 'SWFAllowJE', 9, 1.000000, 'TRUE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 505,-1,'Enable Journal Entries on Locked Workflow Areas') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 506, 'SWFHierarchyStepApproveAll', 9, 1.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 506,-1,'Allow the owner to approve all areas in hierarchy step') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 507, 'SWFLockScheduleData', 9, 1.000000, 'TRUE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 507,-1,'Lock Schedule data in Workflow processes') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 509, 'SFXOverrideRateDimensions', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 509,-1,'Additional Override Rate Dimensions') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 510, 'SFXGlobalRateDimensions', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 510,-1,'Additional Global Rate Dimensions') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 511, 'STaxEntityAttributes', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 511,-1,'Tax Entity Wizard Attributes') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 512, 'STaxEntityHierarchies', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 512,-1,'Tax Entity Wizard Hierarchies') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 513, 'SWFUseCertification', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 513,-1,'Workflow Certification Feature') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 514, 'SWFUseTimePeriodVisibility', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 514,-1,'Use Time Period Visibility') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 515, 'SLVClientConfigFileName', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 515,-1,'LVClient Configuration File Name') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 516, 'SDataAreaStatusHierarchies', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 516,-1,'Data Area Status Hierarchies') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 517, 'SXLPivotSortByPriorityByDate', 5, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 517,-1,'Sort Pivot Query Output with Equal Symbol Priorities') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 518, 'SQuote', 5, 0.000000, '"', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 518,-1,'Quotation mark within Application Framework code') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 519, 'SPrivacyPolicyURLISW', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 519,-1,'insightsoftware Privacy Policy URL') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 520, 'SPrivacyPolicyURLCustom', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 520,-1,'Custom Privacy Policy URL') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 521, 'SSupportedLanguages', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 521,-1,'Supported languages') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 522, 'SSMTPServerHost', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 522,-1,'SMTP server host') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 523, 'SSMTPServerPort', 1, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 523,-1,'SMTP server port') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 524, 'SSMTPUserName', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 524,-1,'SMTP user name') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 525, 'SSMTPPassword', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 525,-1,'SMTP password') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(0, 526, 'SAccessToken', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',0, 526,-1,'Access Token') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1001, 'UGPD0QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1001,-1,'ACCOUNTS Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1002, 'UGPD1QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1002,-1,'TIMEPER Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1003, 'UGPD2QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1003,-1,'ENTITIES Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1004, 'UGPD3QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1004,-1,'DETAILS Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1005, 'UGPD4QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1005,-1,'CURRENCY Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1006, 'UGPD5QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1006,-1,'SEGMENTS Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1007, 'UGPD6QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1007,-1,'ELEMENTS Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1008, 'UGPD7QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1008,-1,'CONTROLS Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1009, 'UGPD8QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1009,-1,'<Dimension 8> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1010, 'UGPD9QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1010,-1,'<Dimension 9> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1011, 'UGPD10QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1011,-1,'<Dimension 10> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1012, 'UGPD11QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1012,-1,'<Dimension 11> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1013, 'UGPD12QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1013,-1,'<Dimension 12> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1014, 'UGPD13QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1014,-1,'<Dimension 13> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1015, 'UGPD14QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1015,-1,'<Dimension 14> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1016, 'UGPD15QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1016,-1,'<Dimension 15> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1050, 'UGPD0InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1050,-1,'ACCOUNTS Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1051, 'UGPD1InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1051,-1,'TIMEPER Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1052, 'UGPD2InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1052,-1,'ENTITIES Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1053, 'UGPD3InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1053,-1,'DETAILS Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1054, 'UGPD4InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1054,-1,'CURRENCY Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1055, 'UGPD5InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1055,-1,'SEGMENTS Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1056, 'UGPD6InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1056,-1,'ELEMENTS Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1057, 'UGPD7InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1057,-1,'CONTROLS Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1058, 'UGPD8InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1058,-1,'<Dimension 8> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1059, 'UGPD9InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1059,-1,'<Dimension 9> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1060, 'UGPD10InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1060,-1,'<Dimension 10> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1061, 'UGPD11InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1061,-1,'<Dimension 11> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1062, 'UGPD12InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1062,-1,'<Dimension 12> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1063, 'UGPD13InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1063,-1,'<Dimension 13> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1064, 'UGPD14InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1064,-1,'<Dimension 14> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1065, 'UGPD15InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1065,-1,'<Dimension 15> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1079, 'UAccSchedules', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1079,-1,'Users Accessible Schedules') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1081, 'UWebTheme', 5, 0.000000, 'Longview Default Theme', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1081,-1,'Web Application Theme') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1082, 'UWebMaximumRows', 3, 10000.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1082,-1,'Maximum Number of Rows Rendered in Web Browser') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1083, 'UWebMaximumColumns', 3, 10000.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1083,-1,'Maximum Number of Columns Rendered in Web Browser') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1084, 'UGPCurrentGroup', 5, 0.000000, 'NONE', 'FF' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1084,-1,'Users Current Group') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1100, 'UD0QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1100,-1,'ACCOUNTS Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1101, 'UD1QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1101,-1,'TIMEPER Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1102, 'UD2QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1102,-1,'ENTITIES Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1103, 'UD3QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1103,-1,'DETAILS Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1104, 'UD4QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1104,-1,'CURRENCY Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1105, 'UD5QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1105,-1,'SEGMENTS Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1106, 'UD6QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1106,-1,'ELEMENTS Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1107, 'UD7QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1107,-1,'CONTROLS Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1108, 'UD8QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1108,-1,'<Dimension 8> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1109, 'UD9QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1109,-1,'<Dimension 9> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1110, 'UD10QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1110,-1,'<Dimension 10> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1111, 'UD11QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1111,-1,'<Dimension 11> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1112, 'UD12QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1112,-1,'<Dimension 12> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1113, 'UD13QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1113,-1,'<Dimension 13> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1114, 'UD14QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1114,-1,'<Dimension 14> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1115, 'UD15QueryDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1115,-1,'<Dimension 15> Default Symbol for Data Queries') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1150, 'UD0InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1150,-1,'ACCOUNTS Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1151, 'UD1InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1151,-1,'TIMEPER Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1152, 'UD2InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1152,-1,'ENTITIES Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1153, 'UD3InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1153,-1,'DETAILS Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1154, 'UD4InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1154,-1,'CURRENCY Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1155, 'UD5InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1155,-1,'SEGMENTS Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1156, 'UD6InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1156,-1,'ELEMENTS Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1157, 'UD7InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1157,-1,'CONTROLS Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1158, 'UD8InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1158,-1,'<Dimension 8> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1159, 'UD9InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1159,-1,'<Dimension 9> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1160, 'UD10InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1160,-1,'<Dimension 10> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1161, 'UD11InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1161,-1,'<Dimension 11> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1162, 'UD12InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1162,-1,'<Dimension 12> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1163, 'UD13InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1163,-1,'<Dimension 13> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1164, 'UD14InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1164,-1,'<Dimension 14> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1165, 'UD15InputDefault', 7, 0.000000, ' ', 'WW' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1165,-1,'<Dimension 15> Default Symbol for Data Input') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1166, 'UJavaInitialHeapSize', 1, 32.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1166,-1,'Initial Heap Size (Mb) for Longview Java components launched via Component Launcher') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1167, 'UJavaMaxHeapSize', 1, 1024.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1167,-1,'Maximum Heap Size (Mb) for Longview Java components launched via Component Launcher') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(1, 1168, 'UJavaHome', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',1, 1168,-1,'JRE Install folder for Java components launched via Component Launcher') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2001, 'ZFXSourceCurrencies', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2001,-1,'List of Source Currencies') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2002, 'ZFXRateType', 9, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2002,-1,'Translation Rate Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2003, 'ZFXTranslations', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2003,-1,'Currency Translation to Use for Each Source Currency') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2005, 'ZFXOverrideRates', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2005,-1,'Override Currency Translation to Use for Each Source Currency') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2006, 'ZFXAccountsCTA', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2006,-1,'Cumulative Translation Adjustment Account') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2007, 'ZFXTimePeriodsOpen', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2007,-1,'List of Time Periods Related to Open Period') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2008, 'ZFXRoundPrecision', 1, 99.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2008,-1,'Translation Rounding Precision') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2009, 'ZElimEntity', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2009,-1,'Elimination Entity') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2010, 'ZElimAccountsOffset', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2010,-1,'Offset Account') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2011, 'ZElimReporter', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2011,-1,'List of Hierarchies to Eliminate this Account at the Reporter''s Parent') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2012, 'ZElimContra', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2012,-1,'List of Hierarchies to Eliminate this Account at the Contra''s Parent') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2013, 'ZElimInvestmentOwnershipAccount', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2013,-1,'Investment Ownership Percentage Account') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2014, 'ZElimInvestmentOwnershipMethod', 9, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2014,-1,'Basis for Determining Capital Amount') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2015, 'ZElimEquivalentCurrency', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2015,-1,'List of Equivalent Currencies') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2016, 'ZGPNativeCurrency', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2016,-1,'Native Currency') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2017, 'ZGPLineItemDetailReference', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2017,-1,'Line Item Detail') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2018, 'ZGPCalendarDate', 11, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2018,-1,'Calendar Date') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2019, 'ZLIDCommentsSymbol', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2019,-1,'LID - Storage Symbol for Comments') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2020, 'ZFXAccountsTA', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2020,-1,'Translation Adjustment Account') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2021, 'ZGPCommentSymbol', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2021,-1,'Symbol for Variance Commentary') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2022, 'ZFXFlowsTA', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2022,-1,'Translation Adjustment Flow') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2034, 'ZElimAllowICTransactions', 9, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2034,-1,'Allow Intercompany Transactions to be Recorded Against this Entity?') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2035, 'ZElimICSchTransactions', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2035,-1,'Name of Schedule Holding Intercompany Transactions') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2036, 'ZElimICSchCapital', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2036,-1,'Name of Schedule Holding Capital Amounts') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2037, 'ZFXOperationsType', 9, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2037,-1,'Translation Method Operations Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2038, 'ZFXAccountType', 9, 0.000000, 'Monetary', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2038,-1,'Foreign Exchange Account Type') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2039, 'ZRECAccountsRetainedEarnings', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2039,-1,'Retained Earnings Income Account') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2040, 'ZFXEntityIndicator', 5, 0.000000, 'FALSE', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2040,-1,'Entity is Translated by Foreign Exchange?') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2041, 'ZValidValues', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2041,-1,'List of Valid Values for Symbol') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2050, 'ZKPIDescription', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2050,-1,'KPI - Display Description') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2051, 'ZKPIFormula', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2051,-1,'KPI - Calculation Formula') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2052, 'ZKPIReportLink', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2052,-1,'KPI - Name of Linked Report') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2053, 'ZKPIVariancePositive', 5, 0.000000, '+', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2053,-1,'KPI - Positive Variance Sign (+/-)') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2054, 'ZKPIVarianceTolerance', 3, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2054,-1,'KPI - Percentage Tolerance for Neutral Variance') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2055, 'ZFXR_Source', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2055,-1,'FXR - Reporting Set - Source Data') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2056, 'ZFXR_DetailsValidation', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2056,-1,'FXR - Reporting Set - List of Details to be Validated') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2057, 'ZFXR_ScalingFactors', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2057,-1,'FXR - Reporting Set - List of  Scaling Factors to Apply') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2058, 'ZFXR_ScalingFactor', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2058,-1,'FXR - Scaling Factor') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2059, 'ZFXR_ScalingFactorDecimals', 1, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2059,-1,'FXR - Scaling Factor - Number of Decimals') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2060, 'ZFXR_DetailsDimension', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2060,-1,'FXR - Reporting Set - Dimension Containing Details') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2061, 'ZFXR_ReportingPeriod', 7, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2061,-1,'FXR - Reporting Set - Reporting Period') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2062, 'ZFXR_ReportingPeriodDetails', 8, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2062,-1,'FXR - Reporting Set - List of Reporting Periods Details') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2063, 'ZFXR_CrossValidations', 6, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2063,-1,'FXR - Reporting Set - Cross-Validations') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2064, 'ZHierarchyName', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2064,-1,'Override the root symbol display name') 
GO

INSERT INTO [dbo].[KLX_ATTR_DEFS] VALUES(2, 2065, 'ZHierarchyDescription', 5, 0.000000, ' ', 'WR' ); 
GO

INSERT INTO [dbo].[KLX_DESC] VALUES(10,'EN',2, 2065,-1,'Override the root symbol display description') 
GO

INSERT INTO [dbo].[KLX_ATTRIBUTES] VALUES( 0, 'SYSTEM', 'Khalix System Class', 'KLX_ATTR_DEFS', ' ', 'KLX_SYSATTR_NUMVAL', 'KLX_SYSATTR_STRVAL' );
GO

INSERT INTO [dbo].[KLX_ATTRIBUTES] VALUES( 1, 'USER', 'Khalix User Class', 'KLX_ATTR_DEFS', 'KLX_USER_SERVER', 'KLX_USRATTR_NUMVAL', 'KLX_USRATTR_STRVAL' );
GO

INSERT INTO [dbo].[KLX_ATTRIBUTES] VALUES( 2, 'SYMBOL', 'Khalix Symbol Class', 'KLX_ATTR_DEFS', 'KLX_MASTER_SYMBOL', 'KLX_SYMATTR_NUMVAL', 'KLX_SYMATTR_STRVAL' );
GO

INSERT INTO [dbo].[KLX_SYSATTR_NUMVAL] VALUES( 0, 1, 0, 8 );
GO

/* Content for Web Tables ********************/

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 100,'Longview_Launch_Center','Longview Launch Center','Launch Longview components.',1,'launchcenter.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 101,'Longview_Documentation','Longview Documentation','Provide list of Longview documentation.',1,'documentation.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 102,'Report_Templates','Report Templates','Create, edit, and publish report templates.',1,'reporttemplate.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 104,'Approval_Workflow','Approval Workflow','Provide list of approval workflow processes.',1,'approval.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 107,'User_Submission_Status','User Submission Status',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 108,'Display_Locks','Display Locks',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 109,'Mappings','Mappings',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 110,'Events','Events',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 111,'Longview_Designer','Longview Designer',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 112,'Events_Status','Events Status',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4000, 'OptixEnt_C_Column3D','Optix Enterprise - 3D Column Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4001, 'OptixEnt_C_Line','Optix Enterprise - Line Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4002, 'OptixEnt_C_Bar2D','Optix Enterprise - 2D Bar Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4003, 'OptixEnt_C_Pie3D','Optix Enterprise - 3D Pie Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4004, 'OptixEnt_C_Doughnut3D','Optix Enterprise - 3D Doughnut Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4005, 'OptixEnt_C_MSColumn3D','Optix Enterprise - 3D Multi-Series Column Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4006, 'OptixEnt_C_MSBar2D','Optix Enterprise - 2D Multi-Series Bar Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4007, 'OptixEnt_C_MSArea','Optix Enterprise - 2D Multi-Series Area Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4008, 'OptixEnt_C_StackedColumn2D','Optix Enterprise - 2D Stacked Column Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4009, 'OptixEnt_C_StackedBar3D','Optix Enterprise - 3D Stacked Bar Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4010, 'OptixEnt_C_MSCombi2D','Optix Enterprise - 2D Multi-Series Single Y Combinataion Chart (Column + Line + Area)',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4011, 'OptixEnt_C_MSColumnLine3D','Optix Enterprise - 3D Multi-Series Column + Multi-Series Line - Single Y Axis Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4012, 'OptixEnt_C_MSStackedColumn2D','Optix Enterprise - 2D Multi-Series Stacked Column Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4013, 'OptixEnt_C_StackedColumn3DLineDY','Optix Enterprise - 3D Stacked Column + Line Dual Y Axis Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4014, 'OptixEnt_C_Bubble','Optix Enterprise - Bubble Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4015, 'OptixEnt_C_ScrollLine2D','Optix Enterprise - 2D Scroll Line Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4016, 'OptixEnt_C_ScrollStackeColumn2D','Optix Enterprise - 2D Scroll Stacked Column Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4017, 'OptixEnt_C_ScrollCombiDY2D','Optix Enterprise - 2D Scroll Combination (Dual Y) Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4018, 'OptixEnt_PC_DragColumn2D1','Optix Enterprise - 2D Drag-able Column Power Chart Example 1',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4019, 'OptixEnt_PC_DragColumn2D2','Optix Enterprise - 2D Drag-able Column Power Chart Example 2',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4020, 'OptixEnt_PC_LogMSLine1','Optix Enterprise - 2D Logarithmic Line Power Chart Example 1',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4021, 'OptixEnt_PC_LogMSLine2','Optix Enterprise - 2D Logarithmic Line Power Chart Example 2',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4022, 'OptixEnt_PC_InverseMSColumn2D','Optix Enterprise - 2D Inverse Y-Axis Column Power Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4023, 'OptixEnt_PC_Spline','Optix Enterprise - 2D Single-Series Spline Power Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4024, 'OptixEnt_PC_MSSpline','Optix Enterprise - 2D Multi-Series Spline Power Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4025, 'OptixEnt_PC_CandleStick1','Optix Enterprise - Candle-Stick Power Chart Example 1',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4026, 'OptixEnt_PC_CandleStick2','Optix Enterprise - Candle-Stick Power Chart Example 2',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4027, 'OptixEnt_PC_CandleStick3','Optix Enterprise - Candle-Stick Power Chart Example 3',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4028, 'OptixEnt_PC_CandleStick4','Optix Enterprise - Candle-Stick Power Chart Example 4',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4029, 'OptixEnt_PC_CandleStick5','Optix Enterprise - Candle-Stick Power Chart Example 5',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4030, 'OptixEnt_PC_CandleStick6','Optix Enterprise - Candle-Stick Power Chart Example 6',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4031, 'OptixEnt_PC_CandleStick7','Optix Enterprise - Candle-Stick Power Chart Example 7',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4032, 'OptixEnt_PC_ErrorBar2D1','Optix Enterprise - Error Bar Power Chart Example 1',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4033, 'OptixEnt_PC_ErrorBar2D2','Optix Enterprise - Error Bar Power Chart Example 2',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4034, 'OptixEnt_PC_DragNode1','Optix Enterprise - Drag Node Power Chart Example 1',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4035, 'OptixEnt_PC_DragNode2','Optix Enterprise - Drag Node Power Chart Example 2',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4036, 'OptixEnt_PC_DragNode3','Optix Enterprise - Drag Node Power Chart Example 3',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4037, 'OptixEnt_PC_MultiLevelPie1','Optix Enterprise - Multi-Level Pie Power Chart Example 1',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4038, 'OptixEnt_PC_MultiLevelPie2','Optix Enterprise - Multi-Level Pie Power Chart Example 2',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4039, 'OptixEnt_PC_MultiLevelPie3','Optix Enterprise - Multi-Level Pie Power Chart Example 3',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4040, 'OptixEnt_PC_MultiAxisLine1','Optix Enterprise - Multi-Axis Line Power Chart Example 1',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4041, 'OptixEnt_PC_MultiAxisLine2','Optix Enterprise - Multi-Axis Line Power Chart Example 2',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4042, 'OptixEnt_W_Bulb1','Optix Enterprise - Real-Time Bulb Widget Example 1',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4043, 'OptixEnt_W_Bulb2','Optix Enterprise - Real-Time Bulb Widget Example 2',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4044, 'OptixEnt_W_HLED1','Optix Enterprise - Real-Time Horizontal LED Widget Example 1',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4045, 'OptixEnt_W_HLED2','Optix Enterprise - Real-Time Horizontal LED Widget Example 2',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4046, 'OptixEnt_W_HLED3','Optix Enterprise - Real-Time Horizontal LED Widget Example 3',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4047, 'OptixEnt_W_HLED4','Optix Enterprise - Real-Time Horizontal LED Widget Example 4',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4048, 'OptixEnt_W_Thermometer1','Optix Enterprise - Thermometer Widget Example 1',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4049, 'OptixEnt_W_Thermometer2','Optix Enterprise - Thermometer Widget Example 2',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4050, 'OptixEnt_W_Thermometer3','Optix Enterprise - Thermometer Widget Example 3',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4051, 'OptixEnt_W_SparkLine','Optix Enterprise - Spark Line Widget',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4052, 'OptixEnt_W_VBullet','Optix Enterprise - Vertical Bullet Graph Widget',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4053, 'OptixEnt_W_SparkWinLoss','Optix Enterprise - Spark Win/Loss Widget',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4054, 'OptixEnt_W_Pyramid1','Optix Enterprise - Pyramid Chart Widget Example 1',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4055, 'OptixEnt_W_Pyramid2','Optix Enterprise - Pyramid Chart Widget Example 2',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4056, 'OptixEnt_W_Pyramid3','Optix Enterprise - Pyramid Chart Widget Example 3',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4057, 'OptixEnt_W_Pyramid4','Optix Enterprise - Pyramid Chart Widget Example 4',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4058, 'OptixEnt_W_DrawingPad','Optix Enterprise - Drawing Pad Widget',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4059, 'OptixEnt_M_World','Optix Enterprise - World Map',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4060, 'OptixEnt_M_NA','Optix Enterprise - North America Map',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4061, 'OptixEnt_M_Africa','Optix Enterprise - Africa Map',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4062, 'OptixEnt_M_Canada','Optix Enterprise - Canada Map',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4063, 'OptixEnt_W_AngularGauge16','Optix Enterprise - Angular Gauge Widget Example 16',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4064, 'OptixEnt_W_AngularGauge15','Optix Enterprise - Angular Gauge Widget Example 15',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4065, 'OptixEnt_W_AngularGauge01','Optix Enterprise - Angular Gauge Widget Example 1',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4066, 'OptixEnt_W_AngularGauge14','Optix Enterprise - Angular Gauge Widget Example 14',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4067, 'OptixEnt_W_AngularGauge13','Optix Enterprise - Angular Gauge Widget Example 13',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4068, 'OptixEnt_W_AngularGauge12','Optix Enterprise - Angular Gauge Widget Example 12',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4069, 'OptixEnt_W_AngularGauge11','Optix Enterprise - Angular Gauge Widget Example 11',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4070, 'OptixEnt_W_AngularGauge10','Optix Enterprise - Angular Gauge Widget Example 10',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4071, 'OptixEnt_W_AngularGauge09','Optix Enterprise - Angular Gauge Widget Example 9',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4072, 'OptixEnt_W_Gantt11','Optix Enterprise - Gantt Chart Widget Example 11',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4073, 'OptixEnt_W_Gantt10','Optix Enterprise - Gantt Chart Widget Example 10',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4074, 'OptixEnt_W_Gantt09','Optix Enterprise - Gantt Chart Widget Example 9',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4075, 'OptixEnt_W_Gantt08','Optix Enterprise - Gantt Chart Widget Example 8',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4076, 'OptixEnt_W_Gantt07','Optix Enterprise - Gantt Chart Widget Example 7',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4077, 'OptixEnt_W_Gantt06','Optix Enterprise - Gantt Chart Widget Example 6',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4078, 'OptixEnt_W_Gantt05','Optix Enterprise - Gantt Chart Widget Example 5',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4079, 'OptixEnt_W_VBullet_Stk','Optix Enterprise - Vertical Stacked Bullet Graph Widget',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4080, 'OptixEnt_C_Area2D','Optix Enterprise - 2D Area Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4081, 'OptixEnt_C_Column2D','Optix Enterprise - 2D Column Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4082, 'OptixEnt_C_Doughnut2D','Optix Enterprise - 2D Doughnut Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4083, 'OptixEnt_C_MSBar3D','Optix Enterprise - 3D Multi-Series Bar Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4084, 'OptixEnt_C_MSColumn2D','Optix Enterprise - 2D Multi-Series Column Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4085, 'OptixEnt_C_MSColumn3DLineDY','Optix Enterprise - 3D Multi-Series Column + Multi-Series Line - Dual Y Axis Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4086, 'OptixEnt_C_MSCombiDY2D','Optix Enterprise - 2D Multi-Series Dual Combination Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4087, 'OptixEnt_C_MSLine','Optix Enterprise - 2D Multi-Series Line Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4088, 'OptixEnt_C_MSStackColumn2DLineDY','Optix Enterprise - 2D Multi-Series Stacked Column + Line Dual Y Axis Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4089, 'OptixEnt_C_Pie2D','Optix Enterprise - 2D Pie Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4090, 'OptixEnt_C_Scatter','Optix Enterprise - Scatter Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4091, 'OptixEnt_C_ScrollArea2D','Optix Enterprise - 2D Scroll Area Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4092, 'OptixEnt_C_ScrollColumn2D','Optix Enterprise - 2D Scroll Column Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4093, 'OptixEnt_C_ScrollCombi2D','Optix Enterprise - 2D Scroll Combination (Single Y) Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4094, 'OptixEnt_C_StackedArea2D','Optix Enterprise - 2D Stacked Area Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4095, 'OptixEnt_C_StackedColumn3D','Optix Enterprise - 3D Stacked Column Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4096, 'OptixEnt_M_Asia','Optix Enterprise - Asia Map',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4097, 'OptixEnt_M_Europe','Optix Enterprise - Europe Map',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4098, 'OptixEnt_M_USA','Optix Enterprise - USA Map',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4099, 'OptixEnt_PC_DragLine','Optix Enterprise - 2D Drag-able Line Power Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4100, 'OptixEnt_PC_InverseMSArea','Optix Enterprise - 2D Inverse Y-Axis Area Power Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4101, 'OptixEnt_PC_InverseMSLine','Optix Enterprise - 2D Inverse Y-Axis Line Power Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4102, 'OptixEnt_PC_Kagi','Optix Enterprise - Kagi Power Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4103, 'OptixEnt_PC_LogMSColumn2D','Optix Enterprise - 2D Logarithmic Column Power Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4104, 'OptixEnt_PC_MSSplineArea','Optix Enterprise - 2D Multi-Series Spline Area Power Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4105, 'OptixEnt_PC_Radar','Optix Enterprise - Radar Power Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4106, 'OptixEnt_PC_SelectScatter','Optix Enterprise - Select-Scatter Power Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4107, 'OptixEnt_PC_SplineArea','Optix Enterprise - 2D Single-Series Spline Area Power Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4108, 'OptixEnt_PC_Waterfall2D','Optix Enterprise - Waterfall/Cascade Power Chart',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4109, 'OptixEnt_W_AngularGauge07','Optix Enterprise - Angular Gauge Widget Example 7',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4110, 'OptixEnt_W_AngularGauge02','Optix Enterprise - Angular Gauge Widget Example 2',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4111, 'OptixEnt_W_AngularGauge03','Optix Enterprise - Angular Gauge Widget Example 3',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4112, 'OptixEnt_W_AngularGauge04','Optix Enterprise - Angular Gauge Widget Example 4',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4113, 'OptixEnt_W_AngularGauge05','Optix Enterprise - Angular Gauge Widget Example 5',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4114, 'OptixEnt_W_AngularGauge06','Optix Enterprise - Angular Gauge Widget Example 6',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4115, 'OptixEnt_W_AngularGauge08','Optix Enterprise - Angular Gauge Widget Example 8',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4116, 'OptixEnt_W_Cylinder','Optix Enterprise - Real-Time Cylinder Widget',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4117, 'OptixEnt_W_Funnel','Optix Enterprise - Funnel Chart Widget',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4118, 'OptixEnt_W_Gantt01','Optix Enterprise - Gantt Chart Widget Example 1',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4119, 'OptixEnt_W_Gantt02','Optix Enterprise - Gantt Chart Widget Example 2',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4120, 'OptixEnt_W_Gantt03','Optix Enterprise - Gantt Chart Widget Example 3',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4121, 'OptixEnt_W_Gantt04','Optix Enterprise - Gantt Chart Widget Example 4',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4122, 'OptixEnt_W_HBullet','Optix Enterprise - Horizontal Bullet Graph Widget',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4123, 'OptixEnt_W_HLinearGauge','Optix Enterprise - Real-Time Horizontal Linear Widget',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4124, 'OptixEnt_W_SparkColumn','Optix Enterprise - Spark Column Widget',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4125, 'OptixEnt_W_VLED1','Optix Enterprise - Real-Time Vertical LED Widget Example 1',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4126, 'OptixEnt_W_VLED2','Optix Enterprise - Real-Time Vertical LED Widget Example 2',' ',1,'LVLogo.gif',1,' ',1 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4127, 'OptixEnt_C_ExportChart','Optix Enterprise - Export to image Column3D chart',' ',1,'LVLogo.gif',1,' ',3 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4128, 'OptixEnt_M_ExportMap','Optix Enterprise - Export to image World Map',' ',1,'LVLogo.gif',1,' ',3 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4129, 'OptixEnt_M_ExportChartData','Optix Enterprise - Export chart data',' ',1,'LVLogo.gif',1,' ',3 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4130, 'OptixEnt_C_LinkedChart','Optix Enterprise - Linked Chart',' ',1,'LVLogo.gif',1,' ',3 );
GO

INSERT INTO [dbo].[KLX_WEB_PANELS] VALUES( 4131, 'OptixEnt_PC_HeatMap','Optix Enterprise - Heat Map',' ',1,'LVLogo.gif',1,' ',3 );
GO

/* Content for JE SubCategories Tables ********************/

INSERT INTO [dbo].[KLX_JE_SUBCATEGORIES] VALUES( 'S', 0, -1, 0 );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 6,'EN',0,0,-1,'Adjustment' );
GO

/* Content for System Tables ********************/

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 0, 'ACCOUNTS' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 1, 'TIMEPER' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 2, 'ENTITIES' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 3, 'DETAILS' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 4, 'CURRENCY' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 5, 'SEGMENTS' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 6, 'ELEMENTS' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 7, 'CONTROLS' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 8, 'UNUSED1' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 9, 'UNUSED2' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 10, 'UNUSED3' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 11, 'UNUSED4' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 12, 'UNUSED5' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 13, 'UNUSED6' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 14, 'UNUSED7' );
GO

INSERT INTO [dbo].[KLX_MASTER_DIM] VALUES( 15, 'UNUSED8' );
GO

INSERT INTO [dbo].[KLX_MASTER_SYMBOL] VALUES( 0, 0, 0, 1, 0, 0, 1, 'DIM0SET', GETDATE(), GETDATE() );
GO

INSERT INTO [dbo].[KLX_MASTER_SYMBOL] VALUES( 1, 0, 0, 1, 0, 0, 1, 'DIM1SET', GETDATE(), GETDATE() );
GO

INSERT INTO [dbo].[KLX_MASTER_SYMBOL] VALUES( 2, 0, 0, 1, 0, 0, 1, 'DIM2SET', GETDATE(), GETDATE() );
GO

INSERT INTO [dbo].[KLX_MASTER_SYMBOL] VALUES( 3, 0, 0, 1, 0, 0, 1, 'DIM3SET', GETDATE(), GETDATE() );
GO

INSERT INTO [dbo].[KLX_MASTER_SYMBOL] VALUES( 4, 0, 0, 1, 0, 0, 1, 'DIM4SET', GETDATE(), GETDATE() );
GO

INSERT INTO [dbo].[KLX_MASTER_SYMBOL] VALUES( 5, 0, 0, 1, 0, 0, 1, 'DIM5SET', GETDATE(), GETDATE() );
GO

INSERT INTO [dbo].[KLX_MASTER_SYMBOL] VALUES( 6, 0, 0, 1, 0, 0, 1, 'DIM6SET', GETDATE(), GETDATE() );
GO

INSERT INTO [dbo].[KLX_MASTER_SYMBOL] VALUES( 7, 0, 0, 1, 0, 0, 1, 'DIM7SET', GETDATE(), GETDATE() );
GO

INSERT INTO [dbo].[KLX_SYM_DESC] VALUES( 1,'EN',-1,0,0,'ACCOUNTS Default' );
GO

INSERT INTO [dbo].[KLX_SYM_DESC] VALUES( 1,'EN',-1,1,0,'TIMEPER Default' );
GO

INSERT INTO [dbo].[KLX_SYM_DESC] VALUES( 1,'EN',-1,2,0,'ENTITIES Default' );
GO

INSERT INTO [dbo].[KLX_SYM_DESC] VALUES( 1,'EN',-1,3,0,'DETAILS Default' );
GO

INSERT INTO [dbo].[KLX_SYM_DESC] VALUES( 1,'EN',-1,4,0,'CURRENCY Default' );
GO

INSERT INTO [dbo].[KLX_SYM_DESC] VALUES( 1,'EN',-1,5,0,'SEGMENTS Default' );
GO

INSERT INTO [dbo].[KLX_SYM_DESC] VALUES( 1,'EN',-1,6,0,'ELEMENTS Default' );
GO

INSERT INTO [dbo].[KLX_SYM_DESC] VALUES( 1,'EN',-1,7,0,'CONTROLS Default' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 19,'EN',1,-1,-1,'All Users' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 19,'EN',2,-1,-1,'Administrators' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 19,'EN',3,-1,-1,'User Administrators' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',0,-1,-1,'ACCOUNTS' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',1,-1,-1,'TIMEPER' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',2,-1,-1,'ENTITIES' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',3,-1,-1,'DETAILS' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',4,-1,-1,'CURRENCY' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',5,-1,-1,'SEGMENTS' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',6,-1,-1,'ELEMENTS' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',7,-1,-1,'CONTROLS' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',8,-1,-1,'DIMENSION8' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',9,-1,-1,'DIMENSION9' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',10,-1,-1,'DIMENSION10' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',11,-1,-1,'DIMENSION11' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',12,-1,-1,'DIMENSION12' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',13,-1,-1,'DIMENSION13' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',14,-1,-1,'DIMENSION14' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 3,'EN',15,-1,-1,'DIMENSION15' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 4,'EN',1,0,-1,'List Items' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 4,'EN',1,1,-1,'User Input' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 4,'EN',2,0,-1,'Comment Number' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 4,'EN',2,1,-1,'Information' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 4,'EN',3,0,-1,'List Items' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 4,'EN',4,0,-1,'Comment Number' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 4,'EN',4,1,-1,'Information' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 4,'EN',5,0,-1,'Contra' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 4,'EN',6,0,-1,'Line' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 4,'EN',7,0,-1,'File Attributes' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 5,'EN',1,-1,-1,'Line Item Details Schedule' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 5,'EN',2,-1,-1,'Comments Schedule' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 5,'EN',3,-1,-1,'Virtual Line Item Details Schedule' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 5,'EN',4,-1,-1,'Virtual Comments Schedule' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 5,'EN',5,-1,-1,'Standard Intercompany Transactions' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 5,'EN',6,-1,-1,'Capital Amounts for Investment Eliminations' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 5,'EN',7,-1,-1,'File Attachment Schedule' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'ATTR:0','1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'ATTR:2','1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'ATTRDEF:0','1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'ATTRDEF:1','1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'ATTRDEF:2','1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SERVERMATH','ON' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'DIMDESC','1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SCHEDULESTAMP','1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SERVER_MODE','MULTI_USER' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'UPLOAD_ALLOWED','ON' );
GO

INSERT INTO [dbo].[LV_ROLE] VALUES( 0, 'Default' );
GO

INSERT INTO [dbo].[LV_ROLE] VALUES( 1, 'All_Access' );
GO

INSERT INTO [dbo].[LV_ROLE] VALUES( 2, 'Excel_Access' );
GO

INSERT INTO [dbo].[LV_ROLE] VALUES( 3, 'Analysis_Reporting_Access' );
GO

INSERT INTO [dbo].[LV_ROLE] VALUES( 4, 'Journal_Entries' );
GO

INSERT INTO [dbo].[LV_ROLE] VALUES( 5, 'Input_Access' );
GO

INSERT INTO [dbo].[LV_ROLE] VALUES( 6, 'V3_Compatible_Access' );
GO

INSERT INTO [dbo].[LV_ROLE] VALUES( 7, 'Dashboard_Designer_Access' );
GO

INSERT INTO [dbo].[LV_ROLE] VALUES( 8, 'Administrator_Access' );
GO

INSERT INTO [dbo].[LV_ROLE] VALUES( 9, 'FXR_Access' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 11,'EN',0,-1,-1,'Default Role' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 11,'EN',1,-1,-1,'All Access Role' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 11,'EN',2,-1,-1,'Excel Access Role' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 11,'EN',3,-1,-1,'Analysis Reporting Role' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 11,'EN',4,-1,-1,'Journal Entries Role' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 11,'EN',5,-1,-1,'Input Role' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 11,'EN',6,-1,-1,'V3 Compatible Role' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 11,'EN',7,-1,-1,'Dashboard Designer Role' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 11,'EN',8,-1,-1,'Administrator Role' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 11,'EN',9,-1,-1,'FXR Access Role' );
GO

INSERT INTO [dbo].[LV_DATA_STATUS] VALUES( 0, 'NOSTATUS' );
GO

INSERT INTO [dbo].[LV_DATA_STATUS] VALUES( 1000, 'INPROGRESS' );
GO

INSERT INTO [dbo].[LV_DATA_STATUS] VALUES( 2000, 'SUBMITTED' );
GO

INSERT INTO [dbo].[LV_DATA_STATUS] VALUES( 3000, 'APPROVED' );
GO

INSERT INTO [dbo].[LV_DATA_STATUS] VALUES( 4000, 'REJECTED' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 8,'EN',0,-1,-1,'No Status' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 8,'EN',1000,-1,-1,'In Progress' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 8,'EN',2000,-1,-1,'Submitted' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 8,'EN',3000,-1,-1,'Approved' );
GO

INSERT INTO [dbo].[KLX_DESC] VALUES( 8,'EN',4000,-1,-1,'Rejected' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'DIM7_KEY_POSN', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'DIM6_KEY_POSN', '2' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'DIM5_KEY_POSN', '3' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'DIM4_KEY_POSN', '4' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'DIM3_KEY_POSN', '5' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'DIM2_KEY_POSN', '6' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'DIM0_KEY_POSN', '7' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'DIM1_KEY_POSN', '8' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:ACCOUNTS', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:TIMEPER', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:ENTITIES', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:DETAILS', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:CURRENCY', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:SEGMENTS', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:ELEMENTS', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:CONTROLS', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:UNUSED1', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:UNUSED2', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:UNUSED3', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:UNUSED4', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:UNUSED5', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:UNUSED6', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:UNUSED7', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'SYMCACHE:UNUSED8', '1' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'MAX_DIMS', '8' );
GO

INSERT INTO [dbo].[KLX_STATUS] VALUES( 'MAX_SCHEDULEDIMS', '3' );
GO

INSERT INTO [dbo].[KLX_PARTITIONS] VALUES( 0, 0, 0, 0, 0, 0, 0, 0, 0, 'P0' );
GO

INSERT INTO [dbo].[KLX_SCHEDULES] VALUES( 1,'LineItemDetails',2,'B:1,2,3,4,5,6,7,8 E:1,2' );
GO

INSERT INTO [dbo].[KLX_SCHEDULES] VALUES( 2,'Comments',130,'B:1,2,3,4,5,6,7,8 E:1,2' );
GO

INSERT INTO [dbo].[KLX_SCHEDULES] VALUES( 3,'VLineItemDetails',0,'B:1,2,3,4,5,6,7,8 E:1' );
GO

INSERT INTO [dbo].[KLX_SCHEDULES] VALUES( 4,'VComments',0,'B:1,2,3,4,5,6,7,8 E:1,2' );
GO

INSERT INTO [dbo].[KLX_SCHEDULES] VALUES( 5,'ICStandard',1,'B:1,2,3,4,5,6,7,8 E:1' );
GO

INSERT INTO [dbo].[KLX_SCHEDULES] VALUES( 6,'ICCapital',1,'B:1,2,3,4,5,6,7,8 E:1' );
GO

INSERT INTO [dbo].[KLX_SCHEDULES] VALUES( 7,'FileAttachment',130,'B:1,2,3,4,5,6,7,8 E:1' );
GO

INSERT INTO [dbo].[KLX_SCHED_DIMS] VALUES(  1, 0, 'ListItems', 1, '01-20', 0, ' ' );
GO

INSERT INTO [dbo].[KLX_SCHED_DIMS] VALUES(  1, 1, 'Uinput', 2, 'Ucomment,uValue', 0, ' ' );
GO

INSERT INTO [dbo].[KLX_SCHED_DIMS] VALUES(  2, 0, 'CommentNo', 1, '1-100', 0, ' ' );
GO

INSERT INTO [dbo].[KLX_SCHED_DIMS] VALUES(  2, 1, 'Info', 2, 'Userid,CDate,Comment', 0, ' ' );
GO

INSERT INTO [dbo].[KLX_SCHED_DIMS] VALUES(  3, 0, 'ListItems', 1, '01-20', 0, ' ' );
GO

INSERT INTO [dbo].[KLX_SCHED_DIMS] VALUES(  4, 0, 'CommentNo', 1, '1-100', 0, ' ' );
GO

INSERT INTO [dbo].[KLX_SCHED_DIMS] VALUES(  4, 1, 'Info', 2, 'Userid,CDate,Comment', 0, ' ' );
GO

INSERT INTO [dbo].[KLX_SCHED_DIMS] VALUES(  5, 0, 'Contras', 4, 'ENTITIES;ZElimAllowICTransactions=TRUE', 17, ' ' );
GO

INSERT INTO [dbo].[KLX_SCHED_DIMS] VALUES(  6, 0, 'Lines', 2, 'L1', 0, 'L1' );
GO

INSERT INTO [dbo].[KLX_SCHED_DIMS] VALUES(  7, 0, 'FileAttachments', 2, 'FileAttachmentFlag', 0, ' ' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '1', '0', '0', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '1', '0', '1', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '1', '0', '2', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '1', '0', '3', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '1', '0', '4', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '1', '0', '5', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '1', '0', '6', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '1', '0', '7', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '6', '0', '0', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '6', '0', '1', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '6', '0', '2', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '6', '0', '3', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '6', '0', '4', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '6', '0', '5', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '6', '0', '6', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '6', '0', '7', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '8', '0', '0', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '8', '0', '1', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '8', '0', '2', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '8', '0', '3', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '8', '0', '4', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '8', '0', '5', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '8', '0', '6', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_ROLE_ACC] VALUES( '8', '0', '7', '-1', '99', 'W', '0' );
GO

INSERT INTO [dbo].[LV_USER_MAIN] VALUES( 1, 'puser', 'Power User', GETDATE(), '01/01/1970', 0, ' ', 0, 0, GETDATE(), '01/01/1970' );
GO

INSERT INTO [dbo].[LV_USER_PASSWORD] VALUES( 1, '14c2839d151cb3be344562b258ce1fe', GETDATE(), 0, 0, ' ', ' ' );
GO

INSERT INTO [dbo].[LV_USER_DETAILS] VALUES( 1, 'user', 'Power', ' ', ' ', ' ' );
GO

INSERT INTO [dbo].[LV_GROUP_MAIN] VALUES( 1, 'AllUsers', GETDATE(), GETDATE() );
GO

INSERT INTO [dbo].[LV_GROUP_MAIN] VALUES( 2, 'Administrators', GETDATE(), GETDATE() );
GO

INSERT INTO [dbo].[LV_GROUP_MAIN] VALUES( 3, 'UserAdministrators', GETDATE(), GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_GROUP] VALUES( 1, 1 );
GO

INSERT INTO [dbo].[LV_USER_GROUP] VALUES( 1, 2 );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 2, 'FULLACCESS', 'Full Access to Longview 7 System' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 4, 'APPLICATIONADMINISTRATOR', 'Access to Longview Application Administrator' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 6, 'SERVERMANAGER', 'Access to Longview Server Manager' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 41, 'ATTRIBUTE', 'Ability to manage attributes in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 42, 'BATCH', 'Ability to manage batches in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 43, 'INTERCOMPANYSETTINGS', 'Ability to manage intercompany settings in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 44, 'JOURNALENTRY', 'Ability to manage journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 45, 'LOCK', 'Ability to manage locks in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 46, 'RULE', 'Ability to manage rules in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 47, 'SCHEDULE', 'Ability to manage schedules in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 48, 'ROLE', 'Ability to manage symbol access roles in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 49, 'USERSYMBOLACCESS', 'Ability to manage symbol access for users in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 50, 'GROUPSYMBOLACCESS', 'Ability to manage symbol access for groups in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 51, 'SYMBOL', 'Ability to manage symbols in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 52, 'USERADMINISTRATION', 'Ability to perform user administration' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 53, 'GROUPADMINISTRATION', 'Ability to perform group administration' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 56, 'FOREIGNEXCHANGESETTINGS', 'Ability to manage FX settings in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 57, 'NDDSETTINGS', 'Ability to manage NDD settings in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 58, 'USERRESETPASSWORD', 'Ability to reset passwords' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 101, 'CONNECT', 'Ability to connect to a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 102, 'VIEWDATA', 'Ability to view data in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 103, 'MODIFYDATA', 'Ability to submit data in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 104, 'ODBC', 'Ability to connect to a data server using ODBC' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 105, 'IWAY', 'Ability to connect to a data server using IWAY Adapter' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 106, 'ADDINFOROFFICE', 'Access to Longview Add-In for Office' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 107, 'ADDINFOROFFICESUBMITDATA', 'Ability to submit data in a data server using Longview Add-In for Office' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 110, 'JOURNALENTRYCURRENTPERIODCREATE', 'Ability to create current period journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 111, 'JOURNALENTRYRESTATEMENTCREATE', 'Ability to create restatement journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 112, 'JOURNALENTRYPRIORPERIODADJCREATE', 'Ability to create prior period journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 113, 'JOURNALENTRYFUTUREPERIODCREATE', 'Ability to create future journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 114, 'JOURNALENTRYCURRENTPERIODREVIEWPOST', 'Ability to review current period journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 115, 'JOURNALENTRYRESTATEMENTREVIEWPOST', 'Ability to review restatement journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 116, 'JOURNALENTRYPRIORPERIODADJREVIEWPOST', 'Ability to review prior period journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 117, 'JOURNALENTRYFUTUREPERIODREVIEWPOST', 'Ability to review future journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 118, 'JOURNALENTRYCURRENTPERIODPERMPOST', 'Ability to permanently post journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 119, 'JOURNALENTRYRESTATEMENTPERMPOST', 'Ability to permanently post restatement journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 120, 'JOURNALENTRYPRIORPERIODADJPERMPOST', 'Ability to permanently post prior period journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 121, 'JOURNALENTRYFUTUREPERIODPERMPOST', 'Ability to permanently post future journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 122, 'JOURNALENTRYOWNREVIEWPOST', 'Ability to review own posted journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 123, 'JOURNALENTRYOWNPERMPOST', 'Ability to permanently post journal entries in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 124, 'JOURNALENTRYTHRESHOLDTOTALDEBITS', 'Ability to specify a value for JE threshold (total debits) in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 125, 'JOURNALENTRYTHRESHOLDSINGLECELL', 'Ability to specify a value for JE threshold (single data cell) in data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 126, 'JOURNALENTRYDELETE', 'Ability to delete journal entries in data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 130, 'SYSTEMATTRIBUTECREATE', 'Ability to create system attributes in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 131, 'USERATTRIBUTECREATE', 'Ability to create user attributes in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 132, 'SYMBOLATTRIBUTECREATE', 'Ability to create symbol attributes in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 133, 'SYSTEMATTRIBUTEMODIFY', 'Ability to modify system attributes in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 134, 'USERATTRIBUTEMODIFY', 'Ability to modify user attributes in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 135, 'SYMBOLATTRIBUTEMODIFY', 'Ability to modify symbol attributes in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 136, 'SYSTEMATTRIBUTEDELETE', 'Ability to delete system attributes in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 137, 'USERATTRIBUTEDELETE', 'Ability to delete user attributes in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 138, 'SYMBOLATTRIBUTEDELETE', 'Ability to delete symbol attributes in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 140, 'SYMBOLCREATE', 'Ability to create symbols in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 141, 'SYMBOLSET', 'Ability to modify symbols in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 142, 'SYMBOLDELETE', 'Ability to delete symbols in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 143, 'SYMBOLASSIGN', 'Ability to assign symbols to a hierarchy in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 144, 'SYMBOLREMOVE', 'Ability to remove symbols from a hierarchy in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 145, 'SYMBOLSWITCH', 'Ability to switch symbols in a hierarchy in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 146, 'SYMBOLCANDELETEROOT', 'Ability to be able to delete a root symbol in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 147, 'SYMBOLCANCREATEROOT', 'Ability to be able to create a root symbol in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 148, 'CONNECTVIAAPPLICATIONFRAMEWORK', 'Ability to connect to a data server using Application Framework' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 149, 'COMPONENTAUTHENTICATION', 'Ability to perform component authentication' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 151, 'DELETECOMMENTS', 'Ability to delete comments in data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 200, 'SERVERMANAGERSTART', 'Ability to start/stop servers' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 302, 'ANALYSISREPORTINGPUBLISHER', 'Ability to access Longview Analysis and Reporting as a publisher' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 303, 'ANALYSISREPORTINGAUTHOR', 'Ability to access Longview Analysis and Reporting as an author' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 304, 'ANALYSISREPORTINGUSER', 'Ability to access Longview Analysis and Reporting as a user' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 305, 'DASHBOARDDESIGNER', 'Access to Longview Dashboard Designer for a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 307, 'WORKFLOWDESIGNER', 'Access to Longview Workflow Designer for a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 308, 'JOURNALENTRIES', 'Access to Longview Journal Entries for a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 309, 'MAPPINGSEDITOR', 'Access to Mappings Editor' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 310, 'MAPSMANAGE', 'Ability to manage maps in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 311, 'MAPPINGSMANAGE', 'Ability to manage mappings in a data server' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 312, 'DESIGNER', 'Access to Longview Designer' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 313, 'DESIGNERDATAIMPORTSCREATE', 'Ability to create Data Import Apps in Longview Designer' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 314, 'DESIGNERDATAIMPORTSMODIFY', 'Ability to modify Data Import Apps in Longview Designer' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 315, 'DESIGNERDATAIMPORTSDELETE', 'Ability to delete Data Import Apps in Longview Designer' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 316, 'DESIGNERDATAIMPORTSPUBLISH', 'Ability to publish Data Import Apps in Longview Designer' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 317, 'DESIGNERLONGVIEWAPPSPUBLISH', 'Ability to publish Longview Apps in Longview Designer' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 400, 'METADATARESETSECURITYRELATED', 'Ability to reset metadata for security related maintenance' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 401, 'METADATAEXPORTSECURITYRELATED', 'Ability to export metadata for security related maintenance' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 402, 'METADATARESETNONSECURITYRELATED', 'Ability to reset metadata for non-security related maintenance' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 403, 'METADATAEXPORTNONSECURITYRELATED', 'Ability to export metadata for non-security related maintenance' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 410, 'SERVICEACCOUNTRESTAPIONLY', 'Service account with REST API access only' );
GO

INSERT INTO [dbo].[LV_OPERATIONS] VALUES( 411, 'SERVICEACCOUNTUSERADMINISTRATOR', 'Grants the ability to perform user/group administration' );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 4, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 6, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 41, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 42, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 43, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 44, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 45, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 46, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 47, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 48, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 49, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 50, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 51, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 56, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 57, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 101, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 102, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 103, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 104, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 105, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 106, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 107, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 110, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 111, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 112, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 113, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 114, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 115, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 116, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 117, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 118, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 119, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 120, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 121, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 122, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 123, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 124, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 125, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 126, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 130, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 131, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 132, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 133, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 134, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 135, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 136, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 137, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 138, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 140, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 141, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 142, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 143, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 144, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 145, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 146, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 147, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 148, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 149, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 151, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 200, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 302, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 305, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 307, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 308, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 309, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 310, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 311, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 312, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 313, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 314, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 315, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 316, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 317, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 400, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 401, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 402, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 403, 0, GETDATE() );
GO

INSERT INTO [dbo].[LV_USER_OPERATIONS] VALUES( 1, 411, 0, GETDATE() );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '0', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '1', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '2', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '3', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '4', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '5', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '6', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '7', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '0', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '1', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '2', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '3', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '4', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '5', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '6', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_SYM_ACC] VALUES( '1', '7', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '1', '0', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '0', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '0', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '0', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '0', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '1', '1', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '1', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '1', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '1', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '1', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '1', '2', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '2', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '2', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '2', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '2', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '1', '3', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '3', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '3', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '3', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '3', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '1', '4', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '4', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '4', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '4', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '4', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '1', '5', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '5', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '5', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '5', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '5', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '1', '6', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '6', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '6', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '6', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '6', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '1', '7', '-1', '99', 'W', '0', '1', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '7', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '2', '7', '-1', '99', 'W', '0', '8', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '7', '-1', '99', 'W', '0', '6', '1' );
GO

INSERT INTO [dbo].[KLX_USER_GRP_ACC] VALUES( '3', '7', '-1', '99', 'W', '0', '8', '1' );
GO

