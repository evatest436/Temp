﻿USE Master
GO

/*** Create view login ***/

EXEC ('CREATE LOGIN [Essity242] WITH PASSWORD = ''Longview7'', DEFAULT_DATABASE = TaxASCMiniReg, CHECK_POLICY = OFF' )

/*** Create view user ***/

USE TaxASCMiniReg
GO

EXEC ('CREATE USER Essity242 FOR LOGIN Essity242 WITH DEFAULT_SCHEMA = dbo' )