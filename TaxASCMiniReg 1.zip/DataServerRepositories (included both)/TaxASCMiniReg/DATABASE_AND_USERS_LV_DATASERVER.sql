/***** Database creation script *****/
USE master
GO

/*** Create the database ***/

CREATE DATABASE TaxASCMiniReg
ON PRIMARY
	( NAME = system01,
	FILENAME = '\DATA\TaxASCMiniReg_system.mdf',
	SIZE = 10MB,
	FILEGROWTH = 2MB ),
	FILEGROUP KLX_BASE_DAT
	( NAME = klx_base_dat01,
	FILENAME = '\DATA\TaxASCMiniReg_klx_base_dat01.ndf',
	SIZE = 100MB,
	FILEGROWTH = 10MB ),
	FILEGROUP KLX_DERIVED_DAT
	( NAME = klx_derived_dat01,
	FILENAME = '\DATA\TaxASCMiniReg_klx_derived_dat01.ndf',
	SIZE = 200MB,
	FILEGROWTH = 10MB )
LOG ON
	( NAME = klx_log01,
	FILENAME = '\LOG\TaxASCMiniReg_klx_log01.ldf',
	SIZE = 50MB,
	FILEGROWTH = 5MB )
GO

/*** Set recovery to simple, required for Khalix ***/

ALTER DATABASE TaxASCMiniReg SET RECOVERY SIMPLE
GO

/*** Create the login if it doesn't exist ***/

IF SUSER_ID('Essity242') IS NULL
BEGIN
    EXEC ('CREATE LOGIN [Essity242] WITH PASSWORD = ''Longview7'', DEFAULT_DATABASE = TaxASCMiniReg, CHECK_POLICY = OFF' )
END
GO

/*** Grant Bulk Insert Administrators server role to the new login ***/

EXEC sp_addsrvrolemember 'Essity242', 'bulkadmin'
GO

/*** Set the new login as the DB owner ***/

USE TaxASCMiniReg
GO

EXEC sp_changedbowner 'Essity242', true
GO

/***** End of Database creation script *****/

CHECKPOINT
GO